#!/usr/bin/env bash

set -euo pipefail

mode="${1:-fast}"
if [[ "$mode" != "docs" && "$mode" != "fast" && "$mode" != "full" && "$mode" != "supply-chain" ]]; then
  printf 'usage: %s [docs|fast|full|supply-chain]\n' "$0" >&2
  exit 2
fi

repo_root="$(git rev-parse --show-toplevel)"
cd "$repo_root"

if [[ -f "$HOME/.cargo/env" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/.cargo/env"
fi

report_path="${CHECK_REPORT_PATH:-}"
if [[ -n "$report_path" && "$report_path" != /* ]]; then
  report_path="$repo_root/$report_path"
fi

if [[ -n "$report_path" ]]; then
  mkdir -p "$(dirname "$report_path")"
  {
    printf '# Check run log\n\n'
    printf -- '- Mode: `%s`\n' "$mode"
    printf -- '- Started: `%s`\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    printf -- '- Host: `%s`\n\n' "$(uname -srm)"
    printf '| Step | Duration seconds | Result |\n'
    printf '|---|---:|---|\n'
  } > "$report_path"
fi

run_step() {
  local label="$1"
  shift
  local started finished duration status

  printf '\n==> %s\n' "$label"
  started="$(date +%s)"
  set +e
  "$@"
  status=$?
  set -e
  finished="$(date +%s)"
  duration=$((finished - started))

  if [[ -n "$report_path" ]]; then
    if (( status == 0 )); then
      printf '| %s | %d | PASS |\n' "$label" "$duration" >> "$report_path"
    else
      printf '| %s | %d | FAIL (%d) |\n' "$label" "$duration" "$status" >> "$report_path"
    fi
  fi

  if (( status != 0 )); then
    printf 'check: %s failed with status %d\n' "$label" "$status" >&2
    exit "$status"
  fi
}

check_quality_tool_versions() {
  source "$repo_root/tools/quality-tool-versions.env"
  cargo deny --version | rg -q "$CARGO_DENY_VERSION"
  cargo audit --version | rg -q "$CARGO_AUDIT_VERSION"
  cargo cyclonedx --version | rg -q "$CARGO_CYCLONEDX_VERSION"
}

check_tracked_whitespace() {
  local empty_tree
  empty_tree="$(git hash-object -t tree /dev/null)"
  git diff --check "$empty_tree" HEAD
}

install_management_spa_dependencies() {
  command -v node >/dev/null
  command -v npm >/dev/null
  (
    cd "$repo_root/web/prism"
    npm ci --ignore-scripts --no-audit --no-fund
  )
}

run_step "P12 serve envelope" "$repo_root/scripts/test-p12-02-serve.sh"
run_step "Agent multi-turn and stream regression" python3 "$repo_root/scripts/test-agent-roundtrip.py"
run_step "Source policy" "$repo_root/scripts/check-source-policy.rb"
run_step "Secret scanner test" "$repo_root/scripts/test-secret-scan.sh"
run_step "Crate boundaries" "$repo_root/scripts/check-crate-boundaries.rb"
run_step "Document links" "$repo_root/scripts/check-doc-links.rb"
run_step "Contract tests" "$repo_root/scripts/check-contract-tests.rb"
run_step "Tracked secret scan" "$repo_root/scripts/secret-scan.sh" --all
run_step "Git whitespace" check_tracked_whitespace

if [[ "$mode" == "full" ]]; then
  run_step "Quality tool versions" check_quality_tool_versions
  run_step "Dependency policy" cargo deny check
  run_step "RustSec audit" cargo audit
fi

if [[ -n "$report_path" ]]; then
  printf '\nCompleted: `%s`\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$report_path"
fi

printf '\ncheck: remaining Full steps passed; original Full stays FAIL\n'
