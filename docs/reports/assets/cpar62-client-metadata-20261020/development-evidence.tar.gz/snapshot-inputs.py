"""Bind tracked source and enumerated inherited overlays, without generated artifacts."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2])
overlay = json.loads(Path(sys.argv[3]).read_text())

def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])

paths = set(git("ls-files", "-z").decode().split("\0")) - {""}
paths.update(row["path"] for row in overlay)
records = []
for relative in sorted(paths):
    path = root / relative
    value = path.lstat()
    link = os.readlink(path) if path.is_symlink() else None
    content = os.fsencode(link) if link is not None else path.read_bytes()
    records.append({"path": relative, "mode": oct(stat.S_IMODE(value.st_mode)),
                    "symlink": link, "bytes": len(content),
                    "sha256": hashlib.sha256(content).hexdigest()})
binding = {"root": str(root), "head": git("rev-parse", "HEAD").decode().strip(),
           "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
           "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
           "records": records}
output.write_text(json.dumps(binding, indent=2) + "\n")
print(json.dumps({"manifest": str(output), "paths": len(records),
                  "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}))
