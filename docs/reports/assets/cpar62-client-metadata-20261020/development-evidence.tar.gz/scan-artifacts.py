"""Inspect actual allowlisted artifact bytes and expanded gzip/tar members with repo rules."""
from pathlib import Path, PurePosixPath
import fnmatch
import gzip
import hashlib
import io
import json
import shlex
import subprocess
import sys
import tarfile

root, assets, output = map(Path, sys.argv[1:4])
exceptions = json.loads(Path(sys.argv[4]).read_text()) if len(sys.argv) == 5 else []
used_exceptions = []
policy = root / "scripts/secret-scan.sh"
line = next(s for s in policy.read_text().splitlines() if s.startswith("secret_regex="))
pattern = shlex.split(line)[0].split("=", 1)[1]
forbidden = [".env", "*/.env", ".env.*", "*/.env.*", "*.pem", "*.key", "*.p12",
             "*.pfx", "*.jks", "*.keystore", "*.oauth.json", "auths/*", "*/auths/*",
             "credentials/*", "*/credentials/*", "secrets/*", "*/secrets/*",
             "deploy-secrets/*", "*/deploy-secrets/*", "*.sqlite", "*.sqlite3",
             "*.sqlite-shm", "*.sqlite-wal"]
records, failures = [], []

def inspect(name, data, depth=0):
    if depth > 5 or len(data) > 100_000_000:
        raise ValueError("artifact expansion bound")
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or any(fnmatch.fnmatchcase(name, p) for p in forbidden):
        failures.append({"path": name, "kind": "forbidden path"})
    records.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    if name.endswith(".gz"):
        inspect(name[:-3], gzip.decompress(data), depth + 1)
    elif name.endswith(".tar"):
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            for member in archive.getmembers():
                if not member.isfile():
                    raise ValueError("only regular artifact archive members are permitted")
                inspect(str(path.parent / member.name), archive.extractfile(member).read(), depth + 1)
    else:
        result = subprocess.run(["rg", "--pcre2", "-a", "--quiet", pattern], input=data,
                                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        if result.returncode == 0:
            remaining = []
            for line in data.splitlines(keepends=True):
                digest = hashlib.sha256(line).hexdigest()
                reviewed = next((e for e in exceptions if e["artifact"] == name
                                 and e["line_sha256"] == digest), None)
                if reviewed is None:
                    remaining.append(line)
                else:
                    # Only a separately verified exact historical filename line is exempt.
                    # The original artifact is unchanged; all other bytes use the same PCRE2.
                    used_exceptions.append(reviewed)
            retry = subprocess.run(["rg", "--pcre2", "-a", "--quiet", pattern],
                                   input=b"".join(remaining), stdout=subprocess.DEVNULL,
                                   stderr=subprocess.PIPE)
            if retry.returncode == 0:
                failures.append({"path": name, "kind": "possible secret; values suppressed"})
            elif retry.returncode != 1:
                raise RuntimeError("unchanged regex rescan failed")
        elif result.returncode != 1:
            raise RuntimeError("unchanged regex scan failed")

for path in sorted(assets.rglob("*")):
    if path.is_symlink():
        raise ValueError("artifact symlink")
    if path.is_file():
        inspect(path.relative_to(assets).as_posix(), path.read_bytes())
if used_exceptions != exceptions:
    raise ValueError("exact reviewed exception set must match actual use")
report = {"status": "FAIL" if failures else "PASS", "policy_sha256": hashlib.sha256(policy.read_bytes()).hexdigest(),
          "method": "unchanged repository PCRE2 pattern and forbidden paths, actual bytes, recursive expanded members",
          "exceptions": used_exceptions, "records": records, "failures": failures}
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "records": len(records), "failures": failures}))
sys.exit(bool(failures))
