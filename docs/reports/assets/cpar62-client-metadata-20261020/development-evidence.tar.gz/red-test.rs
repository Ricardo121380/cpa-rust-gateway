//! C4 is a field-isolated synthetic request, never an original Codex compatibility claim.
use super::*;

const BLOB: &str = r#"{ "installation_id":"C4_PRIVATE_INSTALL", "session_id":"C4_PRIVATE_SESSION", "thread_id":"C4_PRIVATE_THREAD", "turn_id":"C4_PRIVATE_TURN", "root_turn_id":"C4_PRIVATE_ROOT", "window_id":"C4_PRIVATE_WINDOW", "window_number":0, "context_window_id":"C4_PRIVATE_CONTEXT", "agent_name":"/root", "request_kind":"turn", "thread_source":"user", "turn_trigger":"exec", "sandbox":"seatbelt", "sandbox_mode":"workspace-write", "auto_review_enabled":false, "node_repl_auto_review_required":false, "node_repl_disabled":false, "turn_started_at_unix_ms":1792342567139, "analytics_enabled":true, "model":"C4_PRIVATE_MODEL" }"#;

fn metadata() -> Value {
    json!({"root_turn_id":"C4_PRIVATE_ROOT","session_id":"C4_PRIVATE_SESSION",
        "thread_id":"C4_PRIVATE_THREAD","turn_id":"C4_PRIVATE_TURN",
        "x-codex-installation-id":"C4_PRIVATE_INSTALL","x-codex-window-id":"C4_PRIVATE_WINDOW",
        "x-codex-turn-metadata":BLOB})
}

#[actix_web::test]
async fn public_build_c4_metadata_is_local_and_answer_usage_are_preserved() -> TestResult {
    for streaming in [false, true] {
        let peer = ModelPeer::start_wire(streaming, tool_rounds::wire_response(1, streaming)?)?;
        let fixture = lifecycle_fixture(namespaces::transport(&peer, 7)?)?;
        let recording = Recording::start(&fixture, false)?;
        let (url, server) = namespaces::listener(&fixture)?;
        let body = json!({"model":"p12-test-model","input":"C4 synthetic question",
            "stream":streaming,"client_metadata":metadata()});
        let (status, bytes) = namespaces::request(&fixture, &url, &body).await?;
        assert_eq!(status, 200, "{}", String::from_utf8_lossy(&bytes));
        let terminal = namespaces::terminal(&bytes, streaming)?;
        assert_eq!(terminal["usage"]["input_tokens"], 20);
        assert_eq!(terminal["usage"]["output_tokens"], 7);
        let sent = peer.requests.lock().map_err(|_| "receiver")?;
        assert_eq!(sent.len(), 1);
        assert!(sent[0].body.get("client_metadata").is_none());
        assert!(!String::from_utf8_lossy(&sent[0].wire).contains("C4_PRIVATE"));
        drop(sent);
        server.stop(false).await;
        recording.finish(&fixture, 0).await?;
    }
    Ok(())
}
