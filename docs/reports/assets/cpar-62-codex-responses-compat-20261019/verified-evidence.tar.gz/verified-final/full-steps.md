# Check run log

- Mode: `full`
- Started: `2026-10-19T05:50:00Z`
- Host: `Darwin 27.0.0 arm64`

| Step | Duration seconds | Result |
|---|---:|---|
| Shell syntax | 1 | PASS |
| CI workflow | 0 | PASS |
| Release artifact workflow | 1 | PASS |
| CI change classifier | 0 | PASS |
| Plan state | 1 | PASS |
| Plan state guard | 0 | PASS |
| Canary thresholds | 1 | PASS |
| Caddy split | 0 | PASS |
| Caddy split guard | 2 | PASS |
| Management SPA dependencies | 1 | PASS |
| Benchmark baseline comparator | 1 | PASS |
| Soak runner argument guard | 35 | PASS |
| Soak receipt checker | 1 | PASS |
| Quality installer cache behavior | 1 | PASS |
| Release artifact verifier | 5 | PASS |
| P12 systemd unit | 1 | PASS |
| P12 OpenAI differential graph | 0 | PASS |
| P12 OpenAI differential classifier | 0 | PASS |
| P12 OpenClaw migration dry-run | 1 | PASS |
| P12 G1 production graph | 0 | PASS |
| P12 G1 live harness | 0 | PASS |
| P12 G1 Chat SSE classifier | 0 | PASS |
| P12 G1 Responses JSON classifier | 0 | PASS |
| P12 G1 Messages SSE classifier | 0 | PASS |
| P12 grok2api memory export | 1 | PASS |
| P12 Autoreg Console memory export | 0 | PASS |
| P12 production observer | 0 | PASS |
| P12 Grok CPAR curl E2E harness | 0 | PASS |
| CPAR new-build acceptance oracle | 6 | PASS |
| Management SPA | 3 | PASS |
| Rust format | 2 | PASS |
| Clippy | 23 | PASS |
| Rust tests | 208 | PASS |
| P12 serve envelope | 22 | PASS |
| Agent multi-turn and stream regression | 9 | PASS |
| Source policy | 0 | PASS |
| Secret scanner test | 1 | PASS |
| Crate boundaries | 1 | PASS |
| Document links | 0 | PASS |
| Contract tests | 1 | PASS |
| Tracked secret scan | 92 | PASS |
| Git whitespace | 0 | PASS |
| Quality tool versions | 0 | PASS |
| Dependency policy | 2 | PASS |
| RustSec audit | 4 | PASS |

Completed: `2026-10-19T05:57:07Z`
