//! Bounded parallel function batches through the public production Build assembly.
use super::*;

#[actix_web::test]
async fn public_build_parallel_flat_functions_reach_receiver() -> TestResult {
    let peer = ModelPeer::start_wire(false, tool_rounds::wire_response(0, false)?)?;
    let fixture = lifecycle_fixture(namespaces::transport(&peer, 7)?)?;
    let recording = Recording::start(&fixture, false)?;
    let (url, server) = namespaces::listener(&fixture)?;
    let body = json!({"model":"p12-test-model","input":"two independent functions",
        "tools":[{"type":"function","name":"lookup","parameters":{"type":"object"}}],
        "parallel_tool_calls":true,"tool_choice":"auto"});
    let (status, bytes) = namespaces::request(&fixture, &url, &body).await?;
    server.stop(false).await;
    let database = recording.finish(&fixture, 0).await?;
    let rows = SqliteEventStore::open_read_only(database)?.list_events()?;
    let attempts = rows.iter().filter(|row| matches!(row.event(), GatewayEvent::Attempt(_))).count();
    println!("CPAR62_PARALLEL_RED {}", json!({"status":status,"accepted":peer.accepted.load(Ordering::SeqCst),
        "receiver":peer.requests.lock().map_err(|_|"receiver")?.len(),"attempts":attempts,
        "request_count":rows.iter().filter(|row|matches!(row.event(),GatewayEvent::Request(_))).count(),
        "body":String::from_utf8_lossy(&bytes)}));
    assert_eq!(status, 200, "{}", String::from_utf8_lossy(&bytes));
    Ok(())
}
