//! Bounded parallel function batches through the public production Build assembly.
use super::*;

fn controlled_compiler(database: &Path) -> Result<RouteCompiler, RuntimeCompositionError> {
    // Only this private owned fixture supplies the independent local capability evidence.
    // The actual compiler still intersects endpoint/model/candidate policy and emits the snapshot.
    let stock = p12_adapter_capabilities("grok.build.responses")?;
    let parallel = CapabilitySet::try_new(stock.iter().chain([SemanticCapability::ParallelTools]))
        .map_err(|_| RuntimeCompositionError::Unavailable)?;
    Ok(RouteCompiler::with_adapter_capabilities(
        CatalogView::default(),
        BTreeMap::from([("grok.build.responses".into(), parallel)]),
    ).with_durable_catalog(database.to_owned()))
}

fn fixture_for(
    transport: Arc<dyn GrokBuildTransport>,
    stored: bool,
    parallel_profile: bool,
    qualify: impl FnOnce(&mut P12TransportProfiles),
) -> Result<Fixture, Box<dyn Error>> {
    let (channel, secret) = native_channels()[0];
    let mut fixture = fixture_with_compiler(
        channel, secret.as_bytes(), false,
        |configuration| {
            if stored { configuration.route_candidates[0].transform_mode = TransformMode::Canonical; }
            configuration.public_models[0].model_name = channel.model.into();
            configuration.model_aliases.push(gateway_store::control_plane::ModelAliasConfiguration {
                alias: "p12-test-model".into(), public_model_id: configuration.public_models[0].id.clone(),
            });
            configuration.model_routes[0].max_attempts = 3;
            let mut spare = configuration.route_candidates[0].clone();
            spare.id = gateway_core::RouteCandidateId::try_new("parallel-spare-candidate")?;
            spare.upstream_model = "unselected-spare-model".into(); spare.priority = 1;
            configuration.route_candidates.push(spare);
            Ok(())
        },
        |endpoints| {
            let mut profiles = P12TransportProfiles::try_new()?;
            profiles.build = Some(transport);
            qualify(&mut profiles);
            endpoints.values_mut().next().ok_or("endpoint")?.transports = Arc::new(profiles);
            Ok(())
        },
        |_, _| Ok(Arc::from([])),
        |database| if parallel_profile { controlled_compiler(database) } else { deployment_route_compiler(database) },
    )?;
    if stored {
        fixture.state = fixture.state.clone().with_stored_response_store(Arc::new(
            gateway_store::stored_response::SqliteStoredResponseStore::open(
                fixture.directory.path().join("batch-c.sqlite3"), test_secret_store()?,
            )?,
        ));
    }
    Ok(fixture)
}

fn declarations(namespaced: bool) -> Value {
    let f = json!({"type":"function","name":"lookup","parameters":{"type":"object"},"strict":false});
    if namespaced {
        json!([
            {"type":"namespace","name":"left","description":"Independent left seed", "tools":[f.clone()]},
            {"type":"namespace","name":"right","description":"Independent right seed", "tools":[f.clone()]},
            {"type":"function","name":"combine","parameters":{"type":"object"},"strict":false}
        ])
    } else {
        json!([f, {"type":"function","name":"combine","parameters":{"type":"object"},"strict":false}])
    }
}

fn output(round: usize, namespaced: bool) -> Value {
    let mut items = tool_rounds::output(round).as_array().cloned().unwrap_or_default();
    if round == 0 {
        items.truncate(1);
        for (index, seed) in [(0, 19), (1, 22)] {
            let mut call = json!({"id":format!("parallel-item-{index}"),"type":"function_call","status":"completed",
                "call_id":format!("parallel-call-{index}"),"name":"lookup",
                "arguments":json!({"seed":seed,"label":if index==0 {"左"} else {"右"}}).to_string()});
            if namespaced { call["namespace"] = json!(if index==0 {"left"} else {"right"}); }
            items.push(call);
        }
    } else if round == 2 {
        items[1]["name"] = json!("combine");
        items[1]["arguments"] = json!(r#"{"left":19,"right":22,"sum":41}"#);
    } else {
        items[1]["content"][0]["text"] = json!(if round==1 {"Both independent seeds total 41."} else {"The later combined result is 42."});
    }
    json!(items)
}

fn event(kind: &str, mut value: Value) -> String {
    value["type"] = json!(kind);
    // Deliberate gaps: sequence_number is never a requirement of contiguous numbering.
    value["sequence_number"] = json!(900);
    format!("event: {kind}\ndata: {value}\n\n")
}

fn wire(round: usize, namespaced: bool, streaming: bool, reverse_done: bool) -> Result<String, Box<dyn Error>> {
    if round != 0 || !streaming {
        return namespaces::wire_output(&output(round, namespaced), &format!("parallel-native-{round}"), streaming);
    }
    let items = output(round, namespaced);
    let summary = json!([items[0]]);
    let prefix = namespaces::wire_output(&summary, "parallel-native-0", true)?;
    let mut bytes = prefix.split("event: response.completed").next().ok_or("prefix")?.to_owned();
    for index in [1,2] {
        let mut added = items[index].clone(); added["status"] = json!("in_progress"); added["arguments"] = json!("");
        bytes += &event("response.output_item.added", json!({"output_index":index,"item":added}));
    }
    let a: Vec<_> = items[1]["arguments"].as_str().ok_or("args")?.chars().collect();
    let b: Vec<_> = items[2]["arguments"].as_str().ok_or("args")?.chars().collect();
    for offset in 0..a.len().max(b.len()) {
        for (index, chars) in [(1,&a),(2,&b)] {
            if let Some(ch) = chars.get(offset) {
                bytes += &event("response.function_call_arguments.delta", json!({"item_id":items[index]["id"],
                    "output_index":index,"call_id":items[index]["call_id"],"delta":ch.to_string()}));
            }
        }
    }
    for index in if reverse_done {[2,1]} else {[1,2]} {
        bytes += &event("response.function_call_arguments.done", json!({"item_id":items[index]["id"],"output_index":index,
            "call_id":items[index]["call_id"],"name":items[index]["name"],"arguments":items[index]["arguments"]}));
        bytes += &event("response.output_item.done", json!({"output_index":index,"item":items[index]}));
    }
    let mut end = response(); end["id"] = json!("parallel-native-0"); end["output"] = items;
    Ok(bytes + &frame("response.completed", &end))
}

fn body(namespaced: bool, streaming: bool) -> Value {
    json!({"model":"p12-test-model","input":"Read two independent seeds.","tools":declarations(namespaced),
        "parallel_tool_calls":true,"tool_choice":"auto","reasoning":{"summary":"auto"},"stream":streaming})
}

#[actix_web::test]
async fn public_build_parallel_flat_functions_reach_receiver() -> TestResult {
    let peer = ModelPeer::start_wire(false, wire(0, false, false, false)?)?;
    let fixture = fixture_for(namespaces::transport(&peer, 7)?, false, true, |p|p.build_parallel_local_controlled=true)?;
    let recording = Recording::start(&fixture, false)?;
    let (url, server) = namespaces::listener(&fixture)?;
    let (status, bytes) = namespaces::request(&fixture, &url, &body(false, false)).await?;
    assert_eq!(status, 200, "{}",String::from_utf8_lossy(&bytes));
    assert_eq!(namespaces::terminal(&bytes, false)?["output"], output(0,false));
    assert_eq!(peer.accepted.load(Ordering::SeqCst),1);
    assert_eq!(peer.requests.lock().map_err(|_|"receiver")?.len(),1);
    assert_eq!(fixture.events.attempts()?,1);
    server.stop(false).await;
    let database = recording.finish(&fixture,0).await?;
    namespaces::assert_recorded(&database,1).await?;
    println!("CPAR62_PARALLEL_RECEIPT {}",json!({"case":"two-flat-functions","status":status,"receiver":1,"attempts":1,"usage":1,"ledger":1,"cost":"UNKNOWN"}));
    Ok(())
}

#[actix_web::test]
async fn public_build_parallel_conflicts_never_complete_or_store_or_retry() -> TestResult {
    let valid = wire(0,false,true,false)?;
    let mut terminal = response(); terminal["id"]=json!("parallel-native-0"); terminal["output"]=output(0,false);
    terminal["output"][2]["arguments"]=json!(r#"{"changed":true}"#);
    let prefix=valid.split("event: response.completed").next().ok_or("prefix")?;
    let bad = prefix.to_owned()+&frame("response.completed",&terminal);
    let peer=ModelPeer::start_wire(true,bad)?;
    let fixture=fixture_for(namespaces::transport(&peer,7)?,true,true,|p|p.build_parallel_local_controlled=true)?;
    let recording=Recording::start(&fixture,false)?;
    let (url,server)=namespaces::listener(&fixture)?;
    let mut request=body(false,true); request["store"]=json!(true);
    let (status,bytes)=namespaces::request(&fixture,&url,&request).await?;
    assert_eq!(status,200);
    let frames=public_frames(&bytes)?;
    println!("CPAR62_PARALLEL_BARRIER_RED {}",json!({"frames":frames,"receiver":peer.requests.lock().map_err(|_|"receiver")?.len(),"attempts":fixture.events.attempts()?}));
    assert_eq!(frames.iter().filter(|v|v["type"]=="response.failed").count(),1);
    assert!(frames.iter().all(|v|v["type"]!="response.completed"));
    assert!(frames.iter().all(|v|v["type"]!="response.function_call_arguments.done"));
    assert!(frames.iter().all(|v|v["type"]!="response.output_item.done" || v["item"]["type"]!="function_call"));
    server.stop(false).await;
    recording.finish(&fixture,0).await?;
    Ok(())
}
