> For the complete documentation index, see [llms.txt](/llms.txt). Markdown versions of documentation pages are available by appending `.md` to the page URL.

## Create a model response

**post** `/responses`

Creates a model response. Provide [text](/api/docs/guides/text) or
[image](/api/docs/guides/images-vision) inputs to generate [text](/api/docs/guides/text)
or [JSON](/api/docs/guides/structured-outputs) outputs. Have the model call
your own [custom code](/api/docs/guides/function-calling) or use built-in
[tools](/api/docs/guides/tools) like [web search](/api/docs/guides/tools-web-search)
or [file search](/api/docs/guides/tools-file-search) to use your own data
as input for the model's response.

### Body Parameters

- `access_programs: optional object { cyber }`

  Domain-specific access programs to use for this request.

  - `cyber: optional "standard" or "daybreak_blue" or "daybreak_red"`

    The Cyber access program to use for this request. Supported values are `standard`, `daybreak_blue`, and `daybreak_red`. If omitted, the API resolves the program from the model's Cyber tier and your organization and project access, subject to model-specific eligibility restrictions. By default, models without a Cyber tier use Standard. Blue-tier models use Daybreak Blue when authorized; otherwise they fall back to Standard unless the model requires Daybreak access. Red-tier models use Daybreak Red and require authorization. Requests that require unavailable Daybreak access return 403. An implicit Standard fallback is represented by null in the response's access_programs field, rather than an explicit Standard selection.

    - `"standard"`

    - `"daybreak_blue"`

    - `"daybreak_red"`

- `background: optional boolean or null`

  Whether to run the model response in the background.
  [Learn more](/api/docs/guides/background).

- `context_management: optional array of object { type, compact_threshold }  or null`

  Context management configuration for this request.

  - `type: string`

    The context management entry type. Currently only 'compaction' is supported.

  - `compact_threshold: optional number or null`

    Token threshold at which compaction should be triggered for this entry.

- `conversation: optional string or ResponseConversationParam or null`

  The conversation that this response belongs to. Items from this conversation are prepended to `input_items` for this response request.
  Input items and output items from this response are automatically added to this conversation after this response completes.

  - `ConversationID = string`

    The unique ID of the conversation.

  - `ResponseConversationParam object { id }`

    The conversation that this response belongs to.

    - `id: string`

      The unique ID of the conversation.

- `include: optional array of ResponseIncludable or null`

  Specify additional output data to include in the model response. Currently supported values are:

  - `web_search_call.action.sources`: Include the sources of the web search tool call.
  - `code_interpreter_call.outputs`: Includes the outputs of python code execution in code interpreter tool call items.
  - `computer_call_output.output.image_url`: Include image urls from the computer call output.
  - `file_search_call.results`: Include the search results of the file search tool call.
  - `message.input_image.image_url`: Include image urls from the input message.
  - `message.output_text.logprobs`: Include logprobs with assistant messages.
  - `reasoning.encrypted_content`: Includes an encrypted version of reasoning tokens in reasoning item outputs. This enables reasoning items to be used in multi-turn conversations when using the Responses API statelessly (like when the `store` parameter is set to `false`, or when an organization is enrolled in the zero data retention program).

  - `"file_search_call.results"`

  - `"web_search_call.results"`

  - `"web_search_call.action.sources"`

  - `"message.input_image.image_url"`

  - `"computer_call_output.output.image_url"`

  - `"code_interpreter_call.outputs"`

  - `"reasoning.encrypted_content"`

  - `"message.output_text.logprobs"`

- `input: optional string or array of EasyInputMessage or Message { content, role, status, type }  or ResponseOutputMessage or 30 more`

  Text, image, or file inputs to the model, used to generate a response.

  Learn more:

  - [Text inputs and outputs](/api/docs/guides/text)
  - [Image inputs](/api/docs/guides/images-vision)
  - [File inputs](/api/docs/guides/file-inputs)
  - [Conversation state](/api/docs/guides/conversation-state)
  - [Function calling](/api/docs/guides/function-calling)

  - `TextInput = string`

    A text input to the model, equivalent to a text input with the
    `user` role.

  - `InputItemList = array of EasyInputMessage or Message { content, role, status, type }  or ResponseOutputMessage or 30 more`

    A list of one or many input items to the model, containing
    different content types.

    - `EasyInputMessage object { content, role, phase, type }`

      A message input to the model with a role indicating instruction following
      hierarchy. Instructions given with the `developer` or `system` role take
      precedence over instructions given with the `user` role. Messages with the
      `assistant` role are presumed to have been generated by the model in previous
      interactions.

      - `content: string or ResponseInputMessageContentList`

        Text, image, or audio input to the model, used to generate a response.
        Can also contain previous assistant responses.

        - `TextInput = string`

          A text input to the model.

        - `ResponseInputMessageContentList = array of ResponseInputContent`

          A list of one or many input items to the model, containing different content
          types.

          - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

            A text input to the model.

            - `text: string`

              The text input to the model.

            - `type: "input_text"`

              The type of the input item. Always `input_text`.

              - `"input_text"`

            - `prompt_cache_breakpoint: optional object { mode }`

              Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

              - `mode: "explicit"`

                The breakpoint mode. Always `explicit`.

                - `"explicit"`

          - `ResponseInputImage object { detail, type, file_id, 2 more }`

            An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

            - `detail: ImageDetail`

              The detail level of the image to be sent to the model. One of `high`, `low`, `auto`, or `original`. Defaults to `auto`.

              - `"low"`

              - `"high"`

              - `"auto"`

              - `"original"`

            - `type: "input_image"`

              The type of the input item. Always `input_image`.

              - `"input_image"`

            - `file_id: optional string or null`

              The ID of the file to be sent to the model.

            - `image_url: optional string or null`

              The URL of the image to be sent to the model. A fully qualified URL or base64 encoded image in a data URL.

            - `prompt_cache_breakpoint: optional object { mode }`

              Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

              - `mode: "explicit"`

                The breakpoint mode. Always `explicit`.

                - `"explicit"`

          - `ResponseInputFile object { type, detail, file_data, 4 more }`

            A file input to the model.

            - `type: "input_file"`

              The type of the input item. Always `input_file`.

              - `"input_file"`

            - `detail: optional "auto" or "low" or "high"`

              The detail level of the file to be sent to the model. Use `auto` to let the system select the detail level; for GPT-5.6 and later models, `auto` uses high-quality rendering, which may increase input token usage. Use `low` for lower-cost rendering, or `high` to render the file at higher quality. Defaults to `auto`.

              - `"auto"`

              - `"low"`

              - `"high"`

            - `file_data: optional string`

              The content of the file to be sent to the model.

            - `file_id: optional string or null`

              The ID of the file to be sent to the model.

            - `file_url: optional string`

              The URL of the file to be sent to the model.

            - `filename: optional string`

              The name of the file to be sent to the model.

            - `prompt_cache_breakpoint: optional object { mode }`

              Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

              - `mode: "explicit"`

                The breakpoint mode. Always `explicit`.

                - `"explicit"`

      - `role: "user" or "assistant" or "system" or "developer"`

        The role of the message input. One of `user`, `assistant`, `system`, or
        `developer`.

        - `"user"`

        - `"assistant"`

        - `"system"`

        - `"developer"`

      - `phase: optional "commentary" or "final_answer" or null`

        Labels an `assistant` message as intermediate commentary (`commentary`) or the final answer (`final_answer`).
        For models like `gpt-5.3-codex` and beyond, when sending follow-up requests, preserve and resend
        phase on all assistant messages — dropping it can degrade performance. Not used for user messages.

        - `"commentary"`

        - `"final_answer"`

      - `type: optional "message"`

        The type of the message input. Always `message`.

        - `"message"`

    - `Message object { content, role, status, type }`

      A message input to the model with a role indicating instruction following
      hierarchy. Instructions given with the `developer` or `system` role take
      precedence over instructions given with the `user` role.

      - `content: ResponseInputMessageContentList`

        A list of one or many input items to the model, containing different content
        types.

      - `role: "user" or "system" or "developer"`

        The role of the message input. One of `user`, `system`, or `developer`.

        - `"user"`

        - `"system"`

        - `"developer"`

      - `status: optional "in_progress" or "completed" or "incomplete"`

        The status of item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: optional "message"`

        The type of the message input. Always set to `message`.

        - `"message"`

    - `ResponseOutputMessage object { id, content, role, 3 more }`

      An output message from the model.

      - `id: string`

        The unique ID of the output message.

      - `content: array of ResponseOutputText or ResponseOutputRefusal`

        The content of the output message.

        - `ResponseOutputText object { annotations, logprobs, text, type }`

          A text output from the model.

          - `annotations: array of FileCitation { file_id, filename, index, type }  or URLCitation { end_index, start_index, title, 2 more }  or ContainerFileCitation { container_id, end_index, file_id, 3 more }  or FilePath { file_id, index, type }`

            The annotations of the text output.

            - `FileCitation object { file_id, filename, index, type }`

              A citation to a file.

              - `file_id: string`

                The ID of the file.

              - `filename: string`

                The filename of the file cited.

              - `index: number`

                The index in the output text at which to insert the file citation.

              - `type: "file_citation"`

                The type of the file citation. Always `file_citation`.

                - `"file_citation"`

            - `URLCitation object { end_index, start_index, title, 2 more }`

              A citation for a web resource used to generate a model response.

              - `end_index: number`

                The index of the last character of the URL citation in the message.

              - `start_index: number`

                The index of the first character of the URL citation in the message.

              - `title: string`

                The title of the web resource.

              - `type: "url_citation"`

                The type of the URL citation. Always `url_citation`.

                - `"url_citation"`

              - `url: string`

                The URL of the web resource.

            - `ContainerFileCitation object { container_id, end_index, file_id, 3 more }`

              A citation for a container file used to generate a model response.

              - `container_id: string`

                The ID of the container file.

              - `end_index: number`

                The index of the last character of the container file citation in the message.

              - `file_id: string`

                The ID of the file.

              - `filename: string`

                The filename of the container file cited.

              - `start_index: number`

                The index of the first character of the container file citation in the message.

              - `type: "container_file_citation"`

                The type of the container file citation. Always `container_file_citation`.

                - `"container_file_citation"`

            - `FilePath object { file_id, index, type }`

              A path to a file.

              - `file_id: string`

                The ID of the file.

              - `index: number`

                The index of the file in the list of files.

              - `type: "file_path"`

                The type of the file path. Always `file_path`.

                - `"file_path"`

          - `logprobs: array of object { token, bytes, logprob, top_logprobs }`

            - `token: string`

            - `bytes: array of number`

            - `logprob: number`

            - `top_logprobs: array of object { token, bytes, logprob }`

              - `token: string`

              - `bytes: array of number`

              - `logprob: number`

          - `text: string`

            The text output from the model.

          - `type: "output_text"`

            The type of the output text. Always `output_text`.

            - `"output_text"`

        - `ResponseOutputRefusal object { refusal, type }`

          A refusal from the model.

          - `refusal: string`

            The refusal explanation from the model.

          - `type: "refusal"`

            The type of the refusal. Always `refusal`.

            - `"refusal"`

      - `role: "assistant"`

        The role of the output message. Always `assistant`.

        - `"assistant"`

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the message input. One of `in_progress`, `completed`, or
        `incomplete`. Populated when input items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "message"`

        The type of the output message. Always `message`.

        - `"message"`

      - `phase: optional "commentary" or "final_answer" or null`

        Labels an `assistant` message as intermediate commentary (`commentary`) or the final answer (`final_answer`).
        For models like `gpt-5.3-codex` and beyond, when sending follow-up requests, preserve and resend
        phase on all assistant messages — dropping it can degrade performance. Not used for user messages.

        - `"commentary"`

        - `"final_answer"`

    - `FileSearchCall object { id, queries, status, 2 more }`

      The results of a file search tool call. See the
      [file search guide](/api/docs/guides/tools-file-search) for more information.

      - `id: string`

        The unique ID of the file search tool call.

      - `queries: array of string`

        The queries used to search for files.

      - `status: "in_progress" or "searching" or "completed" or 2 more`

        The status of the file search tool call. One of `in_progress`,
        `searching`, `incomplete` or `failed`,

        - `"in_progress"`

        - `"searching"`

        - `"completed"`

        - `"incomplete"`

        - `"failed"`

      - `type: "file_search_call"`

        The type of the file search tool call. Always `file_search_call`.

        - `"file_search_call"`

      - `results: optional array of object { attributes, file_id, filename, 2 more }  or null`

        The results of the file search tool call.

        - `attributes: optional map[string or number or boolean] or null`

          Set of 16 key-value pairs that can be attached to an object. This can be
          useful for storing additional information about the object in a structured
          format, and querying for objects via API or the dashboard. Keys are strings
          with a maximum length of 64 characters. Values are strings with a maximum
          length of 512 characters, booleans, or numbers.

          - `string`

          - `number`

          - `boolean`

        - `file_id: optional string`

          The unique ID of the file.

        - `filename: optional string`

          The name of the file.

        - `score: optional number`

          The relevance score of the file - a value between 0 and 1.

        - `text: optional string`

          The text that was retrieved from the file.

    - `ComputerCall object { id, call_id, pending_safety_checks, 4 more }`

      A tool call to a computer use tool. See the
      [computer use guide](/api/docs/guides/tools-computer-use) for more information.

      - `id: string`

        The unique ID of the computer call.

      - `call_id: string`

        An identifier used when responding to the tool call with output.

      - `pending_safety_checks: array of object { id, code, message }`

        The pending safety checks for the computer call.

        - `id: string`

          The ID of the pending safety check.

        - `code: optional string or null`

          The type of the pending safety check.

        - `message: optional string or null`

          Details about the pending safety check.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "computer_call"`

        The type of the computer call. Always `computer_call`.

        - `"computer_call"`

      - `action: optional ComputerAction`

        A click action.

        - `Click object { button, type, x, 2 more }`

          A click action.

          - `button: "left" or "right" or "wheel" or 2 more`

            Indicates which mouse button was pressed during the click. One of `left`, `right`, `wheel`, `back`, or `forward`.

            - `"left"`

            - `"right"`

            - `"wheel"`

            - `"back"`

            - `"forward"`

          - `type: "click"`

            Specifies the event type. For a click action, this property is always `click`.

            - `"click"`

          - `x: number`

            The x-coordinate where the click occurred.

          - `y: number`

            The y-coordinate where the click occurred.

          - `keys: optional array of string or null`

            The keys being held while clicking.

        - `DoubleClick object { keys, type, x, y }`

          A double click action.

          - `keys: array of string or null`

            The keys being held while double-clicking.

          - `type: "double_click"`

            Specifies the event type. For a double click action, this property is always set to `double_click`.

            - `"double_click"`

          - `x: number`

            The x-coordinate where the double click occurred.

          - `y: number`

            The y-coordinate where the double click occurred.

        - `Drag object { path, type, keys }`

          A drag action.

          - `path: array of object { x, y }`

            An array of coordinates representing the path of the drag action. Coordinates will appear as an array of objects, eg

            ```
            [
              { x: 100, y: 200 },
              { x: 200, y: 300 }
            ]
            ```

            - `x: number`

              The x-coordinate.

            - `y: number`

              The y-coordinate.

          - `type: "drag"`

            Specifies the event type. For a drag action, this property is always set to `drag`.

            - `"drag"`

          - `keys: optional array of string or null`

            The keys being held while dragging the mouse.

        - `Keypress object { keys, type }`

          A collection of keypresses the model would like to perform.

          - `keys: array of string`

            The combination of keys the model is requesting to be pressed. This is an array of strings, each representing a key.

          - `type: "keypress"`

            Specifies the event type. For a keypress action, this property is always set to `keypress`.

            - `"keypress"`

        - `Move object { type, x, y, keys }`

          A mouse move action.

          - `type: "move"`

            Specifies the event type. For a move action, this property is always set to `move`.

            - `"move"`

          - `x: number`

            The x-coordinate to move to.

          - `y: number`

            The y-coordinate to move to.

          - `keys: optional array of string or null`

            The keys being held while moving the mouse.

        - `Screenshot object { type }`

          A screenshot action.

          - `type: "screenshot"`

            Specifies the event type. For a screenshot action, this property is always set to `screenshot`.

            - `"screenshot"`

        - `Scroll object { scroll_x, scroll_y, type, 3 more }`

          A scroll action.

          - `scroll_x: number`

            The horizontal scroll distance.

          - `scroll_y: number`

            The vertical scroll distance.

          - `type: "scroll"`

            Specifies the event type. For a scroll action, this property is always set to `scroll`.

            - `"scroll"`

          - `x: number`

            The x-coordinate where the scroll occurred.

          - `y: number`

            The y-coordinate where the scroll occurred.

          - `keys: optional array of string or null`

            The keys being held while scrolling.

        - `Type object { text, type }`

          An action to type in text.

          - `text: string`

            The text to type.

          - `type: "type"`

            Specifies the event type. For a type action, this property is always set to `type`.

            - `"type"`

        - `Wait object { type }`

          A wait action.

          - `type: "wait"`

            Specifies the event type. For a wait action, this property is always set to `wait`.

            - `"wait"`

      - `actions: optional ComputerActionList`

        Flattened batched actions for `computer_use`. Each action includes an
        `type` discriminator and action-specific fields.

        - `Click object { button, type, x, 2 more }`

          A click action.

        - `DoubleClick object { keys, type, x, y }`

          A double click action.

        - `Drag object { path, type, keys }`

          A drag action.

        - `Keypress object { keys, type }`

          A collection of keypresses the model would like to perform.

        - `Move object { type, x, y, keys }`

          A mouse move action.

        - `Screenshot object { type }`

          A screenshot action.

        - `Scroll object { scroll_x, scroll_y, type, 3 more }`

          A scroll action.

        - `Type object { text, type }`

          An action to type in text.

        - `Wait object { type }`

          A wait action.

    - `ComputerCallOutput object { call_id, output, type, 3 more }`

      The output of a computer tool call.

      - `call_id: string`

        The ID of the computer tool call that produced the output.

      - `output: ResponseComputerToolCallOutputScreenshot`

        A computer screenshot image used with the computer use tool.

        - `type: "computer_screenshot"`

          Specifies the event type. For a computer screenshot, this property is
          always set to `computer_screenshot`.

          - `"computer_screenshot"`

        - `file_id: optional string`

          The identifier of an uploaded file that contains the screenshot.

        - `image_url: optional string`

          The URL of the screenshot image.

      - `type: "computer_call_output"`

        The type of the computer tool call output. Always `computer_call_output`.

        - `"computer_call_output"`

      - `id: optional string or null`

        The ID of the computer tool call output.

      - `acknowledged_safety_checks: optional array of object { id, code, message }  or null`

        The safety checks reported by the API that have been acknowledged by the developer.

        - `id: string`

          The ID of the pending safety check.

        - `code: optional string or null`

          The type of the pending safety check.

        - `message: optional string or null`

          Details about the pending safety check.

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the message input. One of `in_progress`, `completed`, or `incomplete`. Populated when input items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `WebSearchCall object { id, status, type, action }`

      The results of a web search tool call. See the
      [web search guide](/api/docs/guides/tools-web-search) for more information.

      - `id: string`

        The unique ID of the web search tool call.

      - `status: "in_progress" or "searching" or "completed" or 2 more`

        The status of the web search tool call.

        - `"in_progress"`

        - `"searching"`

        - `"completed"`

        - `"failed"`

        - `"incomplete"`

      - `type: "web_search_call"`

        The type of the web search tool call. Always `web_search_call`.

        - `"web_search_call"`

      - `action: optional Search { type, queries, query, sources }  or OpenPage { type, url }  or FindInPage { pattern, type, url }`

        An object describing the specific action taken in this web search call.
        Includes details on how the model used the web (search, open_page, find_in_page).

        - `Search object { type, queries, query, sources }`

          Action type "search" - Performs a web search query.

          - `type: "search"`

            The action type.

            - `"search"`

          - `queries: optional array of string`

            The search queries.

          - `query: optional string`

            The search query.

          - `sources: optional array of object { type, url }`

            The sources used in the search.

            - `type: "url"`

              The type of source. Always `url`.

              - `"url"`

            - `url: string`

              The URL of the source.

        - `OpenPage object { type, url }`

          Action type "open_page" - Opens a specific URL from search results.

          - `type: "open_page"`

            The action type.

            - `"open_page"`

          - `url: optional string or null`

            The URL opened by the model.

        - `FindInPage object { pattern, type, url }`

          Action type "find_in_page": Searches for a pattern within a loaded page.

          - `pattern: string`

            The pattern or text to search for within the page.

          - `type: "find_in_page"`

            The action type.

            - `"find_in_page"`

          - `url: optional string or null`

            The URL of the page searched for the pattern, when available.

    - `FunctionCall object { arguments, call_id, name, 6 more }`

      A tool call to run a function. See the
      [function calling guide](/api/docs/guides/function-calling) for more information.

      - `arguments: string`

        A JSON string of the arguments to pass to the function.

      - `call_id: string`

        The unique ID of the function tool call generated by the model.

      - `name: string`

        The name of the function to run.

      - `type: "function_call"`

        The type of the function tool call. Always `function_call`.

        - `"function_call"`

      - `id: optional string`

        The unique ID of the function tool call.

      - `async: optional boolean`

        Whether the function tool call runs asynchronously.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `namespace: optional string`

        The namespace of the function to run.

      - `status: optional "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `FunctionCallOutput object { output, type, id, 5 more }`

      The output of a function tool call.

      - `output: string or array of ResponseInputTextContent or ResponseInputImageContent or ResponseInputFileContent`

        Text, image, or file output of the function tool call.

        - `string`

          A JSON string of the output of the function tool call.

        - `array of ResponseInputTextContent or ResponseInputImageContent or ResponseInputFileContent`

          An array of content outputs (text, image, file) for the function tool call.

          - `ResponseInputTextContent object { text, type, prompt_cache_breakpoint }`

            A text input to the model.

            - `text: string`

              The text input to the model.

            - `type: "input_text"`

              The type of the input item. Always `input_text`.

              - `"input_text"`

            - `prompt_cache_breakpoint: optional object { mode, ttl }  or null`

              Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

              - `mode: "explicit"`

                The breakpoint mode. Always `explicit`.

                - `"explicit"`

              - `ttl: optional "30m" or "12h"`

                The minimum lifetime of this cache breakpoint. Defaults to the request TTL.

                - `"30m"`

                - `"12h"`

          - `ResponseInputImageContent object { type, detail, file_id, 2 more }`

            An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision)

            - `type: "input_image"`

              The type of the input item. Always `input_image`.

              - `"input_image"`

            - `detail: optional ImageDetail or null`

              The detail level of the image to be sent to the model. One of `high`, `low`, `auto`, or `original`. Defaults to `auto`.

            - `file_id: optional string or null`

              The ID of the file to be sent to the model.

            - `image_url: optional string or null`

              The URL of the image to be sent to the model. A fully qualified URL or base64 encoded image in a data URL.

            - `prompt_cache_breakpoint: optional object { mode, ttl }  or null`

              Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

              - `mode: "explicit"`

                The breakpoint mode. Always `explicit`.

                - `"explicit"`

              - `ttl: optional "30m" or "12h"`

                The minimum lifetime of this cache breakpoint. Defaults to the request TTL.

                - `"30m"`

                - `"12h"`

          - `ResponseInputFileContent object { type, detail, file_data, 4 more }`

            A file input to the model.

            - `type: "input_file"`

              The type of the input item. Always `input_file`.

              - `"input_file"`

            - `detail: optional "auto" or "low" or "high"`

              The detail level of the file to be sent to the model. Use `auto` to let the system select the detail level; for GPT-5.6 and later models, `auto` uses high-quality rendering, which may increase input token usage. Use `low` for lower-cost rendering, or `high` to render the file at higher quality. Defaults to `auto`.

              - `"auto"`

              - `"low"`

              - `"high"`

            - `file_data: optional string or null`

              The base64-encoded data of the file to be sent to the model.

            - `file_id: optional string or null`

              The ID of the file to be sent to the model.

            - `file_url: optional string or null`

              The URL of the file to be sent to the model.

            - `filename: optional string or null`

              The name of the file to be sent to the model.

            - `prompt_cache_breakpoint: optional object { mode, ttl }  or null`

              Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

              - `mode: "explicit"`

                The breakpoint mode. Always `explicit`.

                - `"explicit"`

              - `ttl: optional "30m" or "12h"`

                The minimum lifetime of this cache breakpoint. Defaults to the request TTL.

                - `"30m"`

                - `"12h"`

      - `type: "function_call_output"`

        The type of the function tool call output. Always `function_call_output`.

        - `"function_call_output"`

      - `id: optional string or null`

        The unique ID of the function tool call output. Populated when this item is returned via API.

      - `call_id: optional string or null`

        The unique ID of the function tool call generated by the model.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

      - `name: optional string or null`

        The name of the tool that produced the output.

      - `namespace: optional string or null`

        The namespace of the tool that produced the output.

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the item. One of `in_progress`, `completed`, or `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `ToolSearchCall object { arguments, type, id, 3 more }`

      - `arguments: unknown`

        The arguments supplied to the tool search call.

      - `type: "tool_search_call"`

        The item type. Always `tool_search_call`.

        - `"tool_search_call"`

      - `id: optional string or null`

        The unique ID of this tool search call.

      - `call_id: optional string or null`

        The unique ID of the tool search call generated by the model.

      - `execution: optional "server" or "client"`

        Whether tool search was executed by the server or by the client.

        - `"server"`

        - `"client"`

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the tool search call.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `ToolSearchOutput object { tools, type, id, 3 more }`

      - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

        The loaded tool definitions returned by the tool search output.

        - `Function object { name, parameters, strict, 6 more }`

          Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

          - `name: string`

            The name of the function to call.

          - `parameters: map[unknown] or null`

            A JSON schema object describing the parameters of the function.

          - `strict: boolean or null`

            Whether strict parameter validation is enforced for this function tool.

          - `type: "function"`

            The type of the function tool. Always `function`.

            - `"function"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

          - `defer_loading: optional boolean`

            Whether this function is deferred and loaded via tool search.

          - `description: optional string or null`

            A description of the function. Used by the model to determine whether or not to call the function.

          - `output_schema: optional map[unknown] or null`

            A JSON schema object describing the JSON value encoded in string outputs for this function.

        - `FileSearch object { type, vector_store_ids, filters, 2 more }`

          A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

          - `type: "file_search"`

            The type of the file search tool. Always `file_search`.

            - `"file_search"`

          - `vector_store_ids: array of string`

            The IDs of the vector stores to search.

          - `filters: optional ComparisonFilter or CompoundFilter or null`

            A filter to apply.

            - `ComparisonFilter object { key, type, value }`

              A filter used to compare a specified attribute key to a given value using a defined comparison operation.

              - `key: string`

                The key to compare against the value.

              - `type: "eq" or "ne" or "gt" or 5 more`

                Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`, `nin`.

                - `eq`: equals
                - `ne`: not equal
                - `gt`: greater than
                - `gte`: greater than or equal
                - `lt`: less than
                - `lte`: less than or equal
                - `in`: in
                - `nin`: not in

                - `"eq"`

                - `"ne"`

                - `"gt"`

                - `"gte"`

                - `"lt"`

                - `"lte"`

                - `"in"`

                - `"nin"`

              - `value: string or number or boolean or array of string or number`

                The value to compare against the attribute key; supports string, number, or boolean types.

                - `string`

                - `number`

                - `boolean`

                - `array of string or number`

                  - `string`

                  - `number`

            - `CompoundFilter object { filters, type }`

              Combine multiple filters using `and` or `or`.

              - `filters: array of ComparisonFilter or CompoundFilter`

                Array of filters to combine. Items can be `ComparisonFilter` or `CompoundFilter`.

                - `ComparisonFilter object { key, type, value }`

                  A filter used to compare a specified attribute key to a given value using a defined comparison operation.

                - `CompoundFilter object { filters, type }`

                  Combine multiple filters using `and` or `or`.

              - `type: "and" or "or"`

                Type of operation: `and` or `or`.

                - `"and"`

                - `"or"`

          - `max_num_results: optional number`

            The maximum number of results to return. This number should be between 1 and 50 inclusive.

          - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

            Ranking options for search.

            - `hybrid_search: optional object { embedding_weight, text_weight }`

              Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

              - `embedding_weight: number`

                The weight of the embedding in the reciprocal ranking fusion.

              - `text_weight: number`

                The weight of the text in the reciprocal ranking fusion.

            - `ranker: optional "auto" or "default-2024-11-15"`

              The ranker to use for the file search.

              - `"auto"`

              - `"default-2024-11-15"`

            - `score_threshold: optional number`

              The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

        - `Computer object { type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `type: "computer"`

            The type of the computer tool. Always `computer`.

            - `"computer"`

        - `ComputerUsePreview object { display_height, display_width, environment, type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `display_height: number`

            The height of the computer display.

          - `display_width: number`

            The width of the computer display.

          - `environment: "windows" or "mac" or "linux" or 2 more`

            The type of computer environment to control.

            - `"windows"`

            - `"mac"`

            - `"linux"`

            - `"ubuntu"`

            - `"browser"`

          - `type: "computer_use_preview"`

            The type of the computer use tool. Always `computer_use_preview`.

            - `"computer_use_preview"`

        - `WebSearch object { type, external_web_access, filters, 2 more }`

          Search the Internet for sources related to the prompt. Learn more about the
          [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search" or "web_search_2025_08_26"`

            The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

            - `"web_search"`

            - `"web_search_2025_08_26"`

          - `external_web_access: optional boolean`

            Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

          - `filters: optional object { allowed_domains }  or null`

            Filters for the search.

            - `allowed_domains: optional array of string or null`

              Allowed domains for the search. If not provided, all domains are allowed.
              Subdomains of the provided domains are allowed as well.

              Example: `["pubmed.ncbi.nlm.nih.gov"]`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { city, country, region, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the
            United States. To avoid this fallback, pass `{"type": "approximate"}` without
            location fields. To localize results, provide the relevant location fields.

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

            - `type: optional "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

        - `Mcp object { server_label, type, allowed_callers, 9 more }`

          Give the model access to additional tools via remote Model Context Protocol
          (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

          - `server_label: string`

            A label for this MCP server, used to identify it in tool calls.

          - `type: "mcp"`

            The type of the MCP tool. Always `mcp`.

            - `"mcp"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

            List of allowed tool names or a filter object.

            - `McpAllowedTools = array of string`

              A string array of allowed tool names

            - `McpToolFilter object { read_only, tool_names }`

              A filter object to specify which tools are allowed.

              - `read_only: optional boolean`

                Indicates whether or not a tool modifies data or is read-only. If an
                MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                it will match this filter.

              - `tool_names: optional array of string`

                List of allowed tool names.

          - `authorization: optional string`

            An OAuth access token that can be used with a remote MCP server, either
            with a custom MCP server URL or a service connector. Your application
            must handle the OAuth authorization flow and provide the token here.

          - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

            Identifier for service connectors, like those available in ChatGPT. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
            about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

            This field is deprecated for models released after September 1, 2026.
            Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
            connect through a Secure MCP Tunnel.

            Currently supported `connector_id` values are:

            - Dropbox: `connector_dropbox`
            - Gmail: `connector_gmail`
            - Google Calendar: `connector_googlecalendar`
            - Google Drive: `connector_googledrive`
            - Microsoft Teams: `connector_microsoftteams`
            - Outlook Calendar: `connector_outlookcalendar`
            - Outlook Email: `connector_outlookemail`
            - SharePoint: `connector_sharepoint`

            - `"connector_dropbox"`

            - `"connector_gmail"`

            - `"connector_googlecalendar"`

            - `"connector_googledrive"`

            - `"connector_microsoftteams"`

            - `"connector_outlookcalendar"`

            - `"connector_outlookemail"`

            - `"connector_sharepoint"`

          - `defer_loading: optional boolean`

            Whether this MCP tool is deferred and discovered via tool search.

          - `headers: optional map[string] or null`

            Optional HTTP headers to send to the MCP server. Use for authentication
            or other purposes.

          - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

            Specify which of the MCP server's tools require approval.

            - `McpToolApprovalFilter object { always, never }`

              Specify which of the MCP server's tools require approval. Can be
              `always`, `never`, or a filter object associated with tools
              that require approval.

              - `always: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

              - `never: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

            - `McpToolApprovalSetting = "always" or "never"`

              Specify a single approval policy for all tools. One of `always` or
              `never`. When set to `always`, all tools will require approval. When
              set to `never`, all tools will not require approval.

              - `"always"`

              - `"never"`

          - `server_description: optional string`

            Optional description of the MCP server, used to provide more context.

          - `server_url: optional string`

            The URL for the MCP server. One of `server_url`, `connector_id`, or
            `tunnel_id` must be provided.

          - `tunnel_id: optional string`

            The Secure MCP Tunnel ID to use instead of a direct server URL. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided.

        - `CodeInterpreter object { container, type, allowed_callers }`

          A tool that runs Python code to help generate a response to a prompt.

          - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

            The code interpreter container. Can be a container ID or an object that
            specifies uploaded file IDs to make available to your code, along with an
            optional `memory_limit` setting.

            - `string`

              The container ID.

            - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

              Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

              - `type: "auto"`

                Always `auto`.

                - `"auto"`

              - `file_ids: optional array of string`

                An optional list of uploaded files to make available to your code.

              - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                The memory limit for the code interpreter container.

                - `"1g"`

                - `"4g"`

                - `"16g"`

                - `"64g"`

              - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                Network access policy for the container.

                - `ContainerNetworkPolicyDisabled object { type }`

                  - `type: "disabled"`

                    Disable outbound network access. Always `disabled`.

                    - `"disabled"`

                - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

                  - `allowed_domains: array of string`

                    A list of allowed domains when type is `allowlist`.

                  - `type: "allowlist"`

                    Allow outbound network access only to specified domains. Always `allowlist`.

                    - `"allowlist"`

                  - `domain_secrets: optional array of ContainerNetworkPolicyDomainSecret`

                    Optional domain-scoped secrets for allowlisted domains.

                    - `domain: string`

                      The domain associated with the secret.

                    - `name: string`

                      The name of the secret to inject for the domain.

                    - `value: string`

                      The secret value to inject for the domain.

          - `type: "code_interpreter"`

            The type of the code interpreter tool. Always `code_interpreter`.

            - `"code_interpreter"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

        - `ProgrammaticToolCalling object { type }`

          - `type: "programmatic_tool_calling"`

            The type of the tool. Always `programmatic_tool_calling`.

            - `"programmatic_tool_calling"`

        - `ImageGeneration object { type, action, background, 9 more }`

          A tool that generates images using the GPT image models.

          - `type: "image_generation"`

            The type of the image generation tool. Always `image_generation`.

            - `"image_generation"`

          - `action: optional "generate" or "edit" or "auto"`

            Whether to generate a new image or edit an existing image. Default: `auto`.

            - `"generate"`

            - `"edit"`

            - `"auto"`

          - `background: optional "transparent" or "opaque" or "auto"`

            Set the background of the generated image. One of `transparent`, `opaque`,
            or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
            their `2026-09-08` snapshots, support `opaque` and `transparent`
            backgrounds. Transparent backgrounds are available for supported GPT Image
            models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
            preview. When using `transparent`, set the output format to `png` or `webp`.
            Default: `auto`.

            - `"transparent"`

            - `"opaque"`

            - `"auto"`

          - `input_fidelity: optional "high" or "low" or null`

            Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

            - `"high"`

            - `"low"`

          - `input_image_mask: optional object { file_id, image_url }`

            Optional mask for inpainting. Contains `image_url`
            (string, optional) and `file_id` (string, optional).

            - `file_id: optional string`

              File ID for the mask image.

            - `image_url: optional string`

              Base64-encoded mask image.

          - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

            The image generation model to use. One of `gpt-image-1`,
            `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
            `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
            `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
            `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
            `gpt-image-1`.

            - `string`

            - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

              The image generation model to use. One of `gpt-image-1`,
              `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
              `gpt-image-1`.

              - `"gpt-image-1"`

              - `"gpt-image-1-mini"`

              - `"gpt-image-1.5"`

              - `"gpt-image-2"`

              - `"gpt-image-2-2026-04-21"`

              - `"gpt-image-2.5-sunburst"`

              - `"gpt-image-2.5-sunburst-2026-09-08"`

              - `"gpt-image-2.5-flare"`

              - `"gpt-image-2.5-flare-2026-09-08"`

          - `moderation: optional "auto" or "low"`

            Moderation level for the generated image. Default: `auto`.

            - `"auto"`

            - `"low"`

          - `output_compression: optional number`

            Compression level for the output image. Default: 100.

          - `output_format: optional "png" or "webp" or "jpeg"`

            The output format of the generated image. One of `png`, `webp`, or
            `jpeg`. Default: `png`.

            - `"png"`

            - `"webp"`

            - `"jpeg"`

          - `partial_images: optional number`

            Number of partial images to generate in streaming mode, from 0 (default value) to 3.

          - `quality: optional "low" or "medium" or "high" or 3 more`

            The quality of the generated image. The GPT image models support `low`,
            `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
            including their `2026-09-08` snapshots, also support `xhigh` and `max`.
            Default: `auto`.

            - `"low"`

            - `"medium"`

            - `"high"`

            - `"xhigh"`

            - `"max"`

            - `"auto"`

          - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

            The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

            - `string`

            - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

              The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

              - `"1024x1024"`

              - `"1024x1536"`

              - `"1536x1024"`

              - `"auto"`

        - `LocalShell object { type }`

          A tool that allows the model to execute shell commands in a local environment.

          - `type: "local_shell"`

            The type of the local shell tool. Always `local_shell`.

            - `"local_shell"`

        - `Shell object { type, allowed_callers, environment }`

          A tool that allows the model to execute shell commands.

          - `type: "shell"`

            The type of the shell tool. Always `shell`.

            - `"shell"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

            - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

              - `type: "container_auto"`

                Automatically creates a container for this request

                - `"container_auto"`

              - `file_ids: optional array of string`

                An optional list of uploaded files to make available to your code.

              - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                The memory limit for the container.

                - `"1g"`

                - `"4g"`

                - `"16g"`

                - `"64g"`

              - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                Network access policy for the container.

                - `ContainerNetworkPolicyDisabled object { type }`

                - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

              - `skills: optional array of SkillReference or InlineSkill`

                An optional list of skills referenced by id or inline data.

                - `SkillReference object { skill_id, type, version }`

                  - `skill_id: string`

                    The ID of the referenced skill.

                  - `type: "skill_reference"`

                    References a skill created with the /v1/skills endpoint.

                    - `"skill_reference"`

                  - `version: optional string`

                    Optional skill version. Use a positive integer or 'latest'. Omit for default.

                - `InlineSkill object { description, name, source, type }`

                  - `description: string`

                    The description of the skill.

                  - `name: string`

                    The name of the skill.

                  - `source: InlineSkillSource`

                    Inline skill payload

                    - `data: string`

                      Base64-encoded skill zip bundle.

                    - `media_type: "application/zip"`

                      The media type of the inline skill payload. Must be `application/zip`.

                      - `"application/zip"`

                    - `type: "base64"`

                      The type of the inline skill source. Must be `base64`.

                      - `"base64"`

                  - `type: "inline"`

                    Defines an inline skill for this request.

                    - `"inline"`

            - `LocalEnvironment object { type, skills }`

              - `type: "local"`

                Use a local computer environment.

                - `"local"`

              - `skills: optional array of LocalSkill`

                An optional list of skills.

                - `description: string`

                  The description of the skill.

                - `name: string`

                  The name of the skill.

                - `path: string`

                  The path to the directory containing the skill.

            - `ContainerReference object { container_id, type }`

              - `container_id: string`

                The ID of the referenced container.

              - `type: "container_reference"`

                References a container created with the /v1/containers endpoint

                - `"container_reference"`

        - `Custom object { name, type, allowed_callers, 4 more }`

          A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

          - `name: string`

            The name of the custom tool, used to identify it in tool calls.

          - `type: "custom"`

            The type of the custom tool. Always `custom`.

            - `"custom"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

            Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

          - `defer_loading: optional boolean`

            Whether this tool should be deferred and discovered via tool search.

          - `description: optional string`

            Optional description of the custom tool, used to provide more context.

          - `format: optional CustomToolInputFormat`

            The input format for the custom tool. Default is unconstrained text.

            - `Text object { type }`

              Unconstrained free-form text.

              - `type: "text"`

                Unconstrained text format. Always `text`.

                - `"text"`

            - `Grammar object { definition, syntax, type }`

              A grammar defined by the user.

              - `definition: string`

                The grammar definition.

              - `syntax: "lark" or "regex"`

                The syntax of the grammar definition. One of `lark` or `regex`.

                - `"lark"`

                - `"regex"`

              - `type: "grammar"`

                Grammar format. Always `grammar`.

                - `"grammar"`

        - `ToolSearchOutputNamespaceTool object { description, name, tools, type }`

          Groups function/custom tools under a shared namespace.

          - `description: string`

            A description of the namespace shown to the model.

          - `name: string`

            The namespace name used in tool calls (for example, `crm`).

          - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

            The function/custom tools loaded inside this namespace.

            - `Function object { name, type, allowed_callers, 6 more }`

              - `name: string`

                The name of the loaded function tool.

              - `type: "function"`

                - `"function"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this function should be deferred and discovered via tool search.

              - `description: optional string or null`

              - `output_schema: optional map[unknown] or null`

                A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

              - `parameters: optional unknown or null`

              - `strict: optional boolean or null`

                Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

            - `Custom object { name, type, allowed_callers, 4 more }`

              A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

              - `name: string`

                The name of the custom tool, used to identify it in tool calls.

              - `type: "custom"`

                The type of the custom tool. Always `custom`.

                - `"custom"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this tool should be deferred and discovered via tool search.

              - `description: optional string`

                Optional description of the custom tool, used to provide more context.

              - `format: optional CustomToolInputFormat`

                The input format for the custom tool. Default is unconstrained text.

          - `type: "namespace"`

            The type of the tool. Always `namespace`.

            - `"namespace"`

        - `ToolSearch object { type, description, execution, parameters }`

          Hosted or BYOT tool search configuration for deferred tools.

          - `type: "tool_search"`

            The type of the tool. Always `tool_search`.

            - `"tool_search"`

          - `description: optional string or null`

            Description shown to the model for a client-executed tool search tool.

          - `execution: optional "server" or "client"`

            Whether tool search is executed by the server or by the client.

            - `"server"`

            - `"client"`

          - `parameters: optional unknown or null`

            Parameter schema for a client-executed tool search tool.

        - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

          This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

            The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

            - `"web_search_preview"`

            - `"web_search_preview_2025_03_11"`

          - `search_content_types: optional array of "text" or "image"`

            - `"text"`

            - `"image"`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { type, city, country, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

            - `type: "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

        - `ApplyPatch object { type, allowed_callers }`

          Allows the assistant to create, delete, or update files using unified diffs.

          - `type: "apply_patch"`

            The type of the tool. Always `apply_patch`.

            - `"apply_patch"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

      - `type: "tool_search_output"`

        The item type. Always `tool_search_output`.

        - `"tool_search_output"`

      - `id: optional string or null`

        The unique ID of this tool search output.

      - `call_id: optional string or null`

        The unique ID of the tool search call generated by the model.

      - `execution: optional "server" or "client"`

        Whether tool search was executed by the server or by the client.

        - `"server"`

        - `"client"`

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the tool search output.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `AdditionalTools object { role, tools, type, id }`

      - `role: "developer"`

        The role that provided the additional tools. Only `developer` is supported.

        - `"developer"`

      - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

        A list of additional tools made available at this item.

        - `Function object { name, parameters, strict, 6 more }`

          Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

          - `name: string`

            The name of the function to call.

          - `parameters: map[unknown] or null`

            A JSON schema object describing the parameters of the function.

          - `strict: boolean or null`

            Whether strict parameter validation is enforced for this function tool.

          - `type: "function"`

            The type of the function tool. Always `function`.

            - `"function"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

          - `defer_loading: optional boolean`

            Whether this function is deferred and loaded via tool search.

          - `description: optional string or null`

            A description of the function. Used by the model to determine whether or not to call the function.

          - `output_schema: optional map[unknown] or null`

            A JSON schema object describing the JSON value encoded in string outputs for this function.

        - `FileSearch object { type, vector_store_ids, filters, 2 more }`

          A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

          - `type: "file_search"`

            The type of the file search tool. Always `file_search`.

            - `"file_search"`

          - `vector_store_ids: array of string`

            The IDs of the vector stores to search.

          - `filters: optional ComparisonFilter or CompoundFilter or null`

            A filter to apply.

            - `ComparisonFilter object { key, type, value }`

              A filter used to compare a specified attribute key to a given value using a defined comparison operation.

            - `CompoundFilter object { filters, type }`

              Combine multiple filters using `and` or `or`.

          - `max_num_results: optional number`

            The maximum number of results to return. This number should be between 1 and 50 inclusive.

          - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

            Ranking options for search.

            - `hybrid_search: optional object { embedding_weight, text_weight }`

              Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

              - `embedding_weight: number`

                The weight of the embedding in the reciprocal ranking fusion.

              - `text_weight: number`

                The weight of the text in the reciprocal ranking fusion.

            - `ranker: optional "auto" or "default-2024-11-15"`

              The ranker to use for the file search.

              - `"auto"`

              - `"default-2024-11-15"`

            - `score_threshold: optional number`

              The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

        - `Computer object { type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `type: "computer"`

            The type of the computer tool. Always `computer`.

            - `"computer"`

        - `ComputerUsePreview object { display_height, display_width, environment, type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `display_height: number`

            The height of the computer display.

          - `display_width: number`

            The width of the computer display.

          - `environment: "windows" or "mac" or "linux" or 2 more`

            The type of computer environment to control.

            - `"windows"`

            - `"mac"`

            - `"linux"`

            - `"ubuntu"`

            - `"browser"`

          - `type: "computer_use_preview"`

            The type of the computer use tool. Always `computer_use_preview`.

            - `"computer_use_preview"`

        - `WebSearch object { type, external_web_access, filters, 2 more }`

          Search the Internet for sources related to the prompt. Learn more about the
          [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search" or "web_search_2025_08_26"`

            The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

            - `"web_search"`

            - `"web_search_2025_08_26"`

          - `external_web_access: optional boolean`

            Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

          - `filters: optional object { allowed_domains }  or null`

            Filters for the search.

            - `allowed_domains: optional array of string or null`

              Allowed domains for the search. If not provided, all domains are allowed.
              Subdomains of the provided domains are allowed as well.

              Example: `["pubmed.ncbi.nlm.nih.gov"]`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { city, country, region, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the
            United States. To avoid this fallback, pass `{"type": "approximate"}` without
            location fields. To localize results, provide the relevant location fields.

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

            - `type: optional "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

        - `Mcp object { server_label, type, allowed_callers, 9 more }`

          Give the model access to additional tools via remote Model Context Protocol
          (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

          - `server_label: string`

            A label for this MCP server, used to identify it in tool calls.

          - `type: "mcp"`

            The type of the MCP tool. Always `mcp`.

            - `"mcp"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

            List of allowed tool names or a filter object.

            - `McpAllowedTools = array of string`

              A string array of allowed tool names

            - `McpToolFilter object { read_only, tool_names }`

              A filter object to specify which tools are allowed.

              - `read_only: optional boolean`

                Indicates whether or not a tool modifies data or is read-only. If an
                MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                it will match this filter.

              - `tool_names: optional array of string`

                List of allowed tool names.

          - `authorization: optional string`

            An OAuth access token that can be used with a remote MCP server, either
            with a custom MCP server URL or a service connector. Your application
            must handle the OAuth authorization flow and provide the token here.

          - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

            Identifier for service connectors, like those available in ChatGPT. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
            about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

            This field is deprecated for models released after September 1, 2026.
            Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
            connect through a Secure MCP Tunnel.

            Currently supported `connector_id` values are:

            - Dropbox: `connector_dropbox`
            - Gmail: `connector_gmail`
            - Google Calendar: `connector_googlecalendar`
            - Google Drive: `connector_googledrive`
            - Microsoft Teams: `connector_microsoftteams`
            - Outlook Calendar: `connector_outlookcalendar`
            - Outlook Email: `connector_outlookemail`
            - SharePoint: `connector_sharepoint`

            - `"connector_dropbox"`

            - `"connector_gmail"`

            - `"connector_googlecalendar"`

            - `"connector_googledrive"`

            - `"connector_microsoftteams"`

            - `"connector_outlookcalendar"`

            - `"connector_outlookemail"`

            - `"connector_sharepoint"`

          - `defer_loading: optional boolean`

            Whether this MCP tool is deferred and discovered via tool search.

          - `headers: optional map[string] or null`

            Optional HTTP headers to send to the MCP server. Use for authentication
            or other purposes.

          - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

            Specify which of the MCP server's tools require approval.

            - `McpToolApprovalFilter object { always, never }`

              Specify which of the MCP server's tools require approval. Can be
              `always`, `never`, or a filter object associated with tools
              that require approval.

              - `always: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

              - `never: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

            - `McpToolApprovalSetting = "always" or "never"`

              Specify a single approval policy for all tools. One of `always` or
              `never`. When set to `always`, all tools will require approval. When
              set to `never`, all tools will not require approval.

              - `"always"`

              - `"never"`

          - `server_description: optional string`

            Optional description of the MCP server, used to provide more context.

          - `server_url: optional string`

            The URL for the MCP server. One of `server_url`, `connector_id`, or
            `tunnel_id` must be provided.

          - `tunnel_id: optional string`

            The Secure MCP Tunnel ID to use instead of a direct server URL. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided.

        - `CodeInterpreter object { container, type, allowed_callers }`

          A tool that runs Python code to help generate a response to a prompt.

          - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

            The code interpreter container. Can be a container ID or an object that
            specifies uploaded file IDs to make available to your code, along with an
            optional `memory_limit` setting.

            - `string`

              The container ID.

            - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

              Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

              - `type: "auto"`

                Always `auto`.

                - `"auto"`

              - `file_ids: optional array of string`

                An optional list of uploaded files to make available to your code.

              - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                The memory limit for the code interpreter container.

                - `"1g"`

                - `"4g"`

                - `"16g"`

                - `"64g"`

              - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                Network access policy for the container.

                - `ContainerNetworkPolicyDisabled object { type }`

                - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

          - `type: "code_interpreter"`

            The type of the code interpreter tool. Always `code_interpreter`.

            - `"code_interpreter"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

        - `ProgrammaticToolCalling object { type }`

          - `type: "programmatic_tool_calling"`

            The type of the tool. Always `programmatic_tool_calling`.

            - `"programmatic_tool_calling"`

        - `ImageGeneration object { type, action, background, 9 more }`

          A tool that generates images using the GPT image models.

          - `type: "image_generation"`

            The type of the image generation tool. Always `image_generation`.

            - `"image_generation"`

          - `action: optional "generate" or "edit" or "auto"`

            Whether to generate a new image or edit an existing image. Default: `auto`.

            - `"generate"`

            - `"edit"`

            - `"auto"`

          - `background: optional "transparent" or "opaque" or "auto"`

            Set the background of the generated image. One of `transparent`, `opaque`,
            or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
            their `2026-09-08` snapshots, support `opaque` and `transparent`
            backgrounds. Transparent backgrounds are available for supported GPT Image
            models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
            preview. When using `transparent`, set the output format to `png` or `webp`.
            Default: `auto`.

            - `"transparent"`

            - `"opaque"`

            - `"auto"`

          - `input_fidelity: optional "high" or "low" or null`

            Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

            - `"high"`

            - `"low"`

          - `input_image_mask: optional object { file_id, image_url }`

            Optional mask for inpainting. Contains `image_url`
            (string, optional) and `file_id` (string, optional).

            - `file_id: optional string`

              File ID for the mask image.

            - `image_url: optional string`

              Base64-encoded mask image.

          - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

            The image generation model to use. One of `gpt-image-1`,
            `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
            `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
            `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
            `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
            `gpt-image-1`.

            - `string`

            - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

              The image generation model to use. One of `gpt-image-1`,
              `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
              `gpt-image-1`.

              - `"gpt-image-1"`

              - `"gpt-image-1-mini"`

              - `"gpt-image-1.5"`

              - `"gpt-image-2"`

              - `"gpt-image-2-2026-04-21"`

              - `"gpt-image-2.5-sunburst"`

              - `"gpt-image-2.5-sunburst-2026-09-08"`

              - `"gpt-image-2.5-flare"`

              - `"gpt-image-2.5-flare-2026-09-08"`

          - `moderation: optional "auto" or "low"`

            Moderation level for the generated image. Default: `auto`.

            - `"auto"`

            - `"low"`

          - `output_compression: optional number`

            Compression level for the output image. Default: 100.

          - `output_format: optional "png" or "webp" or "jpeg"`

            The output format of the generated image. One of `png`, `webp`, or
            `jpeg`. Default: `png`.

            - `"png"`

            - `"webp"`

            - `"jpeg"`

          - `partial_images: optional number`

            Number of partial images to generate in streaming mode, from 0 (default value) to 3.

          - `quality: optional "low" or "medium" or "high" or 3 more`

            The quality of the generated image. The GPT image models support `low`,
            `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
            including their `2026-09-08` snapshots, also support `xhigh` and `max`.
            Default: `auto`.

            - `"low"`

            - `"medium"`

            - `"high"`

            - `"xhigh"`

            - `"max"`

            - `"auto"`

          - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

            The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

            - `string`

            - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

              The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

              - `"1024x1024"`

              - `"1024x1536"`

              - `"1536x1024"`

              - `"auto"`

        - `LocalShell object { type }`

          A tool that allows the model to execute shell commands in a local environment.

          - `type: "local_shell"`

            The type of the local shell tool. Always `local_shell`.

            - `"local_shell"`

        - `Shell object { type, allowed_callers, environment }`

          A tool that allows the model to execute shell commands.

          - `type: "shell"`

            The type of the shell tool. Always `shell`.

            - `"shell"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

            - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

            - `LocalEnvironment object { type, skills }`

            - `ContainerReference object { container_id, type }`

        - `Custom object { name, type, allowed_callers, 4 more }`

          A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

          - `name: string`

            The name of the custom tool, used to identify it in tool calls.

          - `type: "custom"`

            The type of the custom tool. Always `custom`.

            - `"custom"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

            Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

          - `defer_loading: optional boolean`

            Whether this tool should be deferred and discovered via tool search.

          - `description: optional string`

            Optional description of the custom tool, used to provide more context.

          - `format: optional CustomToolInputFormat`

            The input format for the custom tool. Default is unconstrained text.

        - `Namespace object { description, name, tools, type }`

          Groups function/custom tools under a shared namespace.

          - `description: string`

            A description of the namespace shown to the model.

          - `name: string`

            The namespace name used in tool calls (for example, `crm`).

          - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

            The function/custom tools available inside this namespace.

            - `Function object { name, type, allowed_callers, 6 more }`

              - `name: string`

              - `type: "function"`

                - `"function"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this function should be deferred and discovered via tool search.

              - `description: optional string or null`

              - `output_schema: optional map[unknown] or null`

                A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

              - `parameters: optional unknown or null`

              - `strict: optional boolean or null`

                Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

            - `Custom object { name, type, allowed_callers, 4 more }`

              A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

              - `name: string`

                The name of the custom tool, used to identify it in tool calls.

              - `type: "custom"`

                The type of the custom tool. Always `custom`.

                - `"custom"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this tool should be deferred and discovered via tool search.

              - `description: optional string`

                Optional description of the custom tool, used to provide more context.

              - `format: optional CustomToolInputFormat`

                The input format for the custom tool. Default is unconstrained text.

          - `type: "namespace"`

            The type of the tool. Always `namespace`.

            - `"namespace"`

        - `ToolSearch object { type, description, execution, parameters }`

          Hosted or BYOT tool search configuration for deferred tools.

          - `type: "tool_search"`

            The type of the tool. Always `tool_search`.

            - `"tool_search"`

          - `description: optional string or null`

            Description shown to the model for a client-executed tool search tool.

          - `execution: optional "server" or "client"`

            Whether tool search is executed by the server or by the client.

            - `"server"`

            - `"client"`

          - `parameters: optional unknown or null`

            Parameter schema for a client-executed tool search tool.

        - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

          This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

            The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

            - `"web_search_preview"`

            - `"web_search_preview_2025_03_11"`

          - `search_content_types: optional array of "text" or "image"`

            - `"text"`

            - `"image"`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { type, city, country, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

            - `type: "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

        - `ApplyPatch object { type, allowed_callers }`

          Allows the assistant to create, delete, or update files using unified diffs.

          - `type: "apply_patch"`

            The type of the tool. Always `apply_patch`.

            - `"apply_patch"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

      - `type: "additional_tools"`

        The item type. Always `additional_tools`.

        - `"additional_tools"`

      - `id: optional string or null`

        The unique ID of this additional tools item.

    - `ConfigurationUpdate object { type, id, reasoning }`

      An update to the conversation's response configuration. The configuration
      remains in effect for subsequent responses until it is replaced by another
      configuration update.

      - `type: "configuration_update"`

        The item type. Always `configuration_update`.

        - `"configuration_update"`

      - `id: optional string or null`

        The unique ID of the configuration update item.

      - `reasoning: optional object { effort }`

        Updates to reasoning configuration. Only effort is supported.

        - `effort: optional ReasoningEffort or null`

          The reasoning effort to use for subsequent responses until another
          configuration update replaces it.

          - `"none"`

          - `"minimal"`

          - `"low"`

          - `"medium"`

          - `"high"`

          - `"xhigh"`

          - `"max"`

    - `Reasoning object { id, summary, type, 3 more }`

      A description of the chain of thought used by a reasoning model while generating
      a response. Be sure to include these items in your `input` to the Responses API
      for subsequent turns of a conversation if you are manually
      [managing context](/api/docs/guides/conversation-state).

      - `id: string`

        The unique identifier of the reasoning content.

      - `summary: array of SummaryTextContent`

        Reasoning summary content.

        - `text: string`

          A summary of the reasoning output from the model so far.

        - `type: "summary_text"`

          The type of the object. Always `summary_text`.

          - `"summary_text"`

      - `type: "reasoning"`

        The type of the object. Always `reasoning`.

        - `"reasoning"`

      - `content: optional array of object { text, type }`

        Reasoning text content.

        - `text: string`

          The reasoning text from the model.

        - `type: "reasoning_text"`

          The type of the reasoning text. Always `reasoning_text`.

          - `"reasoning_text"`

      - `encrypted_content: optional string or null`

        The encrypted content of the reasoning item. This is populated by default
        for reasoning items returned by `POST /v1/responses` and WebSocket
        `response.create` requests.

        When streaming, use the completed reasoning item and its
        `encrypted_content` from the `response.output_item.done` event in
        subsequent requests. The `encrypted_content` in
        `response.output_item.added` may be incomplete. This is especially
        important when `store` is `false` or when using Zero Data Retention.

      - `status: optional "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `Compaction object { encrypted_content, type, id }`

      A compaction item generated by the [`v1/responses/compact` API](/api/reference/resources/responses/methods/compact).

      - `encrypted_content: string`

        The encrypted content of the compaction summary.

      - `type: "compaction"`

        The type of the item. Always `compaction`.

        - `"compaction"`

      - `id: optional string or null`

        The ID of the compaction item.

    - `ImageGenerationCall object { id, result, status, 8 more }`

      An image generation request made by the model.

      - `id: string`

        The unique ID of the image generation call.

      - `result: string or null`

        The generated image encoded in base64.

      - `status: "in_progress" or "completed" or "generating" or "failed"`

        The status of the image generation call.

        - `"in_progress"`

        - `"completed"`

        - `"generating"`

        - `"failed"`

      - `type: "image_generation_call"`

        The type of the image generation call. Always `image_generation_call`.

        - `"image_generation_call"`

      - `action: optional "generate" or "edit" or "auto" or null`

        The action used for image generation.

        - `"generate"`

        - `"edit"`

        - `"auto"`

      - `background: optional "transparent" or "opaque" or "auto" or null`

        The background setting used for generation.

        - `"transparent"`

        - `"opaque"`

        - `"auto"`

      - `error: optional object { code, message, param, 2 more }`

        Details of a moderation failure, when available.

        - `code: string or null`

          The error code.

        - `message: string`

          A description of the error.

        - `param: string or null`

          The related request parameter.

        - `type: string`

          The error type.

        - `moderation_details: optional object { categories, moderation_stage }`

          Public details for a `moderation_blocked` error, when available.

          - `categories: array of string`

            Public moderation categories. New category values may be added over time.

          - `moderation_stage: "input" or "output" or "unknown"`

            The stage where moderation blocked the image generation call.

            - `"input"`

            - `"output"`

            - `"unknown"`

      - `output_format: optional "png" or "webp" or "jpeg" or null`

        The output format used for generation.

        - `"png"`

        - `"webp"`

        - `"jpeg"`

      - `quality: optional "low" or "medium" or "high" or 3 more or null`

        The quality of the image generated by the image generation tool call. One of `low`, `medium`, `high`, `xhigh`, `max`, or `auto`.

        - `"low"`

        - `"medium"`

        - `"high"`

        - `"xhigh"`

        - `"max"`

        - `"auto"`

      - `revised_prompt: optional string or null`

        The prompt that was used after any model prompt rewriting.

      - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or null`

        The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`.

        - `string`

        - `"1024x1024" or "1024x1536" or "1536x1024"`

          The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`.

          - `"1024x1024"`

          - `"1024x1536"`

          - `"1536x1024"`

    - `CodeInterpreterCall object { id, code, container_id, 3 more }`

      A tool call to run code.

      - `id: string`

        The unique ID of the code interpreter tool call.

      - `code: string or null`

        The code to run, or null if not available.

      - `container_id: string`

        The ID of the container used to run the code.

      - `outputs: array of Logs { logs, type }  or Image { type, url }  or null`

        The outputs generated by the code interpreter, such as logs or images.
        Can be null if no outputs are available.

        - `Logs object { logs, type }`

          The logs output from the code interpreter.

          - `logs: string`

            The logs output from the code interpreter.

          - `type: "logs"`

            The type of the output. Always `logs`.

            - `"logs"`

        - `Image object { type, url }`

          The image output from the code interpreter.

          - `type: "image"`

            The type of the output. Always `image`.

            - `"image"`

          - `url: string`

            The URL of the image output from the code interpreter.

      - `status: "in_progress" or "completed" or "incomplete" or 2 more`

        The status of the code interpreter tool call. Valid values are `in_progress`, `completed`, `incomplete`, `interpreting`, and `failed`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

        - `"interpreting"`

        - `"failed"`

      - `type: "code_interpreter_call"`

        The type of the code interpreter tool call. Always `code_interpreter_call`.

        - `"code_interpreter_call"`

    - `LocalShellCall object { id, action, call_id, 2 more }`

      A tool call to run a command on the local shell.

      - `id: string`

        The unique ID of the local shell call.

      - `action: object { command, env, type, 3 more }`

        Execute a shell command on the server.

        - `command: array of string`

          The command to run.

        - `env: map[string]`

          Environment variables to set for the command.

        - `type: "exec"`

          The type of the local shell action. Always `exec`.

          - `"exec"`

        - `timeout_ms: optional number or null`

          Optional timeout in milliseconds for the command.

        - `user: optional string or null`

          Optional user to run the command as.

        - `working_directory: optional string or null`

          Optional working directory to run the command in.

      - `call_id: string`

        The unique ID of the local shell tool call generated by the model.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the local shell call.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "local_shell_call"`

        The type of the local shell call. Always `local_shell_call`.

        - `"local_shell_call"`

    - `LocalShellCallOutput object { id, output, type, status }`

      The output of a local shell tool call.

      - `id: string`

        The unique ID of the local shell tool call generated by the model.

      - `output: string`

        A JSON string of the output of the local shell tool call.

      - `type: "local_shell_call_output"`

        The type of the local shell tool call output. Always `local_shell_call_output`.

        - `"local_shell_call_output"`

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the item. One of `in_progress`, `completed`, or `incomplete`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `ShellCall object { action, call_id, type, 4 more }`

      A tool representing a request to execute one or more shell commands.

      - `action: object { commands, max_output_length, timeout_ms }`

        The shell commands and limits that describe how to run the tool call.

        - `commands: array of string`

          Ordered shell commands for the execution environment to run.

        - `max_output_length: optional number or null`

          Maximum number of UTF-8 characters to capture from combined stdout and stderr output.

        - `timeout_ms: optional number or null`

          Maximum wall-clock time in milliseconds to allow the shell commands to run.

      - `call_id: string`

        The unique ID of the shell tool call generated by the model.

      - `type: "shell_call"`

        The type of the item. Always `shell_call`.

        - `"shell_call"`

      - `id: optional string or null`

        The unique ID of the shell tool call. Populated when this item is returned via API.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

      - `environment: optional LocalEnvironment or ContainerReference or null`

        The environment to execute the shell commands in.

        - `LocalEnvironment object { type, skills }`

        - `ContainerReference object { container_id, type }`

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the shell call. One of `in_progress`, `completed`, or `incomplete`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `ShellCallOutput object { call_id, output, type, 4 more }`

      The streamed output items emitted by a shell tool call.

      - `call_id: string`

        The unique ID of the shell tool call generated by the model.

      - `output: array of ResponseFunctionShellCallOutputContent`

        Captured chunks of stdout and stderr output, along with their associated outcomes.

        - `outcome: Timeout { type }  or Exit { exit_code, type }`

          The exit or timeout outcome associated with this shell call.

          - `Timeout object { type }`

            Indicates that the shell call exceeded its configured time limit.

            - `type: "timeout"`

              The outcome type. Always `timeout`.

              - `"timeout"`

          - `Exit object { exit_code, type }`

            Indicates that the shell commands finished and returned an exit code.

            - `exit_code: number`

              The exit code returned by the shell process.

            - `type: "exit"`

              The outcome type. Always `exit`.

              - `"exit"`

        - `stderr: string`

          Captured stderr output for the shell call.

        - `stdout: string`

          Captured stdout output for the shell call.

      - `type: "shell_call_output"`

        The type of the item. Always `shell_call_output`.

        - `"shell_call_output"`

      - `id: optional string or null`

        The unique ID of the shell tool call output. Populated when this item is returned via API.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

      - `max_output_length: optional number or null`

        The maximum number of UTF-8 characters captured for this shell call's combined output.

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the shell call output.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `ApplyPatchCall object { call_id, operation, status, 3 more }`

      A tool call representing a request to create, delete, or update files using diff patches.

      - `call_id: string`

        The unique ID of the apply patch tool call generated by the model.

      - `operation: CreateFile { diff, path, type }  or DeleteFile { path, type }  or UpdateFile { diff, path, type }`

        The specific create, delete, or update instruction for the apply_patch tool call.

        - `CreateFile object { diff, path, type }`

          Instruction for creating a new file via the apply_patch tool.

          - `diff: string`

            Unified diff content to apply when creating the file.

          - `path: string`

            Path of the file to create relative to the workspace root.

          - `type: "create_file"`

            The operation type. Always `create_file`.

            - `"create_file"`

        - `DeleteFile object { path, type }`

          Instruction for deleting an existing file via the apply_patch tool.

          - `path: string`

            Path of the file to delete relative to the workspace root.

          - `type: "delete_file"`

            The operation type. Always `delete_file`.

            - `"delete_file"`

        - `UpdateFile object { diff, path, type }`

          Instruction for updating an existing file via the apply_patch tool.

          - `diff: string`

            Unified diff content to apply to the existing file.

          - `path: string`

            Path of the file to update relative to the workspace root.

          - `type: "update_file"`

            The operation type. Always `update_file`.

            - `"update_file"`

      - `status: "in_progress" or "completed"`

        The status of the apply patch tool call. One of `in_progress` or `completed`.

        - `"in_progress"`

        - `"completed"`

      - `type: "apply_patch_call"`

        The type of the item. Always `apply_patch_call`.

        - `"apply_patch_call"`

      - `id: optional string or null`

        The unique ID of the apply patch tool call. Populated when this item is returned via API.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

    - `ApplyPatchCallOutput object { call_id, status, type, 3 more }`

      The streamed output emitted by an apply patch tool call.

      - `call_id: string`

        The unique ID of the apply patch tool call generated by the model.

      - `status: "completed" or "failed"`

        The status of the apply patch tool call output. One of `completed` or `failed`.

        - `"completed"`

        - `"failed"`

      - `type: "apply_patch_call_output"`

        The type of the item. Always `apply_patch_call_output`.

        - `"apply_patch_call_output"`

      - `id: optional string or null`

        The unique ID of the apply patch tool call output. Populated when this item is returned via API.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

      - `output: optional string or null`

        Optional human-readable log text from the apply patch tool (e.g., patch results or errors).

    - `McpListTools object { id, server_label, tools, 2 more }`

      A list of tools available on an MCP server.

      - `id: string`

        The unique ID of the list.

      - `server_label: string`

        The label of the MCP server.

      - `tools: array of object { input_schema, name, annotations, description }`

        The tools available on the server.

        - `input_schema: unknown`

          The JSON schema describing the tool's input.

        - `name: string`

          The name of the tool.

        - `annotations: optional unknown or null`

          Additional annotations about the tool.

        - `description: optional string or null`

          The description of the tool.

      - `type: "mcp_list_tools"`

        The type of the item. Always `mcp_list_tools`.

        - `"mcp_list_tools"`

      - `error: optional string or null`

        Error message if the server could not list tools.

    - `McpApprovalRequest object { id, arguments, name, 2 more }`

      A request for human approval of a tool invocation.

      - `id: string`

        The unique ID of the approval request.

      - `arguments: string`

        A JSON string of arguments for the tool.

      - `name: string`

        The name of the tool to run.

      - `server_label: string`

        The label of the MCP server making the request.

      - `type: "mcp_approval_request"`

        The type of the item. Always `mcp_approval_request`.

        - `"mcp_approval_request"`

    - `McpApprovalResponse object { approval_request_id, approve, type, 2 more }`

      A response to an MCP approval request.

      - `approval_request_id: string`

        The ID of the approval request being answered.

      - `approve: boolean`

        Whether the request was approved.

      - `type: "mcp_approval_response"`

        The type of the item. Always `mcp_approval_response`.

        - `"mcp_approval_response"`

      - `id: optional string or null`

        The unique ID of the approval response

      - `reason: optional string or null`

        Optional reason for the decision.

    - `McpCall object { id, arguments, name, 6 more }`

      An invocation of a tool on an MCP server.

      - `id: string`

        The unique ID of the tool call.

      - `arguments: string`

        A JSON string of the arguments passed to the tool.

      - `name: string`

        The name of the tool that was run.

      - `server_label: string`

        The label of the MCP server running the tool.

      - `type: "mcp_call"`

        The type of the item. Always `mcp_call`.

        - `"mcp_call"`

      - `approval_request_id: optional string or null`

        Unique identifier for the MCP tool call approval request.
        Include this value in a subsequent `mcp_approval_response` input to approve or reject the corresponding tool call.

      - `error: optional McpToolCallError or null`

        The error from the tool call, if any.

        - `McpProtocolError object { code, message, type }`

          - `code: number`

          - `message: string`

          - `type: "mcp_protocol_error"`

            - `"mcp_protocol_error"`

        - `McpToolExecutionError object { content, type }`

          - `content: unknown`

          - `type: "mcp_tool_execution_error"`

            - `"mcp_tool_execution_error"`

        - `HTTPError object { code, message, type }`

          - `code: number`

          - `message: string`

          - `type: "http_error"`

            - `"http_error"`

      - `output: optional string or null`

        The output from the tool call.

      - `status: optional "in_progress" or "completed" or "incomplete" or 2 more`

        The status of the tool call. One of `in_progress`, `completed`, `incomplete`, `calling`, or `failed`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

        - `"calling"`

        - `"failed"`

    - `CustomToolCallOutput object { call_id, output, type, 2 more }`

      The output of a custom tool call from your code, being sent back to the model.

      - `call_id: string`

        The call ID, used to map this custom tool call output to a custom tool call.

      - `output: string or array of ResponseInputText or ResponseInputImage or ResponseInputFile`

        The output from the custom tool call generated by your code.
        Can be a string or an list of output content.

        - `StringOutput = string`

          A string of the output of the custom tool call.

        - `OutputContentList = array of ResponseInputText or ResponseInputImage or ResponseInputFile`

          Text, image, or file output of the custom tool call.

          - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

            A text input to the model.

          - `ResponseInputImage object { detail, type, file_id, 2 more }`

            An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

          - `ResponseInputFile object { type, detail, file_data, 4 more }`

            A file input to the model.

      - `type: "custom_tool_call_output"`

        The type of the custom tool call output. Always `custom_tool_call_output`.

        - `"custom_tool_call_output"`

      - `id: optional string`

        The unique ID of the custom tool call output in the OpenAI platform.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

    - `CustomToolCall object { call_id, input, name, 5 more }`

      A call to a custom tool created by the model.

      - `call_id: string`

        An identifier used to map this custom tool call to a tool call output.

      - `input: string`

        The input for the custom tool call generated by the model.

      - `name: string`

        The name of the custom tool being called.

      - `type: "custom_tool_call"`

        The type of the custom tool call. Always `custom_tool_call`.

        - `"custom_tool_call"`

      - `id: optional string`

        The unique ID of the custom tool call in the OpenAI platform.

      - `async: optional boolean`

        Whether the custom tool call runs asynchronously.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `namespace: optional string`

        The namespace of the custom tool being called.

    - `CompactionTrigger object { type, id }`

      Compacts the current context. Must be the final input item.

      - `type: "compaction_trigger"`

        The type of the item. Always `compaction_trigger`.

        - `"compaction_trigger"`

      - `id: optional string or null`

        The unique ID of this compaction trigger.

    - `ItemReference object { id, type }`

      An internal identifier for an item to reference.

      - `id: string`

        The ID of the item to reference.

      - `type: optional "item_reference" or null`

        The type of item to reference. Always `item_reference`.

        - `"item_reference"`

    - `Program object { id, call_id, code, 2 more }`

      - `id: string`

        The unique ID of this program item.

      - `call_id: string`

        The stable call ID of the program item.

      - `code: string`

        The JavaScript source executed by programmatic tool calling.

      - `fingerprint: string`

        Opaque program replay fingerprint that must be round-tripped.

      - `type: "program"`

        The item type. Always `program`.

        - `"program"`

    - `ProgramOutput object { id, call_id, result, 2 more }`

      - `id: string`

        The unique ID of this program output item.

      - `call_id: string`

        The call ID of the program item.

      - `result: string`

        The result produced by the program item.

      - `status: "completed" or "incomplete"`

        The terminal status of the program output.

        - `"completed"`

        - `"incomplete"`

      - `type: "program_output"`

        The item type. Always `program_output`.

        - `"program_output"`

- `instructions: optional string or null`

  A system (or developer) message inserted into the model's context.

  When using along with `previous_response_id`, the instructions from a previous
  response will not be carried over to the next response. This makes it simple
  to swap out system (or developer) messages in new responses.

- `max_output_tokens: optional number or null`

  An upper bound for the number of tokens that can be generated for a response, including visible output tokens and [reasoning tokens](/api/docs/guides/reasoning).

- `max_tool_calls: optional number or null`

  The maximum number of total calls to built-in tools that can be processed in a response. This maximum number applies across all built-in tool calls, not per individual tool. Any further attempts to call a tool by the model will be ignored.

- `metadata: optional Metadata or null`

  Set of 16 key-value pairs that can be attached to an object. This can be
  useful for storing additional information about the object in a structured
  format, and querying for objects via API or the dashboard.

  Keys are strings with a maximum length of 64 characters. Values are strings
  with a maximum length of 512 characters.

- `model: optional ResponsesModel`

  Model ID used to generate the response, like `gpt-6-astra`. OpenAI
  offers a wide range of models with different capabilities, performance
  characteristics, and price points. Refer to the [model guide](/api/docs/models)
  to browse and compare available models.

  - `string`

  - `"gpt-6-astra" or "gpt-6.1-sol" or "gpt-6-sol" or 86 more`

    - `"gpt-6-astra"`

    - `"gpt-6.1-sol"`

    - `"gpt-6-sol"`

    - `"gpt-6-luna"`

    - `"gpt-5.6-sol"`

    - `"gpt-5.6-terra"`

    - `"gpt-5.6-luna"`

    - `"gpt-5.5"`

    - `"gpt-5.5-2026-04-23"`

    - `"gpt-5.4"`

    - `"gpt-5.4-mini"`

    - `"gpt-5.4-nano"`

    - `"gpt-5.4-mini-2026-03-17"`

    - `"gpt-5.4-nano-2026-03-17"`

    - `"gpt-5.3-chat-latest"`

    - `"gpt-5.2"`

    - `"gpt-5.2-2025-12-11"`

    - `"gpt-5.2-chat-latest"`

    - `"gpt-5.2-pro"`

    - `"gpt-5.2-pro-2025-12-11"`

    - `"gpt-5.1"`

    - `"gpt-5.1-2025-11-13"`

    - `"gpt-5.1-codex"`

    - `"gpt-5.1-mini"`

    - `"gpt-5.1-chat-latest"`

    - `"gpt-5"`

    - `"gpt-5-mini"`

    - `"gpt-5-nano"`

    - `"gpt-5-2025-08-07"`

    - `"gpt-5-mini-2025-08-07"`

    - `"gpt-5-nano-2025-08-07"`

    - `"gpt-5-chat-latest"`

    - `"gpt-4.1"`

    - `"gpt-4.1-mini"`

    - `"gpt-4.1-nano"`

    - `"gpt-4.1-2025-04-14"`

    - `"gpt-4.1-mini-2025-04-14"`

    - `"gpt-4.1-nano-2025-04-14"`

    - `"o4-mini"`

    - `"o4-mini-2025-04-16"`

    - `"o3"`

    - `"o3-2025-04-16"`

    - `"o3-mini"`

    - `"o3-mini-2025-01-31"`

    - `"o1"`

    - `"o1-2024-12-17"`

    - `"o1-preview"`

    - `"o1-preview-2024-09-12"`

    - `"o1-mini"`

    - `"o1-mini-2024-09-12"`

    - `"gpt-4o"`

    - `"gpt-4o-2024-11-20"`

    - `"gpt-4o-2024-08-06"`

    - `"gpt-4o-2024-05-13"`

    - `"gpt-audio-mini"`

    - `"gpt-audio-mini-2025-12-15"`

    - `"gpt-4o-audio-preview"`

    - `"gpt-4o-audio-preview-2024-10-01"`

    - `"gpt-4o-audio-preview-2024-12-17"`

    - `"gpt-4o-audio-preview-2025-06-03"`

    - `"gpt-4o-mini-audio-preview"`

    - `"gpt-4o-mini-audio-preview-2024-12-17"`

    - `"gpt-4o-search-preview"`

    - `"gpt-4o-mini-search-preview"`

    - `"gpt-4o-search-preview-2025-03-11"`

    - `"gpt-4o-mini-search-preview-2025-03-11"`

    - `"chatgpt-4o-latest"`

    - `"codex-mini-latest"`

    - `"gpt-4o-mini"`

    - `"gpt-4o-mini-2024-07-18"`

    - `"gpt-4-turbo"`

    - `"gpt-4-turbo-2024-04-09"`

    - `"gpt-4-0125-preview"`

    - `"gpt-4-turbo-preview"`

    - `"gpt-4-1106-preview"`

    - `"gpt-4-vision-preview"`

    - `"gpt-4"`

    - `"gpt-4-0314"`

    - `"gpt-4-0613"`

    - `"gpt-4-32k"`

    - `"gpt-4-32k-0314"`

    - `"gpt-4-32k-0613"`

    - `"gpt-3.5-turbo"`

    - `"gpt-3.5-turbo-16k"`

    - `"gpt-3.5-turbo-0301"`

    - `"gpt-3.5-turbo-0613"`

    - `"gpt-3.5-turbo-1106"`

    - `"gpt-3.5-turbo-0125"`

    - `"gpt-3.5-turbo-16k-0613"`

  - `ResponsesOnlyModel = "o1-pro" or "o1-pro-2025-03-19" or "o3-pro" or 17 more`

    - `"o1-pro"`

    - `"o1-pro-2025-03-19"`

    - `"o3-pro"`

    - `"o3-pro-2025-06-10"`

    - `"o3-deep-research"`

    - `"o3-deep-research-2025-06-26"`

    - `"o4-mini-deep-research"`

    - `"o4-mini-deep-research-2025-06-26"`

    - `"computer-use-preview"`

    - `"computer-use-preview-2025-03-11"`

    - `"gpt-5.5-pro"`

    - `"gpt-5.5-pro-2026-04-23"`

    - `"gpt-5-codex"`

    - `"gpt-5-pro"`

    - `"gpt-5-pro-2025-10-06"`

    - `"gpt-5.1-codex-max"`

    - `"gpt-daybreak-blue-latest"`

    - `"gpt-daybreak-red-latest"`

    - `"gpt-5.6-cyber"`

    - `"gpt-rosalind-research"`

- `moderation: optional object { model, policy }  or null`

  Configuration for running moderation on the input and output of this response.

  - `model: string`

    The moderation model to use for moderated completions, e.g. 'omni-moderation-latest'.

  - `policy: optional object { input, output }  or null`

    The policy to apply to moderated response input and output.

    - `input: optional object { mode }  or null`

      The moderation policy for the response input.

      - `mode: "score" or "block"`

        - `"score"`

        - `"block"`

    - `output: optional object { mode }  or null`

      The moderation policy for the response output.

      - `mode: "score" or "block"`

        - `"score"`

        - `"block"`

- `parallel_tool_calls: optional boolean or null`

  Whether to allow the model to run tool calls in parallel.

- `previous_response_id: optional string or null`

  The unique ID of the previous response to the model. Use this to
  create multi-turn conversations. Learn more about
  [conversation state](/api/docs/guides/conversation-state). Cannot be used in conjunction with `conversation`.

- `prompt: optional ResponsePrompt or null`

  Reference to a prompt template and its variables.
  [Learn more](/api/docs/guides/text?api-mode=responses#version-prompts-in-code).

  - `id: string`

    The unique identifier of the prompt template to use.

  - `variables: optional map[string or ResponseInputText or ResponseInputImage or ResponseInputFile] or null`

    Optional map of values to substitute in for variables in your
    prompt. The substitution values can either be strings, or other
    Response input types like images or files.

    - `string`

    - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

      A text input to the model.

    - `ResponseInputImage object { detail, type, file_id, 2 more }`

      An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

    - `ResponseInputFile object { type, detail, file_data, 4 more }`

      A file input to the model.

  - `version: optional string or null`

    Optional version of the prompt template.

- `prompt_cache_key: optional string or null`

  Used by OpenAI to cache responses for similar requests to optimize your cache hit rates. Replaces the `user` field. [Learn more](/api/docs/guides/prompt-caching).

- `prompt_cache_options: optional object { comparison_response_id, mode, prewarm, ttl }`

  Options for prompt caching. Supported for `gpt-5.6` and later models. By default, OpenAI automatically chooses one implicit cache breakpoint. You can add explicit breakpoints to content blocks with `prompt_cache_breakpoint`. Each request can write up to four breakpoints. For cache matching, OpenAI considers up to the latest 80 breakpoints in the conversation, without a content-block lookback limit. Set `mode` to `explicit` to disable the implicit breakpoint. The `ttl` defaults to `30m`, which is currently the only supported value. See the [prompt caching guide](/api/docs/guides/prompt-caching) for current details.

  - `comparison_response_id: optional string or null`

    The ID of a response to compare when diagnosing prompt cache reuse. Supplying this field requests prompt cache diagnostics when the feature is enabled.

  - `mode: optional "implicit" or "explicit"`

    Controls whether OpenAI automatically creates an implicit cache breakpoint. Defaults to `implicit`. With `implicit`, OpenAI creates one implicit breakpoint and writes up to the latest three explicit breakpoints in the request. With `explicit`, OpenAI does not create an implicit breakpoint and writes up to the latest four explicit breakpoints. If there are no explicit breakpoints, the request does not use prompt caching.

    - `"implicit"`

    - `"explicit"`

  - `prewarm: optional boolean`

    Prepares the prompt cache without generating output. Defaults to `false`. When set to `true`, overrides the `generate` field to `false`.

  - `ttl: optional "30m"`

    The minimum lifetime applied to every implicit and explicit cache breakpoint written by the request. Defaults to `30m`, which is currently the only supported value. The backend may retain cache entries for longer.

    - `"30m"`

- `prompt_cache_retention: optional "in_memory" or "24h" or null`

  Deprecated. Use `prompt_cache_options.ttl` instead.

  The retention policy for the prompt cache. Set to `24h` to enable extended prompt caching, which keeps cached prefixes active for longer, up to a maximum of 24 hours. [Learn more](/api/docs/guides/prompt-caching#prompt-cache-retention).
  This field expresses a maximum retention policy, while
  `prompt_cache_options.ttl` expresses a minimum cache lifetime. The two
  fields are independent and do not interact.
  For `gpt-5.5`, `gpt-5.5-pro`, and future models, only `24h` is supported.

  For older models that support both `in_memory` and `24h`, the default depends on your organization's data retention policy:

  - Organizations without ZDR enabled default to `24h`.
  - Organizations with ZDR enabled default to `in_memory` when `prompt_cache_retention` is not specified.

  - `"in_memory"`

  - `"24h"`

- `reasoning: optional Reasoning or null`

  Configuration options for
  [reasoning models](/api/docs/guides/reasoning).

  - `context: optional "auto" or "current_turn" or "all_turns" or null`

    Controls which reasoning items are rendered back to the model on later turns.
    If omitted or set to `auto`, the model determines the context mode. The
    `gpt-5.6` model family defaults to `all_turns`; earlier models default to
    `current_turn`.

    When returned on a response, this is the effective reasoning context mode
    used for the response.

    - `"auto"`

    - `"current_turn"`

    - `"all_turns"`

  - `effort: optional ReasoningEffort or null`

    Constrains effort on reasoning for reasoning models. Currently supported
    values are `none`, `minimal`, `low`, `medium`, `high`, `xhigh`, and `max`.
    Reducing reasoning effort can result in faster responses and fewer tokens
    used on reasoning in a response. Not all reasoning models support every
    value. See the
    [reasoning guide](/api/docs/guides/reasoning)
    for model-specific support.

  - `generate_summary: optional "auto" or "concise" or "detailed" or null`

    **Deprecated:** use `summary` instead.

    A summary of the reasoning performed by the model. This can be
    useful for debugging and understanding the model's reasoning process.
    One of `auto`, `concise`, or `detailed`.

    - `"auto"`

    - `"concise"`

    - `"detailed"`

  - `mode: optional string or "standard" or "pro"`

    Controls the reasoning execution mode for the request.

    When returned on a response, this is the effective execution mode.

    - `string`

    - `"standard" or "pro"`

      Controls the reasoning execution mode for the request.

      When returned on a response, this is the effective execution mode.

      - `"standard"`

      - `"pro"`

  - `summary: optional "auto" or "concise" or "detailed" or null`

    A summary of the reasoning performed by the model. This can be
    useful for debugging and understanding the model's reasoning process.
    One of `auto`, `concise`, or `detailed`.

    `concise` is supported for `computer-use-preview` models and all reasoning models after `gpt-5`.

    - `"auto"`

    - `"concise"`

    - `"detailed"`

- `safety_identifier: optional string or null`

  A stable identifier used to help detect users of your application that may be violating OpenAI's usage policies.
  The IDs should be a string that uniquely identifies each user, with a maximum length of 128 characters. We recommend hashing their username or email address, in order to avoid sending us any identifying information. [Learn more](/api/docs/guides/safety-best-practices#implement-safety-identifiers).

- `service_tier: optional ServiceTier or null`

  Specifies the processing type used for serving the request.

  - If set to 'auto', then the request will be processed with the service tier configured in the Project settings. Unless otherwise configured, the Project will use 'default'.
  - If set to 'default', then the request will be processed with the standard pricing and performance for the selected model.
  - If set to '[flex](/api/docs/guides/flex-processing)', then the request will be processed with the Flex Processing service tier.
  - To opt-in to [Fast mode](/api/docs/guides/fast-mode) at the request level, include the `service_tier=fast` or `service_tier=priority` parameter for Responses or Chat Completions. The response will show `service_tier=priority` regardless of if you specify `service_tier=fast` or `priority` in your request.
  - If set to 'ultrafast', then the request will be processed with the access-controlled Ultrafast Processing service tier. This tier is currently available for `gpt-5.6-sol`; a response served through it will show `service_tier=ultrafast`.
  - When not set, the default behavior is 'auto'.

  When the `service_tier` parameter is set, the response body will include the `service_tier` value based on the processing mode actually used to serve the request. This response value may be different from the value set in the parameter.

  - `"auto"`

  - `"default"`

  - `"flex"`

  - `"scale"`

  - `"priority"`

  - `"fast"`

  - `"ultrafast"`

- `store: optional boolean or null`

  Whether to store the generated model response for later retrieval via
  API.
  Defaults to true when omitted.
  If set to true, response data will be stored for at least 30 days, subject to the [data retention exceptions](/api/docs/guides/your-data#v1responses).

- `stream: optional boolean or null`

  If set to true, the model response data will be streamed to the client
  as it is generated using [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format).
  See the [Streaming section below](/api/reference/resources/responses/streaming-events)
  for more information.

- `stream_options: optional object { include_obfuscation }  or null`

  Options for streaming responses. Only set this when you set `stream: true`.

  - `include_obfuscation: optional boolean`

    When true, stream obfuscation will be enabled. Stream obfuscation adds
    random characters to an `obfuscation` field on streaming delta events to
    normalize payload sizes as a mitigation to certain side-channel attacks.
    These obfuscation fields are included by default, but add a small amount
    of overhead to the data stream. You can set `include_obfuscation` to
    false to optimize for bandwidth if you trust the network links between
    your application and the OpenAI API.

- `temperature: optional number or null`

  What sampling temperature to use, between 0 and 2. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.
  We generally recommend altering this or `top_p` but not both.

- `text: optional ResponseTextConfig`

  Configuration options for a text response from the model. Can be plain
  text or structured JSON data. Learn more:

  - [Text inputs and outputs](/api/docs/guides/text)
  - [Structured Outputs](/api/docs/guides/structured-outputs)

  - `format: optional ResponseFormatTextConfig`

    An object specifying the format that the model must output.

    Configuring `{ "type": "json_schema" }` enables Structured Outputs,
    which ensures the model will match your supplied JSON schema. Learn more in the
    [Structured Outputs guide](/api/docs/guides/structured-outputs).

    The default format is `{ "type": "text" }` with no additional options.

    **Not recommended for gpt-4o and newer models:**

    Setting to `{ "type": "json_object" }` enables the older JSON mode, which
    ensures the message the model generates is valid JSON. Using `json_schema`
    is preferred for models that support it.

    - `ResponseFormatText object { type }`

      Default response format. Used to generate text responses.

      - `type: "text"`

        The type of response format being defined. Always `text`.

        - `"text"`

    - `ResponseFormatTextJSONSchemaConfig object { name, schema, type, 2 more }`

      JSON Schema response format. Used to generate structured JSON responses.
      Learn more about [Structured Outputs](/api/docs/guides/structured-outputs).

      - `name: string`

        The name of the response format. Must be a-z, A-Z, 0-9, or contain
        underscores and dashes, with a maximum length of 64.

      - `schema: map[unknown]`

        The schema for the response format, described as a JSON Schema object.
        Learn how to build JSON schemas [here](https://json-schema.org/).

      - `type: "json_schema"`

        The type of response format being defined. Always `json_schema`.

        - `"json_schema"`

      - `description: optional string`

        A description of what the response format is for, used by the model to
        determine how to respond in the format.

      - `strict: optional boolean or null`

        Whether to enable strict schema adherence when generating the output.
        If set to true, the model will always follow the exact schema defined
        in the `schema` field. Only a subset of JSON Schema is supported when
        `strict` is `true`. To learn more, read the [Structured Outputs
        guide](/api/docs/guides/structured-outputs).

    - `ResponseFormatJSONObject object { type }`

      JSON object response format. An older method of generating JSON responses.
      Using `json_schema` is recommended for models that support it. Note that the
      model will not generate JSON without a system or user message instructing it
      to do so.

      - `type: "json_object"`

        The type of response format being defined. Always `json_object`.

        - `"json_object"`

  - `verbosity: optional "low" or "medium" or "high" or null`

    Constrains the verbosity of the model's response. Lower values will result in
    more concise responses, while higher values will result in more verbose responses.
    Currently supported values are `low`, `medium`, and `high`. The default is
    `medium`.

    - `"low"`

    - `"medium"`

    - `"high"`

- `tool_choice: optional ToolChoiceOptions or ToolChoiceAllowed or ToolChoiceTypes or 6 more`

  How the model should select which tool (or tools) to use when generating
  a response. See the `tools` parameter to see how to specify which tools
  the model can call.

  - `ToolChoiceOptions = "none" or "auto" or "required"`

    Controls which (if any) tool is called by the model.

    `none` means the model will not call any tool and instead generates a message.

    `auto` means the model can pick between generating a message or calling one or
    more tools.

    `required` means the model must call one or more tools.

    - `"none"`

    - `"auto"`

    - `"required"`

  - `ToolChoiceAllowed object { mode, tools, type }`

    Constrains the tools available to the model to a pre-defined set.

    - `mode: "auto" or "required"`

      Constrains the tools available to the model to a pre-defined set.

      `auto` allows the model to pick from among the allowed tools and generate a
      message.

      `required` requires the model to call one or more of the allowed tools.

      - `"auto"`

      - `"required"`

    - `tools: array of map[unknown]`

      A list of tool definitions that the model should be allowed to call.

      For the Responses API, the list of tool definitions might look like:

      ```json
      [
        { "type": "function", "name": "get_weather" },
        { "type": "mcp", "server_label": "deepwiki" },
        { "type": "image_generation" }
      ]
      ```

    - `type: "allowed_tools"`

      Allowed tool configuration type. Always `allowed_tools`.

      - `"allowed_tools"`

  - `ToolChoiceTypes object { type }`

    Indicates that the model should use a built-in tool to generate a response.
    [Learn more about built-in tools](/api/docs/guides/tools).

    - `type: "file_search" or "web_search_preview" or "computer" or 5 more`

      The type of hosted tool the model should to use. Learn more about
      [built-in tools](/api/docs/guides/tools).

      Allowed values are:

      - `file_search`
      - `web_search_preview`
      - `computer`
      - `computer_use_preview`
      - `computer_use`
      - `code_interpreter`
      - `image_generation`

      - `"file_search"`

      - `"web_search_preview"`

      - `"computer"`

      - `"computer_use_preview"`

      - `"computer_use"`

      - `"web_search_preview_2025_03_11"`

      - `"image_generation"`

      - `"code_interpreter"`

  - `ToolChoiceFunction object { name, type }`

    Use this option to force the model to call a specific function.

    - `name: string`

      The name of the function to call.

    - `type: "function"`

      For function calling, the type is always `function`.

      - `"function"`

  - `ToolChoiceMcp object { server_label, type, name }`

    Use this option to force the model to call a specific tool on a remote MCP server.

    - `server_label: string`

      The label of the MCP server to use.

    - `type: "mcp"`

      For MCP tools, the type is always `mcp`.

      - `"mcp"`

    - `name: optional string or null`

      The name of the tool to call on the server.

  - `ToolChoiceCustom object { name, type }`

    Use this option to force the model to call a specific custom tool.

    - `name: string`

      The name of the custom tool to call.

    - `type: "custom"`

      For custom tool calling, the type is always `custom`.

      - `"custom"`

  - `SpecificProgrammaticToolCallingParam object { type }`

    - `type: "programmatic_tool_calling"`

      The tool to call. Always `programmatic_tool_calling`.

      - `"programmatic_tool_calling"`

  - `ToolChoiceApplyPatch object { type }`

    Forces the model to call the apply_patch tool when executing a tool call.

    - `type: "apply_patch"`

      The tool to call. Always `apply_patch`.

      - `"apply_patch"`

  - `ToolChoiceShell object { type }`

    Forces the model to call the shell tool when a tool call is required.

    - `type: "shell"`

      The tool to call. Always `shell`.

      - `"shell"`

- `tools: optional array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

  An array of tools the model may call while generating a response. You
  can specify which tool to use by setting the `tool_choice` parameter.

  We support the following categories of tools:

  - **Built-in tools**: Tools that are provided by OpenAI that extend the
    model's capabilities, like [web search](/api/docs/guides/tools-web-search)
    or [file search](/api/docs/guides/tools-file-search). Learn more about
    [built-in tools](/api/docs/guides/tools).
  - **MCP Tools**: Integrations with third-party systems via custom MCP servers
    or predefined connectors such as Google Drive and SharePoint. Learn more about
    [MCP Tools](/api/docs/guides/tools-connectors-mcp).
  - **Function calls (custom tools)**: Functions that are defined by you,
    enabling the model to call your own code with strongly typed arguments
    and outputs. Learn more about
    [function calling](/api/docs/guides/function-calling). You can also use
    custom tools to call your own code.

  - `Function object { name, parameters, strict, 6 more }`

    Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

    - `name: string`

      The name of the function to call.

    - `parameters: map[unknown] or null`

      A JSON schema object describing the parameters of the function.

    - `strict: boolean or null`

      Whether strict parameter validation is enforced for this function tool.

    - `type: "function"`

      The type of the function tool. Always `function`.

      - `"function"`

    - `allowed_callers: optional array of "direct" or "programmatic" or null`

      The tool invocation context(s).

      - `"direct"`

      - `"programmatic"`

    - `async: optional boolean`

    - `defer_loading: optional boolean`

      Whether this function is deferred and loaded via tool search.

    - `description: optional string or null`

      A description of the function. Used by the model to determine whether or not to call the function.

    - `output_schema: optional map[unknown] or null`

      A JSON schema object describing the JSON value encoded in string outputs for this function.

  - `FileSearch object { type, vector_store_ids, filters, 2 more }`

    A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

    - `type: "file_search"`

      The type of the file search tool. Always `file_search`.

      - `"file_search"`

    - `vector_store_ids: array of string`

      The IDs of the vector stores to search.

    - `filters: optional ComparisonFilter or CompoundFilter or null`

      A filter to apply.

      - `ComparisonFilter object { key, type, value }`

        A filter used to compare a specified attribute key to a given value using a defined comparison operation.

      - `CompoundFilter object { filters, type }`

        Combine multiple filters using `and` or `or`.

    - `max_num_results: optional number`

      The maximum number of results to return. This number should be between 1 and 50 inclusive.

    - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

      Ranking options for search.

      - `hybrid_search: optional object { embedding_weight, text_weight }`

        Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

        - `embedding_weight: number`

          The weight of the embedding in the reciprocal ranking fusion.

        - `text_weight: number`

          The weight of the text in the reciprocal ranking fusion.

      - `ranker: optional "auto" or "default-2024-11-15"`

        The ranker to use for the file search.

        - `"auto"`

        - `"default-2024-11-15"`

      - `score_threshold: optional number`

        The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

  - `Computer object { type }`

    A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

    - `type: "computer"`

      The type of the computer tool. Always `computer`.

      - `"computer"`

  - `ComputerUsePreview object { display_height, display_width, environment, type }`

    A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

    - `display_height: number`

      The height of the computer display.

    - `display_width: number`

      The width of the computer display.

    - `environment: "windows" or "mac" or "linux" or 2 more`

      The type of computer environment to control.

      - `"windows"`

      - `"mac"`

      - `"linux"`

      - `"ubuntu"`

      - `"browser"`

    - `type: "computer_use_preview"`

      The type of the computer use tool. Always `computer_use_preview`.

      - `"computer_use_preview"`

  - `WebSearch object { type, external_web_access, filters, 2 more }`

    Search the Internet for sources related to the prompt. Learn more about the
    [web search tool](/api/docs/guides/tools-web-search).

    - `type: "web_search" or "web_search_2025_08_26"`

      The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

      - `"web_search"`

      - `"web_search_2025_08_26"`

    - `external_web_access: optional boolean`

      Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

    - `filters: optional object { allowed_domains }  or null`

      Filters for the search.

      - `allowed_domains: optional array of string or null`

        Allowed domains for the search. If not provided, all domains are allowed.
        Subdomains of the provided domains are allowed as well.

        Example: `["pubmed.ncbi.nlm.nih.gov"]`

    - `search_context_size: optional "low" or "medium" or "high"`

      High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

      - `"low"`

      - `"medium"`

      - `"high"`

    - `user_location: optional object { city, country, region, 2 more }  or null`

      The approximate location of the user. If omitted or null, defaults to the
      United States. To avoid this fallback, pass `{"type": "approximate"}` without
      location fields. To localize results, provide the relevant location fields.

      - `city: optional string or null`

        Free text input for the city of the user, e.g. `San Francisco`.

      - `country: optional string or null`

        The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

      - `region: optional string or null`

        Free text input for the region of the user, e.g. `California`.

      - `timezone: optional string or null`

        The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

      - `type: optional "approximate"`

        The type of location approximation. Always `approximate`.

        - `"approximate"`

  - `Mcp object { server_label, type, allowed_callers, 9 more }`

    Give the model access to additional tools via remote Model Context Protocol
    (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

    - `server_label: string`

      A label for this MCP server, used to identify it in tool calls.

    - `type: "mcp"`

      The type of the MCP tool. Always `mcp`.

      - `"mcp"`

    - `allowed_callers: optional array of "direct" or "programmatic" or null`

      The tool invocation context(s).

      - `"direct"`

      - `"programmatic"`

    - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

      List of allowed tool names or a filter object.

      - `McpAllowedTools = array of string`

        A string array of allowed tool names

      - `McpToolFilter object { read_only, tool_names }`

        A filter object to specify which tools are allowed.

        - `read_only: optional boolean`

          Indicates whether or not a tool modifies data or is read-only. If an
          MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
          it will match this filter.

        - `tool_names: optional array of string`

          List of allowed tool names.

    - `authorization: optional string`

      An OAuth access token that can be used with a remote MCP server, either
      with a custom MCP server URL or a service connector. Your application
      must handle the OAuth authorization flow and provide the token here.

    - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

      Identifier for service connectors, like those available in ChatGPT. One of
      `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
      about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

      This field is deprecated for models released after September 1, 2026.
      Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
      connect through a Secure MCP Tunnel.

      Currently supported `connector_id` values are:

      - Dropbox: `connector_dropbox`
      - Gmail: `connector_gmail`
      - Google Calendar: `connector_googlecalendar`
      - Google Drive: `connector_googledrive`
      - Microsoft Teams: `connector_microsoftteams`
      - Outlook Calendar: `connector_outlookcalendar`
      - Outlook Email: `connector_outlookemail`
      - SharePoint: `connector_sharepoint`

      - `"connector_dropbox"`

      - `"connector_gmail"`

      - `"connector_googlecalendar"`

      - `"connector_googledrive"`

      - `"connector_microsoftteams"`

      - `"connector_outlookcalendar"`

      - `"connector_outlookemail"`

      - `"connector_sharepoint"`

    - `defer_loading: optional boolean`

      Whether this MCP tool is deferred and discovered via tool search.

    - `headers: optional map[string] or null`

      Optional HTTP headers to send to the MCP server. Use for authentication
      or other purposes.

    - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

      Specify which of the MCP server's tools require approval.

      - `McpToolApprovalFilter object { always, never }`

        Specify which of the MCP server's tools require approval. Can be
        `always`, `never`, or a filter object associated with tools
        that require approval.

        - `always: optional object { read_only, tool_names }`

          A filter object to specify which tools are allowed.

          - `read_only: optional boolean`

            Indicates whether or not a tool modifies data or is read-only. If an
            MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
            it will match this filter.

          - `tool_names: optional array of string`

            List of allowed tool names.

        - `never: optional object { read_only, tool_names }`

          A filter object to specify which tools are allowed.

          - `read_only: optional boolean`

            Indicates whether or not a tool modifies data or is read-only. If an
            MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
            it will match this filter.

          - `tool_names: optional array of string`

            List of allowed tool names.

      - `McpToolApprovalSetting = "always" or "never"`

        Specify a single approval policy for all tools. One of `always` or
        `never`. When set to `always`, all tools will require approval. When
        set to `never`, all tools will not require approval.

        - `"always"`

        - `"never"`

    - `server_description: optional string`

      Optional description of the MCP server, used to provide more context.

    - `server_url: optional string`

      The URL for the MCP server. One of `server_url`, `connector_id`, or
      `tunnel_id` must be provided.

    - `tunnel_id: optional string`

      The Secure MCP Tunnel ID to use instead of a direct server URL. One of
      `server_url`, `connector_id`, or `tunnel_id` must be provided.

  - `CodeInterpreter object { container, type, allowed_callers }`

    A tool that runs Python code to help generate a response to a prompt.

    - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

      The code interpreter container. Can be a container ID or an object that
      specifies uploaded file IDs to make available to your code, along with an
      optional `memory_limit` setting.

      - `string`

        The container ID.

      - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

        Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

        - `type: "auto"`

          Always `auto`.

          - `"auto"`

        - `file_ids: optional array of string`

          An optional list of uploaded files to make available to your code.

        - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

          The memory limit for the code interpreter container.

          - `"1g"`

          - `"4g"`

          - `"16g"`

          - `"64g"`

        - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

          Network access policy for the container.

          - `ContainerNetworkPolicyDisabled object { type }`

          - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

    - `type: "code_interpreter"`

      The type of the code interpreter tool. Always `code_interpreter`.

      - `"code_interpreter"`

    - `allowed_callers: optional array of "direct" or "programmatic" or null`

      The tool invocation context(s).

      - `"direct"`

      - `"programmatic"`

  - `ProgrammaticToolCalling object { type }`

    - `type: "programmatic_tool_calling"`

      The type of the tool. Always `programmatic_tool_calling`.

      - `"programmatic_tool_calling"`

  - `ImageGeneration object { type, action, background, 9 more }`

    A tool that generates images using the GPT image models.

    - `type: "image_generation"`

      The type of the image generation tool. Always `image_generation`.

      - `"image_generation"`

    - `action: optional "generate" or "edit" or "auto"`

      Whether to generate a new image or edit an existing image. Default: `auto`.

      - `"generate"`

      - `"edit"`

      - `"auto"`

    - `background: optional "transparent" or "opaque" or "auto"`

      Set the background of the generated image. One of `transparent`, `opaque`,
      or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
      their `2026-09-08` snapshots, support `opaque` and `transparent`
      backgrounds. Transparent backgrounds are available for supported GPT Image
      models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
      preview. When using `transparent`, set the output format to `png` or `webp`.
      Default: `auto`.

      - `"transparent"`

      - `"opaque"`

      - `"auto"`

    - `input_fidelity: optional "high" or "low" or null`

      Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

      - `"high"`

      - `"low"`

    - `input_image_mask: optional object { file_id, image_url }`

      Optional mask for inpainting. Contains `image_url`
      (string, optional) and `file_id` (string, optional).

      - `file_id: optional string`

        File ID for the mask image.

      - `image_url: optional string`

        Base64-encoded mask image.

    - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

      The image generation model to use. One of `gpt-image-1`,
      `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
      `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
      `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
      `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
      `gpt-image-1`.

      - `string`

      - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

        The image generation model to use. One of `gpt-image-1`,
        `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
        `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
        `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
        `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
        `gpt-image-1`.

        - `"gpt-image-1"`

        - `"gpt-image-1-mini"`

        - `"gpt-image-1.5"`

        - `"gpt-image-2"`

        - `"gpt-image-2-2026-04-21"`

        - `"gpt-image-2.5-sunburst"`

        - `"gpt-image-2.5-sunburst-2026-09-08"`

        - `"gpt-image-2.5-flare"`

        - `"gpt-image-2.5-flare-2026-09-08"`

    - `moderation: optional "auto" or "low"`

      Moderation level for the generated image. Default: `auto`.

      - `"auto"`

      - `"low"`

    - `output_compression: optional number`

      Compression level for the output image. Default: 100.

    - `output_format: optional "png" or "webp" or "jpeg"`

      The output format of the generated image. One of `png`, `webp`, or
      `jpeg`. Default: `png`.

      - `"png"`

      - `"webp"`

      - `"jpeg"`

    - `partial_images: optional number`

      Number of partial images to generate in streaming mode, from 0 (default value) to 3.

    - `quality: optional "low" or "medium" or "high" or 3 more`

      The quality of the generated image. The GPT image models support `low`,
      `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
      including their `2026-09-08` snapshots, also support `xhigh` and `max`.
      Default: `auto`.

      - `"low"`

      - `"medium"`

      - `"high"`

      - `"xhigh"`

      - `"max"`

      - `"auto"`

    - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

      The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

      - `string`

      - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

        The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

        - `"1024x1024"`

        - `"1024x1536"`

        - `"1536x1024"`

        - `"auto"`

  - `LocalShell object { type }`

    A tool that allows the model to execute shell commands in a local environment.

    - `type: "local_shell"`

      The type of the local shell tool. Always `local_shell`.

      - `"local_shell"`

  - `Shell object { type, allowed_callers, environment }`

    A tool that allows the model to execute shell commands.

    - `type: "shell"`

      The type of the shell tool. Always `shell`.

      - `"shell"`

    - `allowed_callers: optional array of "direct" or "programmatic" or null`

      The tool invocation context(s).

      - `"direct"`

      - `"programmatic"`

    - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

      - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

      - `LocalEnvironment object { type, skills }`

      - `ContainerReference object { container_id, type }`

  - `Custom object { name, type, allowed_callers, 4 more }`

    A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

    - `name: string`

      The name of the custom tool, used to identify it in tool calls.

    - `type: "custom"`

      The type of the custom tool. Always `custom`.

      - `"custom"`

    - `allowed_callers: optional array of "direct" or "programmatic" or null`

      The tool invocation context(s).

      - `"direct"`

      - `"programmatic"`

    - `async: optional boolean`

      Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

    - `defer_loading: optional boolean`

      Whether this tool should be deferred and discovered via tool search.

    - `description: optional string`

      Optional description of the custom tool, used to provide more context.

    - `format: optional CustomToolInputFormat`

      The input format for the custom tool. Default is unconstrained text.

  - `Namespace object { description, name, tools, type }`

    Groups function/custom tools under a shared namespace.

    - `description: string`

      A description of the namespace shown to the model.

    - `name: string`

      The namespace name used in tool calls (for example, `crm`).

    - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

      The function/custom tools available inside this namespace.

      - `Function object { name, type, allowed_callers, 6 more }`

        - `name: string`

        - `type: "function"`

          - `"function"`

        - `allowed_callers: optional array of "direct" or "programmatic" or null`

          The tool invocation context(s).

          - `"direct"`

          - `"programmatic"`

        - `async: optional boolean`

          Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

        - `defer_loading: optional boolean`

          Whether this function should be deferred and discovered via tool search.

        - `description: optional string or null`

        - `output_schema: optional map[unknown] or null`

          A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

        - `parameters: optional unknown or null`

        - `strict: optional boolean or null`

          Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

      - `Custom object { name, type, allowed_callers, 4 more }`

        A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

        - `name: string`

          The name of the custom tool, used to identify it in tool calls.

        - `type: "custom"`

          The type of the custom tool. Always `custom`.

          - `"custom"`

        - `allowed_callers: optional array of "direct" or "programmatic" or null`

          The tool invocation context(s).

          - `"direct"`

          - `"programmatic"`

        - `async: optional boolean`

          Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

        - `defer_loading: optional boolean`

          Whether this tool should be deferred and discovered via tool search.

        - `description: optional string`

          Optional description of the custom tool, used to provide more context.

        - `format: optional CustomToolInputFormat`

          The input format for the custom tool. Default is unconstrained text.

    - `type: "namespace"`

      The type of the tool. Always `namespace`.

      - `"namespace"`

  - `ToolSearch object { type, description, execution, parameters }`

    Hosted or BYOT tool search configuration for deferred tools.

    - `type: "tool_search"`

      The type of the tool. Always `tool_search`.

      - `"tool_search"`

    - `description: optional string or null`

      Description shown to the model for a client-executed tool search tool.

    - `execution: optional "server" or "client"`

      Whether tool search is executed by the server or by the client.

      - `"server"`

      - `"client"`

    - `parameters: optional unknown or null`

      Parameter schema for a client-executed tool search tool.

  - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

    This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

    - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

      The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

      - `"web_search_preview"`

      - `"web_search_preview_2025_03_11"`

    - `search_content_types: optional array of "text" or "image"`

      - `"text"`

      - `"image"`

    - `search_context_size: optional "low" or "medium" or "high"`

      High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

      - `"low"`

      - `"medium"`

      - `"high"`

    - `user_location: optional object { type, city, country, 2 more }  or null`

      The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

      - `type: "approximate"`

        The type of location approximation. Always `approximate`.

        - `"approximate"`

      - `city: optional string or null`

        Free text input for the city of the user, e.g. `San Francisco`.

      - `country: optional string or null`

        The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

      - `region: optional string or null`

        Free text input for the region of the user, e.g. `California`.

      - `timezone: optional string or null`

        The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

  - `ApplyPatch object { type, allowed_callers }`

    Allows the assistant to create, delete, or update files using unified diffs.

    - `type: "apply_patch"`

      The type of the tool. Always `apply_patch`.

      - `"apply_patch"`

    - `allowed_callers: optional array of "direct" or "programmatic" or null`

      The tool invocation context(s).

      - `"direct"`

      - `"programmatic"`

- `top_logprobs: optional number or null`

  An integer between 0 and 20 specifying the maximum number of most likely
  tokens to return at each token position, each with an associated log
  probability. In some cases, the number of returned tokens may be fewer than
  requested.

- `top_p: optional number or null`

  An alternative to sampling with temperature, called nucleus sampling,
  where the model considers the results of the tokens with top_p probability
  mass. So 0.1 means only the tokens comprising the top 10% probability mass
  are considered.

  We generally recommend altering this or `temperature` but not both.

- `truncation: optional "auto" or "disabled" or null`

  The truncation strategy to use for the model response.

  - `auto`: If the input to this Response exceeds
    the model's context window size, the model will truncate the
    response to fit the context window by dropping items from the beginning of the conversation.
  - `disabled` (default): If the input size will exceed the context window
    size for a model, the request will fail with a 400 error.

  - `"auto"`

  - `"disabled"`

- `user: optional string or null`

  This field is being replaced by `safety_identifier` and `prompt_cache_key`. Use `prompt_cache_key` instead to maintain caching optimizations.
  A stable identifier for your end-users.
  Used to boost cache hit rates by better bucketing similar requests and  to help OpenAI detect and prevent abuse. [Learn more](/api/docs/guides/safety-best-practices#implement-safety-identifiers).

### Returns

- `Response object { id, access_programs, created_at, 34 more }`

  - `id: string`

    Unique identifier for this Response.

  - `access_programs: object { cyber }  or null`

    - `cyber: "standard" or "daybreak_blue" or "daybreak_red"`

      The effective Cyber access program used for this response.

      - `"standard"`

      - `"daybreak_blue"`

      - `"daybreak_red"`

  - `created_at: number`

    Unix timestamp (in seconds) of when this Response was created.

  - `error: ResponseError or null`

    An error object returned when the model fails to generate a Response.

    - `code: "server_error" or "rate_limit_exceeded" or "invalid_prompt" or 18 more`

      The error code for the response.

      - `"server_error"`

      - `"rate_limit_exceeded"`

      - `"invalid_prompt"`

      - `"data_residency_mismatch"`

      - `"bio_policy"`

      - `"misalignment_policy_violation"`

      - `"vector_store_timeout"`

      - `"invalid_image"`

      - `"invalid_image_format"`

      - `"invalid_base64_image"`

      - `"invalid_image_url"`

      - `"image_too_large"`

      - `"image_too_small"`

      - `"image_parse_error"`

      - `"image_content_policy_violation"`

      - `"invalid_image_mode"`

      - `"image_file_too_large"`

      - `"unsupported_image_media_type"`

      - `"empty_image_file"`

      - `"failed_to_download_image"`

      - `"image_file_not_found"`

    - `message: string`

      A human-readable description of the error.

    - `misalignment: optional object { detailed_explanation, error_type, review_target, steer }`

      - `detailed_explanation: optional string`

        The public explanation for this block.

      - `error_type: optional string or "potentially_unintended_data_transfer" or "potentially_unintended_data_access" or "potentially_unintended_destructive_activity" or "other"`

        An optional classification; clients must accept additional values.

        - `string`

        - `SafetyAlertErrorType = "potentially_unintended_data_transfer" or "potentially_unintended_data_access" or "potentially_unintended_destructive_activity" or "other"`

          An optional classification; clients must accept additional values.

          - `"potentially_unintended_data_transfer"`

          - `"potentially_unintended_data_access"`

          - `"potentially_unintended_destructive_activity"`

          - `"other"`

      - `review_target: optional string or null`

        An opaque target for explicitly continuing this review, or null when unavailable.

      - `steer: optional object { message }`

        An optional public continuation instruction.

        - `message: string`

          The public continuation instruction.

    - `param: optional string or null`

      The request parameter associated with the error, or null if none was recorded.

    - `type: optional string or null`

      The original error type, or null if it was not recorded.

  - `incomplete_details: object { reason }  or null`

    Details about why the response is incomplete.

    - `reason: optional "max_output_tokens" or "max_messages" or "content_filter" or "steered"`

      The reason why the response is incomplete. `steered` means
      the response stopped at a safe output boundary after a
      WebSocket `response.steer` event. The server can then create
      a successor response automatically with the queued input.

      - `"max_output_tokens"`

      - `"max_messages"`

      - `"content_filter"`

      - `"steered"`

  - `instructions: string or array of EasyInputMessage or Message { content, role, status, type }  or ResponseOutputMessage or 30 more or null`

    A system (or developer) message inserted into the model's context.

    When using along with `previous_response_id`, the instructions from a previous
    response will not be carried over to the next response. This makes it simple
    to swap out system (or developer) messages in new responses.

    - `string`

      A text input to the model, equivalent to a text input with the
      `developer` role.

    - `InputItemList = array of EasyInputMessage or Message { content, role, status, type }  or ResponseOutputMessage or 30 more`

      A list of one or many input items to the model, containing
      different content types.

      - `EasyInputMessage object { content, role, phase, type }`

        A message input to the model with a role indicating instruction following
        hierarchy. Instructions given with the `developer` or `system` role take
        precedence over instructions given with the `user` role. Messages with the
        `assistant` role are presumed to have been generated by the model in previous
        interactions.

        - `content: string or ResponseInputMessageContentList`

          Text, image, or audio input to the model, used to generate a response.
          Can also contain previous assistant responses.

          - `TextInput = string`

            A text input to the model.

          - `ResponseInputMessageContentList = array of ResponseInputContent`

            A list of one or many input items to the model, containing different content
            types.

            - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

              A text input to the model.

              - `text: string`

                The text input to the model.

              - `type: "input_text"`

                The type of the input item. Always `input_text`.

                - `"input_text"`

              - `prompt_cache_breakpoint: optional object { mode }`

                Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

                - `mode: "explicit"`

                  The breakpoint mode. Always `explicit`.

                  - `"explicit"`

            - `ResponseInputImage object { detail, type, file_id, 2 more }`

              An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

              - `detail: ImageDetail`

                The detail level of the image to be sent to the model. One of `high`, `low`, `auto`, or `original`. Defaults to `auto`.

                - `"low"`

                - `"high"`

                - `"auto"`

                - `"original"`

              - `type: "input_image"`

                The type of the input item. Always `input_image`.

                - `"input_image"`

              - `file_id: optional string or null`

                The ID of the file to be sent to the model.

              - `image_url: optional string or null`

                The URL of the image to be sent to the model. A fully qualified URL or base64 encoded image in a data URL.

              - `prompt_cache_breakpoint: optional object { mode }`

                Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

                - `mode: "explicit"`

                  The breakpoint mode. Always `explicit`.

                  - `"explicit"`

            - `ResponseInputFile object { type, detail, file_data, 4 more }`

              A file input to the model.

              - `type: "input_file"`

                The type of the input item. Always `input_file`.

                - `"input_file"`

              - `detail: optional "auto" or "low" or "high"`

                The detail level of the file to be sent to the model. Use `auto` to let the system select the detail level; for GPT-5.6 and later models, `auto` uses high-quality rendering, which may increase input token usage. Use `low` for lower-cost rendering, or `high` to render the file at higher quality. Defaults to `auto`.

                - `"auto"`

                - `"low"`

                - `"high"`

              - `file_data: optional string`

                The content of the file to be sent to the model.

              - `file_id: optional string or null`

                The ID of the file to be sent to the model.

              - `file_url: optional string`

                The URL of the file to be sent to the model.

              - `filename: optional string`

                The name of the file to be sent to the model.

              - `prompt_cache_breakpoint: optional object { mode }`

                Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

                - `mode: "explicit"`

                  The breakpoint mode. Always `explicit`.

                  - `"explicit"`

        - `role: "user" or "assistant" or "system" or "developer"`

          The role of the message input. One of `user`, `assistant`, `system`, or
          `developer`.

          - `"user"`

          - `"assistant"`

          - `"system"`

          - `"developer"`

        - `phase: optional "commentary" or "final_answer" or null`

          Labels an `assistant` message as intermediate commentary (`commentary`) or the final answer (`final_answer`).
          For models like `gpt-5.3-codex` and beyond, when sending follow-up requests, preserve and resend
          phase on all assistant messages — dropping it can degrade performance. Not used for user messages.

          - `"commentary"`

          - `"final_answer"`

        - `type: optional "message"`

          The type of the message input. Always `message`.

          - `"message"`

      - `Message object { content, role, status, type }`

        A message input to the model with a role indicating instruction following
        hierarchy. Instructions given with the `developer` or `system` role take
        precedence over instructions given with the `user` role.

        - `content: ResponseInputMessageContentList`

          A list of one or many input items to the model, containing different content
          types.

        - `role: "user" or "system" or "developer"`

          The role of the message input. One of `user`, `system`, or `developer`.

          - `"user"`

          - `"system"`

          - `"developer"`

        - `status: optional "in_progress" or "completed" or "incomplete"`

          The status of item. One of `in_progress`, `completed`, or
          `incomplete`. Populated when items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

        - `type: optional "message"`

          The type of the message input. Always set to `message`.

          - `"message"`

      - `ResponseOutputMessage object { id, content, role, 3 more }`

        An output message from the model.

        - `id: string`

          The unique ID of the output message.

        - `content: array of ResponseOutputText or ResponseOutputRefusal`

          The content of the output message.

          - `ResponseOutputText object { annotations, logprobs, text, type }`

            A text output from the model.

            - `annotations: array of FileCitation { file_id, filename, index, type }  or URLCitation { end_index, start_index, title, 2 more }  or ContainerFileCitation { container_id, end_index, file_id, 3 more }  or FilePath { file_id, index, type }`

              The annotations of the text output.

              - `FileCitation object { file_id, filename, index, type }`

                A citation to a file.

                - `file_id: string`

                  The ID of the file.

                - `filename: string`

                  The filename of the file cited.

                - `index: number`

                  The index in the output text at which to insert the file citation.

                - `type: "file_citation"`

                  The type of the file citation. Always `file_citation`.

                  - `"file_citation"`

              - `URLCitation object { end_index, start_index, title, 2 more }`

                A citation for a web resource used to generate a model response.

                - `end_index: number`

                  The index of the last character of the URL citation in the message.

                - `start_index: number`

                  The index of the first character of the URL citation in the message.

                - `title: string`

                  The title of the web resource.

                - `type: "url_citation"`

                  The type of the URL citation. Always `url_citation`.

                  - `"url_citation"`

                - `url: string`

                  The URL of the web resource.

              - `ContainerFileCitation object { container_id, end_index, file_id, 3 more }`

                A citation for a container file used to generate a model response.

                - `container_id: string`

                  The ID of the container file.

                - `end_index: number`

                  The index of the last character of the container file citation in the message.

                - `file_id: string`

                  The ID of the file.

                - `filename: string`

                  The filename of the container file cited.

                - `start_index: number`

                  The index of the first character of the container file citation in the message.

                - `type: "container_file_citation"`

                  The type of the container file citation. Always `container_file_citation`.

                  - `"container_file_citation"`

              - `FilePath object { file_id, index, type }`

                A path to a file.

                - `file_id: string`

                  The ID of the file.

                - `index: number`

                  The index of the file in the list of files.

                - `type: "file_path"`

                  The type of the file path. Always `file_path`.

                  - `"file_path"`

            - `logprobs: array of object { token, bytes, logprob, top_logprobs }`

              - `token: string`

              - `bytes: array of number`

              - `logprob: number`

              - `top_logprobs: array of object { token, bytes, logprob }`

                - `token: string`

                - `bytes: array of number`

                - `logprob: number`

            - `text: string`

              The text output from the model.

            - `type: "output_text"`

              The type of the output text. Always `output_text`.

              - `"output_text"`

          - `ResponseOutputRefusal object { refusal, type }`

            A refusal from the model.

            - `refusal: string`

              The refusal explanation from the model.

            - `type: "refusal"`

              The type of the refusal. Always `refusal`.

              - `"refusal"`

        - `role: "assistant"`

          The role of the output message. Always `assistant`.

          - `"assistant"`

        - `status: "in_progress" or "completed" or "incomplete"`

          The status of the message input. One of `in_progress`, `completed`, or
          `incomplete`. Populated when input items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

        - `type: "message"`

          The type of the output message. Always `message`.

          - `"message"`

        - `phase: optional "commentary" or "final_answer" or null`

          Labels an `assistant` message as intermediate commentary (`commentary`) or the final answer (`final_answer`).
          For models like `gpt-5.3-codex` and beyond, when sending follow-up requests, preserve and resend
          phase on all assistant messages — dropping it can degrade performance. Not used for user messages.

          - `"commentary"`

          - `"final_answer"`

      - `FileSearchCall object { id, queries, status, 2 more }`

        The results of a file search tool call. See the
        [file search guide](/api/docs/guides/tools-file-search) for more information.

        - `id: string`

          The unique ID of the file search tool call.

        - `queries: array of string`

          The queries used to search for files.

        - `status: "in_progress" or "searching" or "completed" or 2 more`

          The status of the file search tool call. One of `in_progress`,
          `searching`, `incomplete` or `failed`,

          - `"in_progress"`

          - `"searching"`

          - `"completed"`

          - `"incomplete"`

          - `"failed"`

        - `type: "file_search_call"`

          The type of the file search tool call. Always `file_search_call`.

          - `"file_search_call"`

        - `results: optional array of object { attributes, file_id, filename, 2 more }  or null`

          The results of the file search tool call.

          - `attributes: optional map[string or number or boolean] or null`

            Set of 16 key-value pairs that can be attached to an object. This can be
            useful for storing additional information about the object in a structured
            format, and querying for objects via API or the dashboard. Keys are strings
            with a maximum length of 64 characters. Values are strings with a maximum
            length of 512 characters, booleans, or numbers.

            - `string`

            - `number`

            - `boolean`

          - `file_id: optional string`

            The unique ID of the file.

          - `filename: optional string`

            The name of the file.

          - `score: optional number`

            The relevance score of the file - a value between 0 and 1.

          - `text: optional string`

            The text that was retrieved from the file.

      - `ComputerCall object { id, call_id, pending_safety_checks, 4 more }`

        A tool call to a computer use tool. See the
        [computer use guide](/api/docs/guides/tools-computer-use) for more information.

        - `id: string`

          The unique ID of the computer call.

        - `call_id: string`

          An identifier used when responding to the tool call with output.

        - `pending_safety_checks: array of object { id, code, message }`

          The pending safety checks for the computer call.

          - `id: string`

            The ID of the pending safety check.

          - `code: optional string or null`

            The type of the pending safety check.

          - `message: optional string or null`

            Details about the pending safety check.

        - `status: "in_progress" or "completed" or "incomplete"`

          The status of the item. One of `in_progress`, `completed`, or
          `incomplete`. Populated when items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

        - `type: "computer_call"`

          The type of the computer call. Always `computer_call`.

          - `"computer_call"`

        - `action: optional ComputerAction`

          A click action.

          - `Click object { button, type, x, 2 more }`

            A click action.

            - `button: "left" or "right" or "wheel" or 2 more`

              Indicates which mouse button was pressed during the click. One of `left`, `right`, `wheel`, `back`, or `forward`.

              - `"left"`

              - `"right"`

              - `"wheel"`

              - `"back"`

              - `"forward"`

            - `type: "click"`

              Specifies the event type. For a click action, this property is always `click`.

              - `"click"`

            - `x: number`

              The x-coordinate where the click occurred.

            - `y: number`

              The y-coordinate where the click occurred.

            - `keys: optional array of string or null`

              The keys being held while clicking.

          - `DoubleClick object { keys, type, x, y }`

            A double click action.

            - `keys: array of string or null`

              The keys being held while double-clicking.

            - `type: "double_click"`

              Specifies the event type. For a double click action, this property is always set to `double_click`.

              - `"double_click"`

            - `x: number`

              The x-coordinate where the double click occurred.

            - `y: number`

              The y-coordinate where the double click occurred.

          - `Drag object { path, type, keys }`

            A drag action.

            - `path: array of object { x, y }`

              An array of coordinates representing the path of the drag action. Coordinates will appear as an array of objects, eg

              ```
              [
                { x: 100, y: 200 },
                { x: 200, y: 300 }
              ]
              ```

              - `x: number`

                The x-coordinate.

              - `y: number`

                The y-coordinate.

            - `type: "drag"`

              Specifies the event type. For a drag action, this property is always set to `drag`.

              - `"drag"`

            - `keys: optional array of string or null`

              The keys being held while dragging the mouse.

          - `Keypress object { keys, type }`

            A collection of keypresses the model would like to perform.

            - `keys: array of string`

              The combination of keys the model is requesting to be pressed. This is an array of strings, each representing a key.

            - `type: "keypress"`

              Specifies the event type. For a keypress action, this property is always set to `keypress`.

              - `"keypress"`

          - `Move object { type, x, y, keys }`

            A mouse move action.

            - `type: "move"`

              Specifies the event type. For a move action, this property is always set to `move`.

              - `"move"`

            - `x: number`

              The x-coordinate to move to.

            - `y: number`

              The y-coordinate to move to.

            - `keys: optional array of string or null`

              The keys being held while moving the mouse.

          - `Screenshot object { type }`

            A screenshot action.

            - `type: "screenshot"`

              Specifies the event type. For a screenshot action, this property is always set to `screenshot`.

              - `"screenshot"`

          - `Scroll object { scroll_x, scroll_y, type, 3 more }`

            A scroll action.

            - `scroll_x: number`

              The horizontal scroll distance.

            - `scroll_y: number`

              The vertical scroll distance.

            - `type: "scroll"`

              Specifies the event type. For a scroll action, this property is always set to `scroll`.

              - `"scroll"`

            - `x: number`

              The x-coordinate where the scroll occurred.

            - `y: number`

              The y-coordinate where the scroll occurred.

            - `keys: optional array of string or null`

              The keys being held while scrolling.

          - `Type object { text, type }`

            An action to type in text.

            - `text: string`

              The text to type.

            - `type: "type"`

              Specifies the event type. For a type action, this property is always set to `type`.

              - `"type"`

          - `Wait object { type }`

            A wait action.

            - `type: "wait"`

              Specifies the event type. For a wait action, this property is always set to `wait`.

              - `"wait"`

        - `actions: optional ComputerActionList`

          Flattened batched actions for `computer_use`. Each action includes an
          `type` discriminator and action-specific fields.

          - `Click object { button, type, x, 2 more }`

            A click action.

          - `DoubleClick object { keys, type, x, y }`

            A double click action.

          - `Drag object { path, type, keys }`

            A drag action.

          - `Keypress object { keys, type }`

            A collection of keypresses the model would like to perform.

          - `Move object { type, x, y, keys }`

            A mouse move action.

          - `Screenshot object { type }`

            A screenshot action.

          - `Scroll object { scroll_x, scroll_y, type, 3 more }`

            A scroll action.

          - `Type object { text, type }`

            An action to type in text.

          - `Wait object { type }`

            A wait action.

      - `ComputerCallOutput object { call_id, output, type, 3 more }`

        The output of a computer tool call.

        - `call_id: string`

          The ID of the computer tool call that produced the output.

        - `output: ResponseComputerToolCallOutputScreenshot`

          A computer screenshot image used with the computer use tool.

          - `type: "computer_screenshot"`

            Specifies the event type. For a computer screenshot, this property is
            always set to `computer_screenshot`.

            - `"computer_screenshot"`

          - `file_id: optional string`

            The identifier of an uploaded file that contains the screenshot.

          - `image_url: optional string`

            The URL of the screenshot image.

        - `type: "computer_call_output"`

          The type of the computer tool call output. Always `computer_call_output`.

          - `"computer_call_output"`

        - `id: optional string or null`

          The ID of the computer tool call output.

        - `acknowledged_safety_checks: optional array of object { id, code, message }  or null`

          The safety checks reported by the API that have been acknowledged by the developer.

          - `id: string`

            The ID of the pending safety check.

          - `code: optional string or null`

            The type of the pending safety check.

          - `message: optional string or null`

            Details about the pending safety check.

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the message input. One of `in_progress`, `completed`, or `incomplete`. Populated when input items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `WebSearchCall object { id, status, type, action }`

        The results of a web search tool call. See the
        [web search guide](/api/docs/guides/tools-web-search) for more information.

        - `id: string`

          The unique ID of the web search tool call.

        - `status: "in_progress" or "searching" or "completed" or 2 more`

          The status of the web search tool call.

          - `"in_progress"`

          - `"searching"`

          - `"completed"`

          - `"failed"`

          - `"incomplete"`

        - `type: "web_search_call"`

          The type of the web search tool call. Always `web_search_call`.

          - `"web_search_call"`

        - `action: optional Search { type, queries, query, sources }  or OpenPage { type, url }  or FindInPage { pattern, type, url }`

          An object describing the specific action taken in this web search call.
          Includes details on how the model used the web (search, open_page, find_in_page).

          - `Search object { type, queries, query, sources }`

            Action type "search" - Performs a web search query.

            - `type: "search"`

              The action type.

              - `"search"`

            - `queries: optional array of string`

              The search queries.

            - `query: optional string`

              The search query.

            - `sources: optional array of object { type, url }`

              The sources used in the search.

              - `type: "url"`

                The type of source. Always `url`.

                - `"url"`

              - `url: string`

                The URL of the source.

          - `OpenPage object { type, url }`

            Action type "open_page" - Opens a specific URL from search results.

            - `type: "open_page"`

              The action type.

              - `"open_page"`

            - `url: optional string or null`

              The URL opened by the model.

          - `FindInPage object { pattern, type, url }`

            Action type "find_in_page": Searches for a pattern within a loaded page.

            - `pattern: string`

              The pattern or text to search for within the page.

            - `type: "find_in_page"`

              The action type.

              - `"find_in_page"`

            - `url: optional string or null`

              The URL of the page searched for the pattern, when available.

      - `FunctionCall object { arguments, call_id, name, 6 more }`

        A tool call to run a function. See the
        [function calling guide](/api/docs/guides/function-calling) for more information.

        - `arguments: string`

          A JSON string of the arguments to pass to the function.

        - `call_id: string`

          The unique ID of the function tool call generated by the model.

        - `name: string`

          The name of the function to run.

        - `type: "function_call"`

          The type of the function tool call. Always `function_call`.

          - `"function_call"`

        - `id: optional string`

          The unique ID of the function tool call.

        - `async: optional boolean`

          Whether the function tool call runs asynchronously.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              - `"program"`

        - `namespace: optional string`

          The namespace of the function to run.

        - `status: optional "in_progress" or "completed" or "incomplete"`

          The status of the item. One of `in_progress`, `completed`, or
          `incomplete`. Populated when items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `FunctionCallOutput object { output, type, id, 5 more }`

        The output of a function tool call.

        - `output: string or array of ResponseInputTextContent or ResponseInputImageContent or ResponseInputFileContent`

          Text, image, or file output of the function tool call.

          - `string`

            A JSON string of the output of the function tool call.

          - `array of ResponseInputTextContent or ResponseInputImageContent or ResponseInputFileContent`

            An array of content outputs (text, image, file) for the function tool call.

            - `ResponseInputTextContent object { text, type, prompt_cache_breakpoint }`

              A text input to the model.

              - `text: string`

                The text input to the model.

              - `type: "input_text"`

                The type of the input item. Always `input_text`.

                - `"input_text"`

              - `prompt_cache_breakpoint: optional object { mode, ttl }  or null`

                Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

                - `mode: "explicit"`

                  The breakpoint mode. Always `explicit`.

                  - `"explicit"`

                - `ttl: optional "30m" or "12h"`

                  The minimum lifetime of this cache breakpoint. Defaults to the request TTL.

                  - `"30m"`

                  - `"12h"`

            - `ResponseInputImageContent object { type, detail, file_id, 2 more }`

              An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision)

              - `type: "input_image"`

                The type of the input item. Always `input_image`.

                - `"input_image"`

              - `detail: optional ImageDetail or null`

                The detail level of the image to be sent to the model. One of `high`, `low`, `auto`, or `original`. Defaults to `auto`.

              - `file_id: optional string or null`

                The ID of the file to be sent to the model.

              - `image_url: optional string or null`

                The URL of the image to be sent to the model. A fully qualified URL or base64 encoded image in a data URL.

              - `prompt_cache_breakpoint: optional object { mode, ttl }  or null`

                Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

                - `mode: "explicit"`

                  The breakpoint mode. Always `explicit`.

                  - `"explicit"`

                - `ttl: optional "30m" or "12h"`

                  The minimum lifetime of this cache breakpoint. Defaults to the request TTL.

                  - `"30m"`

                  - `"12h"`

            - `ResponseInputFileContent object { type, detail, file_data, 4 more }`

              A file input to the model.

              - `type: "input_file"`

                The type of the input item. Always `input_file`.

                - `"input_file"`

              - `detail: optional "auto" or "low" or "high"`

                The detail level of the file to be sent to the model. Use `auto` to let the system select the detail level; for GPT-5.6 and later models, `auto` uses high-quality rendering, which may increase input token usage. Use `low` for lower-cost rendering, or `high` to render the file at higher quality. Defaults to `auto`.

                - `"auto"`

                - `"low"`

                - `"high"`

              - `file_data: optional string or null`

                The base64-encoded data of the file to be sent to the model.

              - `file_id: optional string or null`

                The ID of the file to be sent to the model.

              - `file_url: optional string or null`

                The URL of the file to be sent to the model.

              - `filename: optional string or null`

                The name of the file to be sent to the model.

              - `prompt_cache_breakpoint: optional object { mode, ttl }  or null`

                Marks the exact end of a reusable prompt prefix. The breakpoint inherits its TTL from the request's `prompt_cache_options.ttl`; the boundary is not rounded to a token block.

                - `mode: "explicit"`

                  The breakpoint mode. Always `explicit`.

                  - `"explicit"`

                - `ttl: optional "30m" or "12h"`

                  The minimum lifetime of this cache breakpoint. Defaults to the request TTL.

                  - `"30m"`

                  - `"12h"`

        - `type: "function_call_output"`

          The type of the function tool call output. Always `function_call_output`.

          - `"function_call_output"`

        - `id: optional string or null`

          The unique ID of the function tool call output. Populated when this item is returned via API.

        - `call_id: optional string or null`

          The unique ID of the function tool call generated by the model.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              The caller type. Always `direct`.

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              The caller type. Always `program`.

              - `"program"`

        - `name: optional string or null`

          The name of the tool that produced the output.

        - `namespace: optional string or null`

          The namespace of the tool that produced the output.

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the item. One of `in_progress`, `completed`, or `incomplete`. Populated when items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `ToolSearchCall object { arguments, type, id, 3 more }`

        - `arguments: unknown`

          The arguments supplied to the tool search call.

        - `type: "tool_search_call"`

          The item type. Always `tool_search_call`.

          - `"tool_search_call"`

        - `id: optional string or null`

          The unique ID of this tool search call.

        - `call_id: optional string or null`

          The unique ID of the tool search call generated by the model.

        - `execution: optional "server" or "client"`

          Whether tool search was executed by the server or by the client.

          - `"server"`

          - `"client"`

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the tool search call.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `ToolSearchOutput object { tools, type, id, 3 more }`

        - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

          The loaded tool definitions returned by the tool search output.

          - `Function object { name, parameters, strict, 6 more }`

            Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

            - `name: string`

              The name of the function to call.

            - `parameters: map[unknown] or null`

              A JSON schema object describing the parameters of the function.

            - `strict: boolean or null`

              Whether strict parameter validation is enforced for this function tool.

            - `type: "function"`

              The type of the function tool. Always `function`.

              - `"function"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `async: optional boolean`

            - `defer_loading: optional boolean`

              Whether this function is deferred and loaded via tool search.

            - `description: optional string or null`

              A description of the function. Used by the model to determine whether or not to call the function.

            - `output_schema: optional map[unknown] or null`

              A JSON schema object describing the JSON value encoded in string outputs for this function.

          - `FileSearch object { type, vector_store_ids, filters, 2 more }`

            A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

            - `type: "file_search"`

              The type of the file search tool. Always `file_search`.

              - `"file_search"`

            - `vector_store_ids: array of string`

              The IDs of the vector stores to search.

            - `filters: optional ComparisonFilter or CompoundFilter or null`

              A filter to apply.

              - `ComparisonFilter object { key, type, value }`

                A filter used to compare a specified attribute key to a given value using a defined comparison operation.

                - `key: string`

                  The key to compare against the value.

                - `type: "eq" or "ne" or "gt" or 5 more`

                  Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`, `nin`.

                  - `eq`: equals
                  - `ne`: not equal
                  - `gt`: greater than
                  - `gte`: greater than or equal
                  - `lt`: less than
                  - `lte`: less than or equal
                  - `in`: in
                  - `nin`: not in

                  - `"eq"`

                  - `"ne"`

                  - `"gt"`

                  - `"gte"`

                  - `"lt"`

                  - `"lte"`

                  - `"in"`

                  - `"nin"`

                - `value: string or number or boolean or array of string or number`

                  The value to compare against the attribute key; supports string, number, or boolean types.

                  - `string`

                  - `number`

                  - `boolean`

                  - `array of string or number`

                    - `string`

                    - `number`

              - `CompoundFilter object { filters, type }`

                Combine multiple filters using `and` or `or`.

                - `filters: array of ComparisonFilter or CompoundFilter`

                  Array of filters to combine. Items can be `ComparisonFilter` or `CompoundFilter`.

                  - `ComparisonFilter object { key, type, value }`

                    A filter used to compare a specified attribute key to a given value using a defined comparison operation.

                  - `CompoundFilter object { filters, type }`

                    Combine multiple filters using `and` or `or`.

                - `type: "and" or "or"`

                  Type of operation: `and` or `or`.

                  - `"and"`

                  - `"or"`

            - `max_num_results: optional number`

              The maximum number of results to return. This number should be between 1 and 50 inclusive.

            - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

              Ranking options for search.

              - `hybrid_search: optional object { embedding_weight, text_weight }`

                Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

                - `embedding_weight: number`

                  The weight of the embedding in the reciprocal ranking fusion.

                - `text_weight: number`

                  The weight of the text in the reciprocal ranking fusion.

              - `ranker: optional "auto" or "default-2024-11-15"`

                The ranker to use for the file search.

                - `"auto"`

                - `"default-2024-11-15"`

              - `score_threshold: optional number`

                The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

          - `Computer object { type }`

            A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

            - `type: "computer"`

              The type of the computer tool. Always `computer`.

              - `"computer"`

          - `ComputerUsePreview object { display_height, display_width, environment, type }`

            A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

            - `display_height: number`

              The height of the computer display.

            - `display_width: number`

              The width of the computer display.

            - `environment: "windows" or "mac" or "linux" or 2 more`

              The type of computer environment to control.

              - `"windows"`

              - `"mac"`

              - `"linux"`

              - `"ubuntu"`

              - `"browser"`

            - `type: "computer_use_preview"`

              The type of the computer use tool. Always `computer_use_preview`.

              - `"computer_use_preview"`

          - `WebSearch object { type, external_web_access, filters, 2 more }`

            Search the Internet for sources related to the prompt. Learn more about the
            [web search tool](/api/docs/guides/tools-web-search).

            - `type: "web_search" or "web_search_2025_08_26"`

              The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

              - `"web_search"`

              - `"web_search_2025_08_26"`

            - `external_web_access: optional boolean`

              Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

            - `filters: optional object { allowed_domains }  or null`

              Filters for the search.

              - `allowed_domains: optional array of string or null`

                Allowed domains for the search. If not provided, all domains are allowed.
                Subdomains of the provided domains are allowed as well.

                Example: `["pubmed.ncbi.nlm.nih.gov"]`

            - `search_context_size: optional "low" or "medium" or "high"`

              High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

              - `"low"`

              - `"medium"`

              - `"high"`

            - `user_location: optional object { city, country, region, 2 more }  or null`

              The approximate location of the user. If omitted or null, defaults to the
              United States. To avoid this fallback, pass `{"type": "approximate"}` without
              location fields. To localize results, provide the relevant location fields.

              - `city: optional string or null`

                Free text input for the city of the user, e.g. `San Francisco`.

              - `country: optional string or null`

                The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

              - `region: optional string or null`

                Free text input for the region of the user, e.g. `California`.

              - `timezone: optional string or null`

                The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

              - `type: optional "approximate"`

                The type of location approximation. Always `approximate`.

                - `"approximate"`

          - `Mcp object { server_label, type, allowed_callers, 9 more }`

            Give the model access to additional tools via remote Model Context Protocol
            (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

            - `server_label: string`

              A label for this MCP server, used to identify it in tool calls.

            - `type: "mcp"`

              The type of the MCP tool. Always `mcp`.

              - `"mcp"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

              List of allowed tool names or a filter object.

              - `McpAllowedTools = array of string`

                A string array of allowed tool names

              - `McpToolFilter object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

            - `authorization: optional string`

              An OAuth access token that can be used with a remote MCP server, either
              with a custom MCP server URL or a service connector. Your application
              must handle the OAuth authorization flow and provide the token here.

            - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

              Identifier for service connectors, like those available in ChatGPT. One of
              `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
              about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

              This field is deprecated for models released after September 1, 2026.
              Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
              connect through a Secure MCP Tunnel.

              Currently supported `connector_id` values are:

              - Dropbox: `connector_dropbox`
              - Gmail: `connector_gmail`
              - Google Calendar: `connector_googlecalendar`
              - Google Drive: `connector_googledrive`
              - Microsoft Teams: `connector_microsoftteams`
              - Outlook Calendar: `connector_outlookcalendar`
              - Outlook Email: `connector_outlookemail`
              - SharePoint: `connector_sharepoint`

              - `"connector_dropbox"`

              - `"connector_gmail"`

              - `"connector_googlecalendar"`

              - `"connector_googledrive"`

              - `"connector_microsoftteams"`

              - `"connector_outlookcalendar"`

              - `"connector_outlookemail"`

              - `"connector_sharepoint"`

            - `defer_loading: optional boolean`

              Whether this MCP tool is deferred and discovered via tool search.

            - `headers: optional map[string] or null`

              Optional HTTP headers to send to the MCP server. Use for authentication
              or other purposes.

            - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

              Specify which of the MCP server's tools require approval.

              - `McpToolApprovalFilter object { always, never }`

                Specify which of the MCP server's tools require approval. Can be
                `always`, `never`, or a filter object associated with tools
                that require approval.

                - `always: optional object { read_only, tool_names }`

                  A filter object to specify which tools are allowed.

                  - `read_only: optional boolean`

                    Indicates whether or not a tool modifies data or is read-only. If an
                    MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                    it will match this filter.

                  - `tool_names: optional array of string`

                    List of allowed tool names.

                - `never: optional object { read_only, tool_names }`

                  A filter object to specify which tools are allowed.

                  - `read_only: optional boolean`

                    Indicates whether or not a tool modifies data or is read-only. If an
                    MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                    it will match this filter.

                  - `tool_names: optional array of string`

                    List of allowed tool names.

              - `McpToolApprovalSetting = "always" or "never"`

                Specify a single approval policy for all tools. One of `always` or
                `never`. When set to `always`, all tools will require approval. When
                set to `never`, all tools will not require approval.

                - `"always"`

                - `"never"`

            - `server_description: optional string`

              Optional description of the MCP server, used to provide more context.

            - `server_url: optional string`

              The URL for the MCP server. One of `server_url`, `connector_id`, or
              `tunnel_id` must be provided.

            - `tunnel_id: optional string`

              The Secure MCP Tunnel ID to use instead of a direct server URL. One of
              `server_url`, `connector_id`, or `tunnel_id` must be provided.

          - `CodeInterpreter object { container, type, allowed_callers }`

            A tool that runs Python code to help generate a response to a prompt.

            - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

              The code interpreter container. Can be a container ID or an object that
              specifies uploaded file IDs to make available to your code, along with an
              optional `memory_limit` setting.

              - `string`

                The container ID.

              - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

                Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

                - `type: "auto"`

                  Always `auto`.

                  - `"auto"`

                - `file_ids: optional array of string`

                  An optional list of uploaded files to make available to your code.

                - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                  The memory limit for the code interpreter container.

                  - `"1g"`

                  - `"4g"`

                  - `"16g"`

                  - `"64g"`

                - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                  Network access policy for the container.

                  - `ContainerNetworkPolicyDisabled object { type }`

                    - `type: "disabled"`

                      Disable outbound network access. Always `disabled`.

                      - `"disabled"`

                  - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

                    - `allowed_domains: array of string`

                      A list of allowed domains when type is `allowlist`.

                    - `type: "allowlist"`

                      Allow outbound network access only to specified domains. Always `allowlist`.

                      - `"allowlist"`

                    - `domain_secrets: optional array of ContainerNetworkPolicyDomainSecret`

                      Optional domain-scoped secrets for allowlisted domains.

                      - `domain: string`

                        The domain associated with the secret.

                      - `name: string`

                        The name of the secret to inject for the domain.

                      - `value: string`

                        The secret value to inject for the domain.

            - `type: "code_interpreter"`

              The type of the code interpreter tool. Always `code_interpreter`.

              - `"code_interpreter"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

          - `ProgrammaticToolCalling object { type }`

            - `type: "programmatic_tool_calling"`

              The type of the tool. Always `programmatic_tool_calling`.

              - `"programmatic_tool_calling"`

          - `ImageGeneration object { type, action, background, 9 more }`

            A tool that generates images using the GPT image models.

            - `type: "image_generation"`

              The type of the image generation tool. Always `image_generation`.

              - `"image_generation"`

            - `action: optional "generate" or "edit" or "auto"`

              Whether to generate a new image or edit an existing image. Default: `auto`.

              - `"generate"`

              - `"edit"`

              - `"auto"`

            - `background: optional "transparent" or "opaque" or "auto"`

              Set the background of the generated image. One of `transparent`, `opaque`,
              or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
              their `2026-09-08` snapshots, support `opaque` and `transparent`
              backgrounds. Transparent backgrounds are available for supported GPT Image
              models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
              preview. When using `transparent`, set the output format to `png` or `webp`.
              Default: `auto`.

              - `"transparent"`

              - `"opaque"`

              - `"auto"`

            - `input_fidelity: optional "high" or "low" or null`

              Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

              - `"high"`

              - `"low"`

            - `input_image_mask: optional object { file_id, image_url }`

              Optional mask for inpainting. Contains `image_url`
              (string, optional) and `file_id` (string, optional).

              - `file_id: optional string`

                File ID for the mask image.

              - `image_url: optional string`

                Base64-encoded mask image.

            - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

              The image generation model to use. One of `gpt-image-1`,
              `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
              `gpt-image-1`.

              - `string`

              - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

                The image generation model to use. One of `gpt-image-1`,
                `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
                `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
                `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
                `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
                `gpt-image-1`.

                - `"gpt-image-1"`

                - `"gpt-image-1-mini"`

                - `"gpt-image-1.5"`

                - `"gpt-image-2"`

                - `"gpt-image-2-2026-04-21"`

                - `"gpt-image-2.5-sunburst"`

                - `"gpt-image-2.5-sunburst-2026-09-08"`

                - `"gpt-image-2.5-flare"`

                - `"gpt-image-2.5-flare-2026-09-08"`

            - `moderation: optional "auto" or "low"`

              Moderation level for the generated image. Default: `auto`.

              - `"auto"`

              - `"low"`

            - `output_compression: optional number`

              Compression level for the output image. Default: 100.

            - `output_format: optional "png" or "webp" or "jpeg"`

              The output format of the generated image. One of `png`, `webp`, or
              `jpeg`. Default: `png`.

              - `"png"`

              - `"webp"`

              - `"jpeg"`

            - `partial_images: optional number`

              Number of partial images to generate in streaming mode, from 0 (default value) to 3.

            - `quality: optional "low" or "medium" or "high" or 3 more`

              The quality of the generated image. The GPT image models support `low`,
              `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
              including their `2026-09-08` snapshots, also support `xhigh` and `max`.
              Default: `auto`.

              - `"low"`

              - `"medium"`

              - `"high"`

              - `"xhigh"`

              - `"max"`

              - `"auto"`

            - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

              The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

              - `string`

              - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

                The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

                - `"1024x1024"`

                - `"1024x1536"`

                - `"1536x1024"`

                - `"auto"`

          - `LocalShell object { type }`

            A tool that allows the model to execute shell commands in a local environment.

            - `type: "local_shell"`

              The type of the local shell tool. Always `local_shell`.

              - `"local_shell"`

          - `Shell object { type, allowed_callers, environment }`

            A tool that allows the model to execute shell commands.

            - `type: "shell"`

              The type of the shell tool. Always `shell`.

              - `"shell"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

              - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

                - `type: "container_auto"`

                  Automatically creates a container for this request

                  - `"container_auto"`

                - `file_ids: optional array of string`

                  An optional list of uploaded files to make available to your code.

                - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                  The memory limit for the container.

                  - `"1g"`

                  - `"4g"`

                  - `"16g"`

                  - `"64g"`

                - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                  Network access policy for the container.

                  - `ContainerNetworkPolicyDisabled object { type }`

                  - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

                - `skills: optional array of SkillReference or InlineSkill`

                  An optional list of skills referenced by id or inline data.

                  - `SkillReference object { skill_id, type, version }`

                    - `skill_id: string`

                      The ID of the referenced skill.

                    - `type: "skill_reference"`

                      References a skill created with the /v1/skills endpoint.

                      - `"skill_reference"`

                    - `version: optional string`

                      Optional skill version. Use a positive integer or 'latest'. Omit for default.

                  - `InlineSkill object { description, name, source, type }`

                    - `description: string`

                      The description of the skill.

                    - `name: string`

                      The name of the skill.

                    - `source: InlineSkillSource`

                      Inline skill payload

                      - `data: string`

                        Base64-encoded skill zip bundle.

                      - `media_type: "application/zip"`

                        The media type of the inline skill payload. Must be `application/zip`.

                        - `"application/zip"`

                      - `type: "base64"`

                        The type of the inline skill source. Must be `base64`.

                        - `"base64"`

                    - `type: "inline"`

                      Defines an inline skill for this request.

                      - `"inline"`

              - `LocalEnvironment object { type, skills }`

                - `type: "local"`

                  Use a local computer environment.

                  - `"local"`

                - `skills: optional array of LocalSkill`

                  An optional list of skills.

                  - `description: string`

                    The description of the skill.

                  - `name: string`

                    The name of the skill.

                  - `path: string`

                    The path to the directory containing the skill.

              - `ContainerReference object { container_id, type }`

                - `container_id: string`

                  The ID of the referenced container.

                - `type: "container_reference"`

                  References a container created with the /v1/containers endpoint

                  - `"container_reference"`

          - `Custom object { name, type, allowed_callers, 4 more }`

            A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

            - `name: string`

              The name of the custom tool, used to identify it in tool calls.

            - `type: "custom"`

              The type of the custom tool. Always `custom`.

              - `"custom"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `async: optional boolean`

              Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

            - `defer_loading: optional boolean`

              Whether this tool should be deferred and discovered via tool search.

            - `description: optional string`

              Optional description of the custom tool, used to provide more context.

            - `format: optional CustomToolInputFormat`

              The input format for the custom tool. Default is unconstrained text.

              - `Text object { type }`

                Unconstrained free-form text.

                - `type: "text"`

                  Unconstrained text format. Always `text`.

                  - `"text"`

              - `Grammar object { definition, syntax, type }`

                A grammar defined by the user.

                - `definition: string`

                  The grammar definition.

                - `syntax: "lark" or "regex"`

                  The syntax of the grammar definition. One of `lark` or `regex`.

                  - `"lark"`

                  - `"regex"`

                - `type: "grammar"`

                  Grammar format. Always `grammar`.

                  - `"grammar"`

          - `ToolSearchOutputNamespaceTool object { description, name, tools, type }`

            Groups function/custom tools under a shared namespace.

            - `description: string`

              A description of the namespace shown to the model.

            - `name: string`

              The namespace name used in tool calls (for example, `crm`).

            - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

              The function/custom tools loaded inside this namespace.

              - `Function object { name, type, allowed_callers, 6 more }`

                - `name: string`

                  The name of the loaded function tool.

                - `type: "function"`

                  - `"function"`

                - `allowed_callers: optional array of "direct" or "programmatic" or null`

                  The tool invocation context(s).

                  - `"direct"`

                  - `"programmatic"`

                - `async: optional boolean`

                  Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

                - `defer_loading: optional boolean`

                  Whether this function should be deferred and discovered via tool search.

                - `description: optional string or null`

                - `output_schema: optional map[unknown] or null`

                  A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

                - `parameters: optional unknown or null`

                - `strict: optional boolean or null`

                  Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

              - `Custom object { name, type, allowed_callers, 4 more }`

                A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

                - `name: string`

                  The name of the custom tool, used to identify it in tool calls.

                - `type: "custom"`

                  The type of the custom tool. Always `custom`.

                  - `"custom"`

                - `allowed_callers: optional array of "direct" or "programmatic" or null`

                  The tool invocation context(s).

                  - `"direct"`

                  - `"programmatic"`

                - `async: optional boolean`

                  Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

                - `defer_loading: optional boolean`

                  Whether this tool should be deferred and discovered via tool search.

                - `description: optional string`

                  Optional description of the custom tool, used to provide more context.

                - `format: optional CustomToolInputFormat`

                  The input format for the custom tool. Default is unconstrained text.

            - `type: "namespace"`

              The type of the tool. Always `namespace`.

              - `"namespace"`

          - `ToolSearch object { type, description, execution, parameters }`

            Hosted or BYOT tool search configuration for deferred tools.

            - `type: "tool_search"`

              The type of the tool. Always `tool_search`.

              - `"tool_search"`

            - `description: optional string or null`

              Description shown to the model for a client-executed tool search tool.

            - `execution: optional "server" or "client"`

              Whether tool search is executed by the server or by the client.

              - `"server"`

              - `"client"`

            - `parameters: optional unknown or null`

              Parameter schema for a client-executed tool search tool.

          - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

            This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

            - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

              The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

              - `"web_search_preview"`

              - `"web_search_preview_2025_03_11"`

            - `search_content_types: optional array of "text" or "image"`

              - `"text"`

              - `"image"`

            - `search_context_size: optional "low" or "medium" or "high"`

              High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

              - `"low"`

              - `"medium"`

              - `"high"`

            - `user_location: optional object { type, city, country, 2 more }  or null`

              The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

              - `type: "approximate"`

                The type of location approximation. Always `approximate`.

                - `"approximate"`

              - `city: optional string or null`

                Free text input for the city of the user, e.g. `San Francisco`.

              - `country: optional string or null`

                The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

              - `region: optional string or null`

                Free text input for the region of the user, e.g. `California`.

              - `timezone: optional string or null`

                The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

          - `ApplyPatch object { type, allowed_callers }`

            Allows the assistant to create, delete, or update files using unified diffs.

            - `type: "apply_patch"`

              The type of the tool. Always `apply_patch`.

              - `"apply_patch"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

        - `type: "tool_search_output"`

          The item type. Always `tool_search_output`.

          - `"tool_search_output"`

        - `id: optional string or null`

          The unique ID of this tool search output.

        - `call_id: optional string or null`

          The unique ID of the tool search call generated by the model.

        - `execution: optional "server" or "client"`

          Whether tool search was executed by the server or by the client.

          - `"server"`

          - `"client"`

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the tool search output.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `AdditionalTools object { role, tools, type, id }`

        - `role: "developer"`

          The role that provided the additional tools. Only `developer` is supported.

          - `"developer"`

        - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

          A list of additional tools made available at this item.

          - `Function object { name, parameters, strict, 6 more }`

            Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

            - `name: string`

              The name of the function to call.

            - `parameters: map[unknown] or null`

              A JSON schema object describing the parameters of the function.

            - `strict: boolean or null`

              Whether strict parameter validation is enforced for this function tool.

            - `type: "function"`

              The type of the function tool. Always `function`.

              - `"function"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `async: optional boolean`

            - `defer_loading: optional boolean`

              Whether this function is deferred and loaded via tool search.

            - `description: optional string or null`

              A description of the function. Used by the model to determine whether or not to call the function.

            - `output_schema: optional map[unknown] or null`

              A JSON schema object describing the JSON value encoded in string outputs for this function.

          - `FileSearch object { type, vector_store_ids, filters, 2 more }`

            A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

            - `type: "file_search"`

              The type of the file search tool. Always `file_search`.

              - `"file_search"`

            - `vector_store_ids: array of string`

              The IDs of the vector stores to search.

            - `filters: optional ComparisonFilter or CompoundFilter or null`

              A filter to apply.

              - `ComparisonFilter object { key, type, value }`

                A filter used to compare a specified attribute key to a given value using a defined comparison operation.

              - `CompoundFilter object { filters, type }`

                Combine multiple filters using `and` or `or`.

            - `max_num_results: optional number`

              The maximum number of results to return. This number should be between 1 and 50 inclusive.

            - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

              Ranking options for search.

              - `hybrid_search: optional object { embedding_weight, text_weight }`

                Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

                - `embedding_weight: number`

                  The weight of the embedding in the reciprocal ranking fusion.

                - `text_weight: number`

                  The weight of the text in the reciprocal ranking fusion.

              - `ranker: optional "auto" or "default-2024-11-15"`

                The ranker to use for the file search.

                - `"auto"`

                - `"default-2024-11-15"`

              - `score_threshold: optional number`

                The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

          - `Computer object { type }`

            A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

            - `type: "computer"`

              The type of the computer tool. Always `computer`.

              - `"computer"`

          - `ComputerUsePreview object { display_height, display_width, environment, type }`

            A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

            - `display_height: number`

              The height of the computer display.

            - `display_width: number`

              The width of the computer display.

            - `environment: "windows" or "mac" or "linux" or 2 more`

              The type of computer environment to control.

              - `"windows"`

              - `"mac"`

              - `"linux"`

              - `"ubuntu"`

              - `"browser"`

            - `type: "computer_use_preview"`

              The type of the computer use tool. Always `computer_use_preview`.

              - `"computer_use_preview"`

          - `WebSearch object { type, external_web_access, filters, 2 more }`

            Search the Internet for sources related to the prompt. Learn more about the
            [web search tool](/api/docs/guides/tools-web-search).

            - `type: "web_search" or "web_search_2025_08_26"`

              The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

              - `"web_search"`

              - `"web_search_2025_08_26"`

            - `external_web_access: optional boolean`

              Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

            - `filters: optional object { allowed_domains }  or null`

              Filters for the search.

              - `allowed_domains: optional array of string or null`

                Allowed domains for the search. If not provided, all domains are allowed.
                Subdomains of the provided domains are allowed as well.

                Example: `["pubmed.ncbi.nlm.nih.gov"]`

            - `search_context_size: optional "low" or "medium" or "high"`

              High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

              - `"low"`

              - `"medium"`

              - `"high"`

            - `user_location: optional object { city, country, region, 2 more }  or null`

              The approximate location of the user. If omitted or null, defaults to the
              United States. To avoid this fallback, pass `{"type": "approximate"}` without
              location fields. To localize results, provide the relevant location fields.

              - `city: optional string or null`

                Free text input for the city of the user, e.g. `San Francisco`.

              - `country: optional string or null`

                The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

              - `region: optional string or null`

                Free text input for the region of the user, e.g. `California`.

              - `timezone: optional string or null`

                The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

              - `type: optional "approximate"`

                The type of location approximation. Always `approximate`.

                - `"approximate"`

          - `Mcp object { server_label, type, allowed_callers, 9 more }`

            Give the model access to additional tools via remote Model Context Protocol
            (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

            - `server_label: string`

              A label for this MCP server, used to identify it in tool calls.

            - `type: "mcp"`

              The type of the MCP tool. Always `mcp`.

              - `"mcp"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

              List of allowed tool names or a filter object.

              - `McpAllowedTools = array of string`

                A string array of allowed tool names

              - `McpToolFilter object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

            - `authorization: optional string`

              An OAuth access token that can be used with a remote MCP server, either
              with a custom MCP server URL or a service connector. Your application
              must handle the OAuth authorization flow and provide the token here.

            - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

              Identifier for service connectors, like those available in ChatGPT. One of
              `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
              about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

              This field is deprecated for models released after September 1, 2026.
              Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
              connect through a Secure MCP Tunnel.

              Currently supported `connector_id` values are:

              - Dropbox: `connector_dropbox`
              - Gmail: `connector_gmail`
              - Google Calendar: `connector_googlecalendar`
              - Google Drive: `connector_googledrive`
              - Microsoft Teams: `connector_microsoftteams`
              - Outlook Calendar: `connector_outlookcalendar`
              - Outlook Email: `connector_outlookemail`
              - SharePoint: `connector_sharepoint`

              - `"connector_dropbox"`

              - `"connector_gmail"`

              - `"connector_googlecalendar"`

              - `"connector_googledrive"`

              - `"connector_microsoftteams"`

              - `"connector_outlookcalendar"`

              - `"connector_outlookemail"`

              - `"connector_sharepoint"`

            - `defer_loading: optional boolean`

              Whether this MCP tool is deferred and discovered via tool search.

            - `headers: optional map[string] or null`

              Optional HTTP headers to send to the MCP server. Use for authentication
              or other purposes.

            - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

              Specify which of the MCP server's tools require approval.

              - `McpToolApprovalFilter object { always, never }`

                Specify which of the MCP server's tools require approval. Can be
                `always`, `never`, or a filter object associated with tools
                that require approval.

                - `always: optional object { read_only, tool_names }`

                  A filter object to specify which tools are allowed.

                  - `read_only: optional boolean`

                    Indicates whether or not a tool modifies data or is read-only. If an
                    MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                    it will match this filter.

                  - `tool_names: optional array of string`

                    List of allowed tool names.

                - `never: optional object { read_only, tool_names }`

                  A filter object to specify which tools are allowed.

                  - `read_only: optional boolean`

                    Indicates whether or not a tool modifies data or is read-only. If an
                    MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                    it will match this filter.

                  - `tool_names: optional array of string`

                    List of allowed tool names.

              - `McpToolApprovalSetting = "always" or "never"`

                Specify a single approval policy for all tools. One of `always` or
                `never`. When set to `always`, all tools will require approval. When
                set to `never`, all tools will not require approval.

                - `"always"`

                - `"never"`

            - `server_description: optional string`

              Optional description of the MCP server, used to provide more context.

            - `server_url: optional string`

              The URL for the MCP server. One of `server_url`, `connector_id`, or
              `tunnel_id` must be provided.

            - `tunnel_id: optional string`

              The Secure MCP Tunnel ID to use instead of a direct server URL. One of
              `server_url`, `connector_id`, or `tunnel_id` must be provided.

          - `CodeInterpreter object { container, type, allowed_callers }`

            A tool that runs Python code to help generate a response to a prompt.

            - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

              The code interpreter container. Can be a container ID or an object that
              specifies uploaded file IDs to make available to your code, along with an
              optional `memory_limit` setting.

              - `string`

                The container ID.

              - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

                Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

                - `type: "auto"`

                  Always `auto`.

                  - `"auto"`

                - `file_ids: optional array of string`

                  An optional list of uploaded files to make available to your code.

                - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                  The memory limit for the code interpreter container.

                  - `"1g"`

                  - `"4g"`

                  - `"16g"`

                  - `"64g"`

                - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                  Network access policy for the container.

                  - `ContainerNetworkPolicyDisabled object { type }`

                  - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

            - `type: "code_interpreter"`

              The type of the code interpreter tool. Always `code_interpreter`.

              - `"code_interpreter"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

          - `ProgrammaticToolCalling object { type }`

            - `type: "programmatic_tool_calling"`

              The type of the tool. Always `programmatic_tool_calling`.

              - `"programmatic_tool_calling"`

          - `ImageGeneration object { type, action, background, 9 more }`

            A tool that generates images using the GPT image models.

            - `type: "image_generation"`

              The type of the image generation tool. Always `image_generation`.

              - `"image_generation"`

            - `action: optional "generate" or "edit" or "auto"`

              Whether to generate a new image or edit an existing image. Default: `auto`.

              - `"generate"`

              - `"edit"`

              - `"auto"`

            - `background: optional "transparent" or "opaque" or "auto"`

              Set the background of the generated image. One of `transparent`, `opaque`,
              or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
              their `2026-09-08` snapshots, support `opaque` and `transparent`
              backgrounds. Transparent backgrounds are available for supported GPT Image
              models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
              preview. When using `transparent`, set the output format to `png` or `webp`.
              Default: `auto`.

              - `"transparent"`

              - `"opaque"`

              - `"auto"`

            - `input_fidelity: optional "high" or "low" or null`

              Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

              - `"high"`

              - `"low"`

            - `input_image_mask: optional object { file_id, image_url }`

              Optional mask for inpainting. Contains `image_url`
              (string, optional) and `file_id` (string, optional).

              - `file_id: optional string`

                File ID for the mask image.

              - `image_url: optional string`

                Base64-encoded mask image.

            - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

              The image generation model to use. One of `gpt-image-1`,
              `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
              `gpt-image-1`.

              - `string`

              - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

                The image generation model to use. One of `gpt-image-1`,
                `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
                `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
                `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
                `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
                `gpt-image-1`.

                - `"gpt-image-1"`

                - `"gpt-image-1-mini"`

                - `"gpt-image-1.5"`

                - `"gpt-image-2"`

                - `"gpt-image-2-2026-04-21"`

                - `"gpt-image-2.5-sunburst"`

                - `"gpt-image-2.5-sunburst-2026-09-08"`

                - `"gpt-image-2.5-flare"`

                - `"gpt-image-2.5-flare-2026-09-08"`

            - `moderation: optional "auto" or "low"`

              Moderation level for the generated image. Default: `auto`.

              - `"auto"`

              - `"low"`

            - `output_compression: optional number`

              Compression level for the output image. Default: 100.

            - `output_format: optional "png" or "webp" or "jpeg"`

              The output format of the generated image. One of `png`, `webp`, or
              `jpeg`. Default: `png`.

              - `"png"`

              - `"webp"`

              - `"jpeg"`

            - `partial_images: optional number`

              Number of partial images to generate in streaming mode, from 0 (default value) to 3.

            - `quality: optional "low" or "medium" or "high" or 3 more`

              The quality of the generated image. The GPT image models support `low`,
              `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
              including their `2026-09-08` snapshots, also support `xhigh` and `max`.
              Default: `auto`.

              - `"low"`

              - `"medium"`

              - `"high"`

              - `"xhigh"`

              - `"max"`

              - `"auto"`

            - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

              The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

              - `string`

              - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

                The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

                - `"1024x1024"`

                - `"1024x1536"`

                - `"1536x1024"`

                - `"auto"`

          - `LocalShell object { type }`

            A tool that allows the model to execute shell commands in a local environment.

            - `type: "local_shell"`

              The type of the local shell tool. Always `local_shell`.

              - `"local_shell"`

          - `Shell object { type, allowed_callers, environment }`

            A tool that allows the model to execute shell commands.

            - `type: "shell"`

              The type of the shell tool. Always `shell`.

              - `"shell"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

              - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

              - `LocalEnvironment object { type, skills }`

              - `ContainerReference object { container_id, type }`

          - `Custom object { name, type, allowed_callers, 4 more }`

            A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

            - `name: string`

              The name of the custom tool, used to identify it in tool calls.

            - `type: "custom"`

              The type of the custom tool. Always `custom`.

              - `"custom"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

            - `async: optional boolean`

              Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

            - `defer_loading: optional boolean`

              Whether this tool should be deferred and discovered via tool search.

            - `description: optional string`

              Optional description of the custom tool, used to provide more context.

            - `format: optional CustomToolInputFormat`

              The input format for the custom tool. Default is unconstrained text.

          - `Namespace object { description, name, tools, type }`

            Groups function/custom tools under a shared namespace.

            - `description: string`

              A description of the namespace shown to the model.

            - `name: string`

              The namespace name used in tool calls (for example, `crm`).

            - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

              The function/custom tools available inside this namespace.

              - `Function object { name, type, allowed_callers, 6 more }`

                - `name: string`

                - `type: "function"`

                  - `"function"`

                - `allowed_callers: optional array of "direct" or "programmatic" or null`

                  The tool invocation context(s).

                  - `"direct"`

                  - `"programmatic"`

                - `async: optional boolean`

                  Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

                - `defer_loading: optional boolean`

                  Whether this function should be deferred and discovered via tool search.

                - `description: optional string or null`

                - `output_schema: optional map[unknown] or null`

                  A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

                - `parameters: optional unknown or null`

                - `strict: optional boolean or null`

                  Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

              - `Custom object { name, type, allowed_callers, 4 more }`

                A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

                - `name: string`

                  The name of the custom tool, used to identify it in tool calls.

                - `type: "custom"`

                  The type of the custom tool. Always `custom`.

                  - `"custom"`

                - `allowed_callers: optional array of "direct" or "programmatic" or null`

                  The tool invocation context(s).

                  - `"direct"`

                  - `"programmatic"`

                - `async: optional boolean`

                  Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

                - `defer_loading: optional boolean`

                  Whether this tool should be deferred and discovered via tool search.

                - `description: optional string`

                  Optional description of the custom tool, used to provide more context.

                - `format: optional CustomToolInputFormat`

                  The input format for the custom tool. Default is unconstrained text.

            - `type: "namespace"`

              The type of the tool. Always `namespace`.

              - `"namespace"`

          - `ToolSearch object { type, description, execution, parameters }`

            Hosted or BYOT tool search configuration for deferred tools.

            - `type: "tool_search"`

              The type of the tool. Always `tool_search`.

              - `"tool_search"`

            - `description: optional string or null`

              Description shown to the model for a client-executed tool search tool.

            - `execution: optional "server" or "client"`

              Whether tool search is executed by the server or by the client.

              - `"server"`

              - `"client"`

            - `parameters: optional unknown or null`

              Parameter schema for a client-executed tool search tool.

          - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

            This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

            - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

              The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

              - `"web_search_preview"`

              - `"web_search_preview_2025_03_11"`

            - `search_content_types: optional array of "text" or "image"`

              - `"text"`

              - `"image"`

            - `search_context_size: optional "low" or "medium" or "high"`

              High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

              - `"low"`

              - `"medium"`

              - `"high"`

            - `user_location: optional object { type, city, country, 2 more }  or null`

              The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

              - `type: "approximate"`

                The type of location approximation. Always `approximate`.

                - `"approximate"`

              - `city: optional string or null`

                Free text input for the city of the user, e.g. `San Francisco`.

              - `country: optional string or null`

                The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

              - `region: optional string or null`

                Free text input for the region of the user, e.g. `California`.

              - `timezone: optional string or null`

                The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

          - `ApplyPatch object { type, allowed_callers }`

            Allows the assistant to create, delete, or update files using unified diffs.

            - `type: "apply_patch"`

              The type of the tool. Always `apply_patch`.

              - `"apply_patch"`

            - `allowed_callers: optional array of "direct" or "programmatic" or null`

              The tool invocation context(s).

              - `"direct"`

              - `"programmatic"`

        - `type: "additional_tools"`

          The item type. Always `additional_tools`.

          - `"additional_tools"`

        - `id: optional string or null`

          The unique ID of this additional tools item.

      - `ConfigurationUpdate object { type, id, reasoning }`

        An update to the conversation's response configuration. The configuration
        remains in effect for subsequent responses until it is replaced by another
        configuration update.

        - `type: "configuration_update"`

          The item type. Always `configuration_update`.

          - `"configuration_update"`

        - `id: optional string or null`

          The unique ID of the configuration update item.

        - `reasoning: optional object { effort }`

          Updates to reasoning configuration. Only effort is supported.

          - `effort: optional ReasoningEffort or null`

            The reasoning effort to use for subsequent responses until another
            configuration update replaces it.

            - `"none"`

            - `"minimal"`

            - `"low"`

            - `"medium"`

            - `"high"`

            - `"xhigh"`

            - `"max"`

      - `Reasoning object { id, summary, type, 3 more }`

        A description of the chain of thought used by a reasoning model while generating
        a response. Be sure to include these items in your `input` to the Responses API
        for subsequent turns of a conversation if you are manually
        [managing context](/api/docs/guides/conversation-state).

        - `id: string`

          The unique identifier of the reasoning content.

        - `summary: array of SummaryTextContent`

          Reasoning summary content.

          - `text: string`

            A summary of the reasoning output from the model so far.

          - `type: "summary_text"`

            The type of the object. Always `summary_text`.

            - `"summary_text"`

        - `type: "reasoning"`

          The type of the object. Always `reasoning`.

          - `"reasoning"`

        - `content: optional array of object { text, type }`

          Reasoning text content.

          - `text: string`

            The reasoning text from the model.

          - `type: "reasoning_text"`

            The type of the reasoning text. Always `reasoning_text`.

            - `"reasoning_text"`

        - `encrypted_content: optional string or null`

          The encrypted content of the reasoning item. This is populated by default
          for reasoning items returned by `POST /v1/responses` and WebSocket
          `response.create` requests.

          When streaming, use the completed reasoning item and its
          `encrypted_content` from the `response.output_item.done` event in
          subsequent requests. The `encrypted_content` in
          `response.output_item.added` may be incomplete. This is especially
          important when `store` is `false` or when using Zero Data Retention.

        - `status: optional "in_progress" or "completed" or "incomplete"`

          The status of the item. One of `in_progress`, `completed`, or
          `incomplete`. Populated when items are returned via API.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `Compaction object { encrypted_content, type, id }`

        A compaction item generated by the [`v1/responses/compact` API](/api/reference/resources/responses/methods/compact).

        - `encrypted_content: string`

          The encrypted content of the compaction summary.

        - `type: "compaction"`

          The type of the item. Always `compaction`.

          - `"compaction"`

        - `id: optional string or null`

          The ID of the compaction item.

      - `ImageGenerationCall object { id, result, status, 8 more }`

        An image generation request made by the model.

        - `id: string`

          The unique ID of the image generation call.

        - `result: string or null`

          The generated image encoded in base64.

        - `status: "in_progress" or "completed" or "generating" or "failed"`

          The status of the image generation call.

          - `"in_progress"`

          - `"completed"`

          - `"generating"`

          - `"failed"`

        - `type: "image_generation_call"`

          The type of the image generation call. Always `image_generation_call`.

          - `"image_generation_call"`

        - `action: optional "generate" or "edit" or "auto" or null`

          The action used for image generation.

          - `"generate"`

          - `"edit"`

          - `"auto"`

        - `background: optional "transparent" or "opaque" or "auto" or null`

          The background setting used for generation.

          - `"transparent"`

          - `"opaque"`

          - `"auto"`

        - `error: optional object { code, message, param, 2 more }`

          Details of a moderation failure, when available.

          - `code: string or null`

            The error code.

          - `message: string`

            A description of the error.

          - `param: string or null`

            The related request parameter.

          - `type: string`

            The error type.

          - `moderation_details: optional object { categories, moderation_stage }`

            Public details for a `moderation_blocked` error, when available.

            - `categories: array of string`

              Public moderation categories. New category values may be added over time.

            - `moderation_stage: "input" or "output" or "unknown"`

              The stage where moderation blocked the image generation call.

              - `"input"`

              - `"output"`

              - `"unknown"`

        - `output_format: optional "png" or "webp" or "jpeg" or null`

          The output format used for generation.

          - `"png"`

          - `"webp"`

          - `"jpeg"`

        - `quality: optional "low" or "medium" or "high" or 3 more or null`

          The quality of the image generated by the image generation tool call. One of `low`, `medium`, `high`, `xhigh`, `max`, or `auto`.

          - `"low"`

          - `"medium"`

          - `"high"`

          - `"xhigh"`

          - `"max"`

          - `"auto"`

        - `revised_prompt: optional string or null`

          The prompt that was used after any model prompt rewriting.

        - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or null`

          The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`.

          - `string`

          - `"1024x1024" or "1024x1536" or "1536x1024"`

            The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`.

            - `"1024x1024"`

            - `"1024x1536"`

            - `"1536x1024"`

      - `CodeInterpreterCall object { id, code, container_id, 3 more }`

        A tool call to run code.

        - `id: string`

          The unique ID of the code interpreter tool call.

        - `code: string or null`

          The code to run, or null if not available.

        - `container_id: string`

          The ID of the container used to run the code.

        - `outputs: array of Logs { logs, type }  or Image { type, url }  or null`

          The outputs generated by the code interpreter, such as logs or images.
          Can be null if no outputs are available.

          - `Logs object { logs, type }`

            The logs output from the code interpreter.

            - `logs: string`

              The logs output from the code interpreter.

            - `type: "logs"`

              The type of the output. Always `logs`.

              - `"logs"`

          - `Image object { type, url }`

            The image output from the code interpreter.

            - `type: "image"`

              The type of the output. Always `image`.

              - `"image"`

            - `url: string`

              The URL of the image output from the code interpreter.

        - `status: "in_progress" or "completed" or "incomplete" or 2 more`

          The status of the code interpreter tool call. Valid values are `in_progress`, `completed`, `incomplete`, `interpreting`, and `failed`.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

          - `"interpreting"`

          - `"failed"`

        - `type: "code_interpreter_call"`

          The type of the code interpreter tool call. Always `code_interpreter_call`.

          - `"code_interpreter_call"`

      - `LocalShellCall object { id, action, call_id, 2 more }`

        A tool call to run a command on the local shell.

        - `id: string`

          The unique ID of the local shell call.

        - `action: object { command, env, type, 3 more }`

          Execute a shell command on the server.

          - `command: array of string`

            The command to run.

          - `env: map[string]`

            Environment variables to set for the command.

          - `type: "exec"`

            The type of the local shell action. Always `exec`.

            - `"exec"`

          - `timeout_ms: optional number or null`

            Optional timeout in milliseconds for the command.

          - `user: optional string or null`

            Optional user to run the command as.

          - `working_directory: optional string or null`

            Optional working directory to run the command in.

        - `call_id: string`

          The unique ID of the local shell tool call generated by the model.

        - `status: "in_progress" or "completed" or "incomplete"`

          The status of the local shell call.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

        - `type: "local_shell_call"`

          The type of the local shell call. Always `local_shell_call`.

          - `"local_shell_call"`

      - `LocalShellCallOutput object { id, output, type, status }`

        The output of a local shell tool call.

        - `id: string`

          The unique ID of the local shell tool call generated by the model.

        - `output: string`

          A JSON string of the output of the local shell tool call.

        - `type: "local_shell_call_output"`

          The type of the local shell tool call output. Always `local_shell_call_output`.

          - `"local_shell_call_output"`

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the item. One of `in_progress`, `completed`, or `incomplete`.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `ShellCall object { action, call_id, type, 4 more }`

        A tool representing a request to execute one or more shell commands.

        - `action: object { commands, max_output_length, timeout_ms }`

          The shell commands and limits that describe how to run the tool call.

          - `commands: array of string`

            Ordered shell commands for the execution environment to run.

          - `max_output_length: optional number or null`

            Maximum number of UTF-8 characters to capture from combined stdout and stderr output.

          - `timeout_ms: optional number or null`

            Maximum wall-clock time in milliseconds to allow the shell commands to run.

        - `call_id: string`

          The unique ID of the shell tool call generated by the model.

        - `type: "shell_call"`

          The type of the item. Always `shell_call`.

          - `"shell_call"`

        - `id: optional string or null`

          The unique ID of the shell tool call. Populated when this item is returned via API.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              The caller type. Always `direct`.

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              The caller type. Always `program`.

              - `"program"`

        - `environment: optional LocalEnvironment or ContainerReference or null`

          The environment to execute the shell commands in.

          - `LocalEnvironment object { type, skills }`

          - `ContainerReference object { container_id, type }`

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the shell call. One of `in_progress`, `completed`, or `incomplete`.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `ShellCallOutput object { call_id, output, type, 4 more }`

        The streamed output items emitted by a shell tool call.

        - `call_id: string`

          The unique ID of the shell tool call generated by the model.

        - `output: array of ResponseFunctionShellCallOutputContent`

          Captured chunks of stdout and stderr output, along with their associated outcomes.

          - `outcome: Timeout { type }  or Exit { exit_code, type }`

            The exit or timeout outcome associated with this shell call.

            - `Timeout object { type }`

              Indicates that the shell call exceeded its configured time limit.

              - `type: "timeout"`

                The outcome type. Always `timeout`.

                - `"timeout"`

            - `Exit object { exit_code, type }`

              Indicates that the shell commands finished and returned an exit code.

              - `exit_code: number`

                The exit code returned by the shell process.

              - `type: "exit"`

                The outcome type. Always `exit`.

                - `"exit"`

          - `stderr: string`

            Captured stderr output for the shell call.

          - `stdout: string`

            Captured stdout output for the shell call.

        - `type: "shell_call_output"`

          The type of the item. Always `shell_call_output`.

          - `"shell_call_output"`

        - `id: optional string or null`

          The unique ID of the shell tool call output. Populated when this item is returned via API.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              The caller type. Always `direct`.

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              The caller type. Always `program`.

              - `"program"`

        - `max_output_length: optional number or null`

          The maximum number of UTF-8 characters captured for this shell call's combined output.

        - `status: optional "in_progress" or "completed" or "incomplete" or null`

          The status of the shell call output.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

      - `ApplyPatchCall object { call_id, operation, status, 3 more }`

        A tool call representing a request to create, delete, or update files using diff patches.

        - `call_id: string`

          The unique ID of the apply patch tool call generated by the model.

        - `operation: CreateFile { diff, path, type }  or DeleteFile { path, type }  or UpdateFile { diff, path, type }`

          The specific create, delete, or update instruction for the apply_patch tool call.

          - `CreateFile object { diff, path, type }`

            Instruction for creating a new file via the apply_patch tool.

            - `diff: string`

              Unified diff content to apply when creating the file.

            - `path: string`

              Path of the file to create relative to the workspace root.

            - `type: "create_file"`

              The operation type. Always `create_file`.

              - `"create_file"`

          - `DeleteFile object { path, type }`

            Instruction for deleting an existing file via the apply_patch tool.

            - `path: string`

              Path of the file to delete relative to the workspace root.

            - `type: "delete_file"`

              The operation type. Always `delete_file`.

              - `"delete_file"`

          - `UpdateFile object { diff, path, type }`

            Instruction for updating an existing file via the apply_patch tool.

            - `diff: string`

              Unified diff content to apply to the existing file.

            - `path: string`

              Path of the file to update relative to the workspace root.

            - `type: "update_file"`

              The operation type. Always `update_file`.

              - `"update_file"`

        - `status: "in_progress" or "completed"`

          The status of the apply patch tool call. One of `in_progress` or `completed`.

          - `"in_progress"`

          - `"completed"`

        - `type: "apply_patch_call"`

          The type of the item. Always `apply_patch_call`.

          - `"apply_patch_call"`

        - `id: optional string or null`

          The unique ID of the apply patch tool call. Populated when this item is returned via API.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              The caller type. Always `direct`.

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              The caller type. Always `program`.

              - `"program"`

      - `ApplyPatchCallOutput object { call_id, status, type, 3 more }`

        The streamed output emitted by an apply patch tool call.

        - `call_id: string`

          The unique ID of the apply patch tool call generated by the model.

        - `status: "completed" or "failed"`

          The status of the apply patch tool call output. One of `completed` or `failed`.

          - `"completed"`

          - `"failed"`

        - `type: "apply_patch_call_output"`

          The type of the item. Always `apply_patch_call_output`.

          - `"apply_patch_call_output"`

        - `id: optional string or null`

          The unique ID of the apply patch tool call output. Populated when this item is returned via API.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              The caller type. Always `direct`.

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              The caller type. Always `program`.

              - `"program"`

        - `output: optional string or null`

          Optional human-readable log text from the apply patch tool (e.g., patch results or errors).

      - `McpListTools object { id, server_label, tools, 2 more }`

        A list of tools available on an MCP server.

        - `id: string`

          The unique ID of the list.

        - `server_label: string`

          The label of the MCP server.

        - `tools: array of object { input_schema, name, annotations, description }`

          The tools available on the server.

          - `input_schema: unknown`

            The JSON schema describing the tool's input.

          - `name: string`

            The name of the tool.

          - `annotations: optional unknown or null`

            Additional annotations about the tool.

          - `description: optional string or null`

            The description of the tool.

        - `type: "mcp_list_tools"`

          The type of the item. Always `mcp_list_tools`.

          - `"mcp_list_tools"`

        - `error: optional string or null`

          Error message if the server could not list tools.

      - `McpApprovalRequest object { id, arguments, name, 2 more }`

        A request for human approval of a tool invocation.

        - `id: string`

          The unique ID of the approval request.

        - `arguments: string`

          A JSON string of arguments for the tool.

        - `name: string`

          The name of the tool to run.

        - `server_label: string`

          The label of the MCP server making the request.

        - `type: "mcp_approval_request"`

          The type of the item. Always `mcp_approval_request`.

          - `"mcp_approval_request"`

      - `McpApprovalResponse object { approval_request_id, approve, type, 2 more }`

        A response to an MCP approval request.

        - `approval_request_id: string`

          The ID of the approval request being answered.

        - `approve: boolean`

          Whether the request was approved.

        - `type: "mcp_approval_response"`

          The type of the item. Always `mcp_approval_response`.

          - `"mcp_approval_response"`

        - `id: optional string or null`

          The unique ID of the approval response

        - `reason: optional string or null`

          Optional reason for the decision.

      - `McpCall object { id, arguments, name, 6 more }`

        An invocation of a tool on an MCP server.

        - `id: string`

          The unique ID of the tool call.

        - `arguments: string`

          A JSON string of the arguments passed to the tool.

        - `name: string`

          The name of the tool that was run.

        - `server_label: string`

          The label of the MCP server running the tool.

        - `type: "mcp_call"`

          The type of the item. Always `mcp_call`.

          - `"mcp_call"`

        - `approval_request_id: optional string or null`

          Unique identifier for the MCP tool call approval request.
          Include this value in a subsequent `mcp_approval_response` input to approve or reject the corresponding tool call.

        - `error: optional McpToolCallError or null`

          The error from the tool call, if any.

          - `McpProtocolError object { code, message, type }`

            - `code: number`

            - `message: string`

            - `type: "mcp_protocol_error"`

              - `"mcp_protocol_error"`

          - `McpToolExecutionError object { content, type }`

            - `content: unknown`

            - `type: "mcp_tool_execution_error"`

              - `"mcp_tool_execution_error"`

          - `HTTPError object { code, message, type }`

            - `code: number`

            - `message: string`

            - `type: "http_error"`

              - `"http_error"`

        - `output: optional string or null`

          The output from the tool call.

        - `status: optional "in_progress" or "completed" or "incomplete" or 2 more`

          The status of the tool call. One of `in_progress`, `completed`, `incomplete`, `calling`, or `failed`.

          - `"in_progress"`

          - `"completed"`

          - `"incomplete"`

          - `"calling"`

          - `"failed"`

      - `CustomToolCallOutput object { call_id, output, type, 2 more }`

        The output of a custom tool call from your code, being sent back to the model.

        - `call_id: string`

          The call ID, used to map this custom tool call output to a custom tool call.

        - `output: string or array of ResponseInputText or ResponseInputImage or ResponseInputFile`

          The output from the custom tool call generated by your code.
          Can be a string or an list of output content.

          - `StringOutput = string`

            A string of the output of the custom tool call.

          - `OutputContentList = array of ResponseInputText or ResponseInputImage or ResponseInputFile`

            Text, image, or file output of the custom tool call.

            - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

              A text input to the model.

            - `ResponseInputImage object { detail, type, file_id, 2 more }`

              An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

            - `ResponseInputFile object { type, detail, file_data, 4 more }`

              A file input to the model.

        - `type: "custom_tool_call_output"`

          The type of the custom tool call output. Always `custom_tool_call_output`.

          - `"custom_tool_call_output"`

        - `id: optional string`

          The unique ID of the custom tool call output in the OpenAI platform.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              The caller type. Always `direct`.

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              The caller type. Always `program`.

              - `"program"`

      - `CustomToolCall object { call_id, input, name, 5 more }`

        A call to a custom tool created by the model.

        - `call_id: string`

          An identifier used to map this custom tool call to a tool call output.

        - `input: string`

          The input for the custom tool call generated by the model.

        - `name: string`

          The name of the custom tool being called.

        - `type: "custom_tool_call"`

          The type of the custom tool call. Always `custom_tool_call`.

          - `"custom_tool_call"`

        - `id: optional string`

          The unique ID of the custom tool call in the OpenAI platform.

        - `async: optional boolean`

          Whether the custom tool call runs asynchronously.

        - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

          The execution context that produced this tool call.

          - `Direct object { type }`

            - `type: "direct"`

              - `"direct"`

          - `Program object { caller_id, type }`

            - `caller_id: string`

              The call ID of the program item that produced this tool call.

            - `type: "program"`

              - `"program"`

        - `namespace: optional string`

          The namespace of the custom tool being called.

      - `CompactionTrigger object { type, id }`

        Compacts the current context. Must be the final input item.

        - `type: "compaction_trigger"`

          The type of the item. Always `compaction_trigger`.

          - `"compaction_trigger"`

        - `id: optional string or null`

          The unique ID of this compaction trigger.

      - `ItemReference object { id, type }`

        An internal identifier for an item to reference.

        - `id: string`

          The ID of the item to reference.

        - `type: optional "item_reference" or null`

          The type of item to reference. Always `item_reference`.

          - `"item_reference"`

      - `Program object { id, call_id, code, 2 more }`

        - `id: string`

          The unique ID of this program item.

        - `call_id: string`

          The stable call ID of the program item.

        - `code: string`

          The JavaScript source executed by programmatic tool calling.

        - `fingerprint: string`

          Opaque program replay fingerprint that must be round-tripped.

        - `type: "program"`

          The item type. Always `program`.

          - `"program"`

      - `ProgramOutput object { id, call_id, result, 2 more }`

        - `id: string`

          The unique ID of this program output item.

        - `call_id: string`

          The call ID of the program item.

        - `result: string`

          The result produced by the program item.

        - `status: "completed" or "incomplete"`

          The terminal status of the program output.

          - `"completed"`

          - `"incomplete"`

        - `type: "program_output"`

          The item type. Always `program_output`.

          - `"program_output"`

  - `metadata: Metadata or null`

    Set of 16 key-value pairs that can be attached to an object. This can be
    useful for storing additional information about the object in a structured
    format, and querying for objects via API or the dashboard.

    Keys are strings with a maximum length of 64 characters. Values are strings
    with a maximum length of 512 characters.

  - `model: ResponsesModel`

    Model ID used to generate the response, like `gpt-6-astra`. OpenAI
    offers a wide range of models with different capabilities, performance
    characteristics, and price points. Refer to the [model guide](/api/docs/models)
    to browse and compare available models.

    - `string`

    - `"gpt-6-astra" or "gpt-6.1-sol" or "gpt-6-sol" or 86 more`

      - `"gpt-6-astra"`

      - `"gpt-6.1-sol"`

      - `"gpt-6-sol"`

      - `"gpt-6-luna"`

      - `"gpt-5.6-sol"`

      - `"gpt-5.6-terra"`

      - `"gpt-5.6-luna"`

      - `"gpt-5.5"`

      - `"gpt-5.5-2026-04-23"`

      - `"gpt-5.4"`

      - `"gpt-5.4-mini"`

      - `"gpt-5.4-nano"`

      - `"gpt-5.4-mini-2026-03-17"`

      - `"gpt-5.4-nano-2026-03-17"`

      - `"gpt-5.3-chat-latest"`

      - `"gpt-5.2"`

      - `"gpt-5.2-2025-12-11"`

      - `"gpt-5.2-chat-latest"`

      - `"gpt-5.2-pro"`

      - `"gpt-5.2-pro-2025-12-11"`

      - `"gpt-5.1"`

      - `"gpt-5.1-2025-11-13"`

      - `"gpt-5.1-codex"`

      - `"gpt-5.1-mini"`

      - `"gpt-5.1-chat-latest"`

      - `"gpt-5"`

      - `"gpt-5-mini"`

      - `"gpt-5-nano"`

      - `"gpt-5-2025-08-07"`

      - `"gpt-5-mini-2025-08-07"`

      - `"gpt-5-nano-2025-08-07"`

      - `"gpt-5-chat-latest"`

      - `"gpt-4.1"`

      - `"gpt-4.1-mini"`

      - `"gpt-4.1-nano"`

      - `"gpt-4.1-2025-04-14"`

      - `"gpt-4.1-mini-2025-04-14"`

      - `"gpt-4.1-nano-2025-04-14"`

      - `"o4-mini"`

      - `"o4-mini-2025-04-16"`

      - `"o3"`

      - `"o3-2025-04-16"`

      - `"o3-mini"`

      - `"o3-mini-2025-01-31"`

      - `"o1"`

      - `"o1-2024-12-17"`

      - `"o1-preview"`

      - `"o1-preview-2024-09-12"`

      - `"o1-mini"`

      - `"o1-mini-2024-09-12"`

      - `"gpt-4o"`

      - `"gpt-4o-2024-11-20"`

      - `"gpt-4o-2024-08-06"`

      - `"gpt-4o-2024-05-13"`

      - `"gpt-audio-mini"`

      - `"gpt-audio-mini-2025-12-15"`

      - `"gpt-4o-audio-preview"`

      - `"gpt-4o-audio-preview-2024-10-01"`

      - `"gpt-4o-audio-preview-2024-12-17"`

      - `"gpt-4o-audio-preview-2025-06-03"`

      - `"gpt-4o-mini-audio-preview"`

      - `"gpt-4o-mini-audio-preview-2024-12-17"`

      - `"gpt-4o-search-preview"`

      - `"gpt-4o-mini-search-preview"`

      - `"gpt-4o-search-preview-2025-03-11"`

      - `"gpt-4o-mini-search-preview-2025-03-11"`

      - `"chatgpt-4o-latest"`

      - `"codex-mini-latest"`

      - `"gpt-4o-mini"`

      - `"gpt-4o-mini-2024-07-18"`

      - `"gpt-4-turbo"`

      - `"gpt-4-turbo-2024-04-09"`

      - `"gpt-4-0125-preview"`

      - `"gpt-4-turbo-preview"`

      - `"gpt-4-1106-preview"`

      - `"gpt-4-vision-preview"`

      - `"gpt-4"`

      - `"gpt-4-0314"`

      - `"gpt-4-0613"`

      - `"gpt-4-32k"`

      - `"gpt-4-32k-0314"`

      - `"gpt-4-32k-0613"`

      - `"gpt-3.5-turbo"`

      - `"gpt-3.5-turbo-16k"`

      - `"gpt-3.5-turbo-0301"`

      - `"gpt-3.5-turbo-0613"`

      - `"gpt-3.5-turbo-1106"`

      - `"gpt-3.5-turbo-0125"`

      - `"gpt-3.5-turbo-16k-0613"`

    - `ResponsesOnlyModel = "o1-pro" or "o1-pro-2025-03-19" or "o3-pro" or 17 more`

      - `"o1-pro"`

      - `"o1-pro-2025-03-19"`

      - `"o3-pro"`

      - `"o3-pro-2025-06-10"`

      - `"o3-deep-research"`

      - `"o3-deep-research-2025-06-26"`

      - `"o4-mini-deep-research"`

      - `"o4-mini-deep-research-2025-06-26"`

      - `"computer-use-preview"`

      - `"computer-use-preview-2025-03-11"`

      - `"gpt-5.5-pro"`

      - `"gpt-5.5-pro-2026-04-23"`

      - `"gpt-5-codex"`

      - `"gpt-5-pro"`

      - `"gpt-5-pro-2025-10-06"`

      - `"gpt-5.1-codex-max"`

      - `"gpt-daybreak-blue-latest"`

      - `"gpt-daybreak-red-latest"`

      - `"gpt-5.6-cyber"`

      - `"gpt-rosalind-research"`

  - `object: "response"`

    The object type of this resource - always set to `response`.

    - `"response"`

  - `output: array of ResponseOutputItem`

    An array of content items generated by the model.

    - The length and order of items in the `output` array is dependent
      on the model's response.
    - Rather than accessing the first item in the `output` array and
      assuming it's an `assistant` message with the content generated by
      the model, you might consider using the `output_text` property where
      supported in SDKs.

    - `ResponseOutputMessage object { id, content, role, 3 more }`

      An output message from the model.

    - `FileSearchCall object { id, queries, status, 2 more }`

      The results of a file search tool call. See the
      [file search guide](/api/docs/guides/tools-file-search) for more information.

      - `id: string`

        The unique ID of the file search tool call.

      - `queries: array of string`

        The queries used to search for files.

      - `status: "in_progress" or "searching" or "completed" or 2 more`

        The status of the file search tool call. One of `in_progress`,
        `searching`, `incomplete` or `failed`,

        - `"in_progress"`

        - `"searching"`

        - `"completed"`

        - `"incomplete"`

        - `"failed"`

      - `type: "file_search_call"`

        The type of the file search tool call. Always `file_search_call`.

        - `"file_search_call"`

      - `results: optional array of object { attributes, file_id, filename, 2 more }  or null`

        The results of the file search tool call.

        - `attributes: optional map[string or number or boolean] or null`

          Set of 16 key-value pairs that can be attached to an object. This can be
          useful for storing additional information about the object in a structured
          format, and querying for objects via API or the dashboard. Keys are strings
          with a maximum length of 64 characters. Values are strings with a maximum
          length of 512 characters, booleans, or numbers.

          - `string`

          - `number`

          - `boolean`

        - `file_id: optional string`

          The unique ID of the file.

        - `filename: optional string`

          The name of the file.

        - `score: optional number`

          The relevance score of the file - a value between 0 and 1.

        - `text: optional string`

          The text that was retrieved from the file.

    - `FunctionCall object { arguments, call_id, name, 6 more }`

      A tool call to run a function. See the
      [function calling guide](/api/docs/guides/function-calling) for more information.

      - `arguments: string`

        A JSON string of the arguments to pass to the function.

      - `call_id: string`

        The unique ID of the function tool call generated by the model.

      - `name: string`

        The name of the function to run.

      - `type: "function_call"`

        The type of the function tool call. Always `function_call`.

        - `"function_call"`

      - `id: optional string`

        The unique ID of the function tool call.

      - `async: optional boolean`

        Whether the function tool call runs asynchronously.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `namespace: optional string`

        The namespace of the function to run.

      - `status: optional "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `FunctionCallOutput object { id, output, status, 6 more }`

      - `id: string`

        The unique ID of the function call tool output.

      - `output: string or array of ResponseInputText or ResponseInputImage or ResponseInputFile`

        The output from the function call generated by your code.
        Can be a string or an list of output content.

        - `StringOutput = string`

          A string of the output of the function call.

        - `OutputContentList = array of ResponseInputText or ResponseInputImage or ResponseInputFile`

          Text, image, or file output of the function call.

          - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

            A text input to the model.

          - `ResponseInputImage object { detail, type, file_id, 2 more }`

            An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

          - `ResponseInputFile object { type, detail, file_data, 4 more }`

            A file input to the model.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "function_call_output"`

        The type of the function tool call output. Always `function_call_output`.

        - `"function_call_output"`

      - `call_id: optional string`

        The unique ID of the function tool call generated by the model.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

      - `created_by: optional string`

        The identifier of the actor that created the item.

      - `name: optional string`

        The name of the tool that produced the output.

      - `namespace: optional string`

        The namespace of the tool that produced the output.

    - `WebSearchCall object { id, status, type, action }`

      The results of a web search tool call. See the
      [web search guide](/api/docs/guides/tools-web-search) for more information.

      - `id: string`

        The unique ID of the web search tool call.

      - `status: "in_progress" or "searching" or "completed" or 2 more`

        The status of the web search tool call.

        - `"in_progress"`

        - `"searching"`

        - `"completed"`

        - `"failed"`

        - `"incomplete"`

      - `type: "web_search_call"`

        The type of the web search tool call. Always `web_search_call`.

        - `"web_search_call"`

      - `action: optional Search { type, queries, query, sources }  or OpenPage { type, url }  or FindInPage { pattern, type, url }`

        An object describing the specific action taken in this web search call.
        Includes details on how the model used the web (search, open_page, find_in_page).

        - `Search object { type, queries, query, sources }`

          Action type "search" - Performs a web search query.

          - `type: "search"`

            The action type.

            - `"search"`

          - `queries: optional array of string`

            The search queries.

          - `query: optional string`

            The search query.

          - `sources: optional array of object { type, url }`

            The sources used in the search.

            - `type: "url"`

              The type of source. Always `url`.

              - `"url"`

            - `url: string`

              The URL of the source.

        - `OpenPage object { type, url }`

          Action type "open_page" - Opens a specific URL from search results.

          - `type: "open_page"`

            The action type.

            - `"open_page"`

          - `url: optional string or null`

            The URL opened by the model.

        - `FindInPage object { pattern, type, url }`

          Action type "find_in_page": Searches for a pattern within a loaded page.

          - `pattern: string`

            The pattern or text to search for within the page.

          - `type: "find_in_page"`

            The action type.

            - `"find_in_page"`

          - `url: optional string or null`

            The URL of the page searched for the pattern, when available.

    - `ComputerCall object { id, call_id, pending_safety_checks, 4 more }`

      A tool call to a computer use tool. See the
      [computer use guide](/api/docs/guides/tools-computer-use) for more information.

      - `id: string`

        The unique ID of the computer call.

      - `call_id: string`

        An identifier used when responding to the tool call with output.

      - `pending_safety_checks: array of object { id, code, message }`

        The pending safety checks for the computer call.

        - `id: string`

          The ID of the pending safety check.

        - `code: optional string or null`

          The type of the pending safety check.

        - `message: optional string or null`

          Details about the pending safety check.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "computer_call"`

        The type of the computer call. Always `computer_call`.

        - `"computer_call"`

      - `action: optional ComputerAction`

        A click action.

      - `actions: optional ComputerActionList`

        Flattened batched actions for `computer_use`. Each action includes an
        `type` discriminator and action-specific fields.

    - `ComputerCallOutput object { id, call_id, output, 4 more }`

      - `id: string`

        The ID of the computer tool call output.

      - `call_id: string`

        The ID of the computer tool call that produced the output.

      - `output: ResponseComputerToolCallOutputScreenshot`

        A computer screenshot image used with the computer use tool.

      - `status: "completed" or "incomplete" or "failed" or "in_progress"`

        The status of the message input. One of `in_progress`, `completed`, or
        `incomplete`. Populated when input items are returned via API.

        - `"completed"`

        - `"incomplete"`

        - `"failed"`

        - `"in_progress"`

      - `type: "computer_call_output"`

        The type of the computer tool call output. Always `computer_call_output`.

        - `"computer_call_output"`

      - `acknowledged_safety_checks: optional array of object { id, code, message }`

        The safety checks reported by the API that have been acknowledged by the
        developer.

        - `id: string`

          The ID of the pending safety check.

        - `code: optional string or null`

          The type of the pending safety check.

        - `message: optional string or null`

          Details about the pending safety check.

      - `created_by: optional string`

        The identifier of the actor that created the item.

    - `Reasoning object { id, summary, type, 3 more }`

      A description of the chain of thought used by a reasoning model while generating
      a response. Be sure to include these items in your `input` to the Responses API
      for subsequent turns of a conversation if you are manually
      [managing context](/api/docs/guides/conversation-state).

      - `id: string`

        The unique identifier of the reasoning content.

      - `summary: array of SummaryTextContent`

        Reasoning summary content.

        - `text: string`

          A summary of the reasoning output from the model so far.

        - `type: "summary_text"`

          The type of the object. Always `summary_text`.

      - `type: "reasoning"`

        The type of the object. Always `reasoning`.

        - `"reasoning"`

      - `content: optional array of object { text, type }`

        Reasoning text content.

        - `text: string`

          The reasoning text from the model.

        - `type: "reasoning_text"`

          The type of the reasoning text. Always `reasoning_text`.

          - `"reasoning_text"`

      - `encrypted_content: optional string or null`

        The encrypted content of the reasoning item. This is populated by default
        for reasoning items returned by `POST /v1/responses` and WebSocket
        `response.create` requests.

        When streaming, use the completed reasoning item and its
        `encrypted_content` from the `response.output_item.done` event in
        subsequent requests. The `encrypted_content` in
        `response.output_item.added` may be incomplete. This is especially
        important when `store` is `false` or when using Zero Data Retention.

      - `status: optional "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `Program object { id, call_id, code, 2 more }`

      - `id: string`

        The unique ID of the program item.

      - `call_id: string`

        The stable call ID of the program item.

      - `code: string`

        The JavaScript source executed by programmatic tool calling.

      - `fingerprint: string`

        Opaque program replay fingerprint that must be round-tripped.

      - `type: "program"`

        The type of the item. Always `program`.

        - `"program"`

    - `ProgramOutput object { id, call_id, result, 2 more }`

      - `id: string`

        The unique ID of the program output item.

      - `call_id: string`

        The call ID of the program item.

      - `result: string`

        The result produced by the program item.

      - `status: "completed" or "incomplete"`

        The terminal status of the program output item.

        - `"completed"`

        - `"incomplete"`

      - `type: "program_output"`

        The type of the item. Always `program_output`.

        - `"program_output"`

    - `ToolSearchCall object { id, arguments, call_id, 4 more }`

      - `id: string`

        The unique ID of the tool search call item.

      - `arguments: unknown`

        Arguments used for the tool search call.

      - `call_id: string or null`

        The unique ID of the tool search call generated by the model.

      - `execution: "server" or "client"`

        Whether tool search was executed by the server or by the client.

        - `"server"`

        - `"client"`

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the tool search call item that was recorded.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "tool_search_call"`

        The type of the item. Always `tool_search_call`.

        - `"tool_search_call"`

      - `created_by: optional string`

        The identifier of the actor that created the item.

    - `ToolSearchOutput object { id, call_id, execution, 4 more }`

      - `id: string`

        The unique ID of the tool search output item.

      - `call_id: string or null`

        The unique ID of the tool search call generated by the model.

      - `execution: "server" or "client"`

        Whether tool search was executed by the server or by the client.

        - `"server"`

        - `"client"`

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the tool search output item that was recorded.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

        The loaded tool definitions returned by tool search.

        - `Function object { name, parameters, strict, 6 more }`

          Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

          - `name: string`

            The name of the function to call.

          - `parameters: map[unknown] or null`

            A JSON schema object describing the parameters of the function.

          - `strict: boolean or null`

            Whether strict parameter validation is enforced for this function tool.

          - `type: "function"`

            The type of the function tool. Always `function`.

            - `"function"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

          - `defer_loading: optional boolean`

            Whether this function is deferred and loaded via tool search.

          - `description: optional string or null`

            A description of the function. Used by the model to determine whether or not to call the function.

          - `output_schema: optional map[unknown] or null`

            A JSON schema object describing the JSON value encoded in string outputs for this function.

        - `FileSearch object { type, vector_store_ids, filters, 2 more }`

          A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

          - `type: "file_search"`

            The type of the file search tool. Always `file_search`.

            - `"file_search"`

          - `vector_store_ids: array of string`

            The IDs of the vector stores to search.

          - `filters: optional ComparisonFilter or CompoundFilter or null`

            A filter to apply.

            - `ComparisonFilter object { key, type, value }`

              A filter used to compare a specified attribute key to a given value using a defined comparison operation.

            - `CompoundFilter object { filters, type }`

              Combine multiple filters using `and` or `or`.

          - `max_num_results: optional number`

            The maximum number of results to return. This number should be between 1 and 50 inclusive.

          - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

            Ranking options for search.

            - `hybrid_search: optional object { embedding_weight, text_weight }`

              Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

              - `embedding_weight: number`

                The weight of the embedding in the reciprocal ranking fusion.

              - `text_weight: number`

                The weight of the text in the reciprocal ranking fusion.

            - `ranker: optional "auto" or "default-2024-11-15"`

              The ranker to use for the file search.

              - `"auto"`

              - `"default-2024-11-15"`

            - `score_threshold: optional number`

              The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

        - `Computer object { type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `type: "computer"`

            The type of the computer tool. Always `computer`.

            - `"computer"`

        - `ComputerUsePreview object { display_height, display_width, environment, type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `display_height: number`

            The height of the computer display.

          - `display_width: number`

            The width of the computer display.

          - `environment: "windows" or "mac" or "linux" or 2 more`

            The type of computer environment to control.

            - `"windows"`

            - `"mac"`

            - `"linux"`

            - `"ubuntu"`

            - `"browser"`

          - `type: "computer_use_preview"`

            The type of the computer use tool. Always `computer_use_preview`.

            - `"computer_use_preview"`

        - `WebSearch object { type, external_web_access, filters, 2 more }`

          Search the Internet for sources related to the prompt. Learn more about the
          [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search" or "web_search_2025_08_26"`

            The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

            - `"web_search"`

            - `"web_search_2025_08_26"`

          - `external_web_access: optional boolean`

            Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

          - `filters: optional object { allowed_domains }  or null`

            Filters for the search.

            - `allowed_domains: optional array of string or null`

              Allowed domains for the search. If not provided, all domains are allowed.
              Subdomains of the provided domains are allowed as well.

              Example: `["pubmed.ncbi.nlm.nih.gov"]`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { city, country, region, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the
            United States. To avoid this fallback, pass `{"type": "approximate"}` without
            location fields. To localize results, provide the relevant location fields.

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

            - `type: optional "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

        - `Mcp object { server_label, type, allowed_callers, 9 more }`

          Give the model access to additional tools via remote Model Context Protocol
          (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

          - `server_label: string`

            A label for this MCP server, used to identify it in tool calls.

          - `type: "mcp"`

            The type of the MCP tool. Always `mcp`.

            - `"mcp"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

            List of allowed tool names or a filter object.

            - `McpAllowedTools = array of string`

              A string array of allowed tool names

            - `McpToolFilter object { read_only, tool_names }`

              A filter object to specify which tools are allowed.

              - `read_only: optional boolean`

                Indicates whether or not a tool modifies data or is read-only. If an
                MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                it will match this filter.

              - `tool_names: optional array of string`

                List of allowed tool names.

          - `authorization: optional string`

            An OAuth access token that can be used with a remote MCP server, either
            with a custom MCP server URL or a service connector. Your application
            must handle the OAuth authorization flow and provide the token here.

          - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

            Identifier for service connectors, like those available in ChatGPT. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
            about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

            This field is deprecated for models released after September 1, 2026.
            Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
            connect through a Secure MCP Tunnel.

            Currently supported `connector_id` values are:

            - Dropbox: `connector_dropbox`
            - Gmail: `connector_gmail`
            - Google Calendar: `connector_googlecalendar`
            - Google Drive: `connector_googledrive`
            - Microsoft Teams: `connector_microsoftteams`
            - Outlook Calendar: `connector_outlookcalendar`
            - Outlook Email: `connector_outlookemail`
            - SharePoint: `connector_sharepoint`

            - `"connector_dropbox"`

            - `"connector_gmail"`

            - `"connector_googlecalendar"`

            - `"connector_googledrive"`

            - `"connector_microsoftteams"`

            - `"connector_outlookcalendar"`

            - `"connector_outlookemail"`

            - `"connector_sharepoint"`

          - `defer_loading: optional boolean`

            Whether this MCP tool is deferred and discovered via tool search.

          - `headers: optional map[string] or null`

            Optional HTTP headers to send to the MCP server. Use for authentication
            or other purposes.

          - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

            Specify which of the MCP server's tools require approval.

            - `McpToolApprovalFilter object { always, never }`

              Specify which of the MCP server's tools require approval. Can be
              `always`, `never`, or a filter object associated with tools
              that require approval.

              - `always: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

              - `never: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

            - `McpToolApprovalSetting = "always" or "never"`

              Specify a single approval policy for all tools. One of `always` or
              `never`. When set to `always`, all tools will require approval. When
              set to `never`, all tools will not require approval.

              - `"always"`

              - `"never"`

          - `server_description: optional string`

            Optional description of the MCP server, used to provide more context.

          - `server_url: optional string`

            The URL for the MCP server. One of `server_url`, `connector_id`, or
            `tunnel_id` must be provided.

          - `tunnel_id: optional string`

            The Secure MCP Tunnel ID to use instead of a direct server URL. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided.

        - `CodeInterpreter object { container, type, allowed_callers }`

          A tool that runs Python code to help generate a response to a prompt.

          - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

            The code interpreter container. Can be a container ID or an object that
            specifies uploaded file IDs to make available to your code, along with an
            optional `memory_limit` setting.

            - `string`

              The container ID.

            - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

              Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

              - `type: "auto"`

                Always `auto`.

                - `"auto"`

              - `file_ids: optional array of string`

                An optional list of uploaded files to make available to your code.

              - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                The memory limit for the code interpreter container.

                - `"1g"`

                - `"4g"`

                - `"16g"`

                - `"64g"`

              - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                Network access policy for the container.

                - `ContainerNetworkPolicyDisabled object { type }`

                - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

          - `type: "code_interpreter"`

            The type of the code interpreter tool. Always `code_interpreter`.

            - `"code_interpreter"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

        - `ProgrammaticToolCalling object { type }`

          - `type: "programmatic_tool_calling"`

            The type of the tool. Always `programmatic_tool_calling`.

            - `"programmatic_tool_calling"`

        - `ImageGeneration object { type, action, background, 9 more }`

          A tool that generates images using the GPT image models.

          - `type: "image_generation"`

            The type of the image generation tool. Always `image_generation`.

            - `"image_generation"`

          - `action: optional "generate" or "edit" or "auto"`

            Whether to generate a new image or edit an existing image. Default: `auto`.

            - `"generate"`

            - `"edit"`

            - `"auto"`

          - `background: optional "transparent" or "opaque" or "auto"`

            Set the background of the generated image. One of `transparent`, `opaque`,
            or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
            their `2026-09-08` snapshots, support `opaque` and `transparent`
            backgrounds. Transparent backgrounds are available for supported GPT Image
            models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
            preview. When using `transparent`, set the output format to `png` or `webp`.
            Default: `auto`.

            - `"transparent"`

            - `"opaque"`

            - `"auto"`

          - `input_fidelity: optional "high" or "low" or null`

            Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

            - `"high"`

            - `"low"`

          - `input_image_mask: optional object { file_id, image_url }`

            Optional mask for inpainting. Contains `image_url`
            (string, optional) and `file_id` (string, optional).

            - `file_id: optional string`

              File ID for the mask image.

            - `image_url: optional string`

              Base64-encoded mask image.

          - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

            The image generation model to use. One of `gpt-image-1`,
            `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
            `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
            `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
            `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
            `gpt-image-1`.

            - `string`

            - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

              The image generation model to use. One of `gpt-image-1`,
              `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
              `gpt-image-1`.

              - `"gpt-image-1"`

              - `"gpt-image-1-mini"`

              - `"gpt-image-1.5"`

              - `"gpt-image-2"`

              - `"gpt-image-2-2026-04-21"`

              - `"gpt-image-2.5-sunburst"`

              - `"gpt-image-2.5-sunburst-2026-09-08"`

              - `"gpt-image-2.5-flare"`

              - `"gpt-image-2.5-flare-2026-09-08"`

          - `moderation: optional "auto" or "low"`

            Moderation level for the generated image. Default: `auto`.

            - `"auto"`

            - `"low"`

          - `output_compression: optional number`

            Compression level for the output image. Default: 100.

          - `output_format: optional "png" or "webp" or "jpeg"`

            The output format of the generated image. One of `png`, `webp`, or
            `jpeg`. Default: `png`.

            - `"png"`

            - `"webp"`

            - `"jpeg"`

          - `partial_images: optional number`

            Number of partial images to generate in streaming mode, from 0 (default value) to 3.

          - `quality: optional "low" or "medium" or "high" or 3 more`

            The quality of the generated image. The GPT image models support `low`,
            `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
            including their `2026-09-08` snapshots, also support `xhigh` and `max`.
            Default: `auto`.

            - `"low"`

            - `"medium"`

            - `"high"`

            - `"xhigh"`

            - `"max"`

            - `"auto"`

          - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

            The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

            - `string`

            - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

              The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

              - `"1024x1024"`

              - `"1024x1536"`

              - `"1536x1024"`

              - `"auto"`

        - `LocalShell object { type }`

          A tool that allows the model to execute shell commands in a local environment.

          - `type: "local_shell"`

            The type of the local shell tool. Always `local_shell`.

            - `"local_shell"`

        - `Shell object { type, allowed_callers, environment }`

          A tool that allows the model to execute shell commands.

          - `type: "shell"`

            The type of the shell tool. Always `shell`.

            - `"shell"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

            - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

            - `LocalEnvironment object { type, skills }`

            - `ContainerReference object { container_id, type }`

        - `Custom object { name, type, allowed_callers, 4 more }`

          A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

          - `name: string`

            The name of the custom tool, used to identify it in tool calls.

          - `type: "custom"`

            The type of the custom tool. Always `custom`.

            - `"custom"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

            Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

          - `defer_loading: optional boolean`

            Whether this tool should be deferred and discovered via tool search.

          - `description: optional string`

            Optional description of the custom tool, used to provide more context.

          - `format: optional CustomToolInputFormat`

            The input format for the custom tool. Default is unconstrained text.

        - `Namespace object { description, name, tools, type }`

          Groups function/custom tools under a shared namespace.

          - `description: string`

            A description of the namespace shown to the model.

          - `name: string`

            The namespace name used in tool calls (for example, `crm`).

          - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

            The function/custom tools available inside this namespace.

            - `Function object { name, type, allowed_callers, 6 more }`

              - `name: string`

              - `type: "function"`

                - `"function"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this function should be deferred and discovered via tool search.

              - `description: optional string or null`

              - `output_schema: optional map[unknown] or null`

                A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

              - `parameters: optional unknown or null`

              - `strict: optional boolean or null`

                Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

            - `Custom object { name, type, allowed_callers, 4 more }`

              A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

              - `name: string`

                The name of the custom tool, used to identify it in tool calls.

              - `type: "custom"`

                The type of the custom tool. Always `custom`.

                - `"custom"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this tool should be deferred and discovered via tool search.

              - `description: optional string`

                Optional description of the custom tool, used to provide more context.

              - `format: optional CustomToolInputFormat`

                The input format for the custom tool. Default is unconstrained text.

          - `type: "namespace"`

            The type of the tool. Always `namespace`.

            - `"namespace"`

        - `ToolSearch object { type, description, execution, parameters }`

          Hosted or BYOT tool search configuration for deferred tools.

          - `type: "tool_search"`

            The type of the tool. Always `tool_search`.

            - `"tool_search"`

          - `description: optional string or null`

            Description shown to the model for a client-executed tool search tool.

          - `execution: optional "server" or "client"`

            Whether tool search is executed by the server or by the client.

            - `"server"`

            - `"client"`

          - `parameters: optional unknown or null`

            Parameter schema for a client-executed tool search tool.

        - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

          This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

            The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

            - `"web_search_preview"`

            - `"web_search_preview_2025_03_11"`

          - `search_content_types: optional array of "text" or "image"`

            - `"text"`

            - `"image"`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { type, city, country, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

            - `type: "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

        - `ApplyPatch object { type, allowed_callers }`

          Allows the assistant to create, delete, or update files using unified diffs.

          - `type: "apply_patch"`

            The type of the tool. Always `apply_patch`.

            - `"apply_patch"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

      - `type: "tool_search_output"`

        The type of the item. Always `tool_search_output`.

        - `"tool_search_output"`

      - `created_by: optional string`

        The identifier of the actor that created the item.

    - `AdditionalTools object { id, role, tools, type }`

      - `id: string`

        The unique ID of the additional tools item.

      - `role: "unknown" or "user" or "assistant" or 5 more`

        The role that provided the additional tools.

        - `"unknown"`

        - `"user"`

        - `"assistant"`

        - `"system"`

        - `"critic"`

        - `"discriminator"`

        - `"developer"`

        - `"tool"`

      - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

        The additional tool definitions made available at this item.

        - `Function object { name, parameters, strict, 6 more }`

          Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

          - `name: string`

            The name of the function to call.

          - `parameters: map[unknown] or null`

            A JSON schema object describing the parameters of the function.

          - `strict: boolean or null`

            Whether strict parameter validation is enforced for this function tool.

          - `type: "function"`

            The type of the function tool. Always `function`.

            - `"function"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

          - `defer_loading: optional boolean`

            Whether this function is deferred and loaded via tool search.

          - `description: optional string or null`

            A description of the function. Used by the model to determine whether or not to call the function.

          - `output_schema: optional map[unknown] or null`

            A JSON schema object describing the JSON value encoded in string outputs for this function.

        - `FileSearch object { type, vector_store_ids, filters, 2 more }`

          A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

          - `type: "file_search"`

            The type of the file search tool. Always `file_search`.

            - `"file_search"`

          - `vector_store_ids: array of string`

            The IDs of the vector stores to search.

          - `filters: optional ComparisonFilter or CompoundFilter or null`

            A filter to apply.

            - `ComparisonFilter object { key, type, value }`

              A filter used to compare a specified attribute key to a given value using a defined comparison operation.

            - `CompoundFilter object { filters, type }`

              Combine multiple filters using `and` or `or`.

          - `max_num_results: optional number`

            The maximum number of results to return. This number should be between 1 and 50 inclusive.

          - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

            Ranking options for search.

            - `hybrid_search: optional object { embedding_weight, text_weight }`

              Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

              - `embedding_weight: number`

                The weight of the embedding in the reciprocal ranking fusion.

              - `text_weight: number`

                The weight of the text in the reciprocal ranking fusion.

            - `ranker: optional "auto" or "default-2024-11-15"`

              The ranker to use for the file search.

              - `"auto"`

              - `"default-2024-11-15"`

            - `score_threshold: optional number`

              The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

        - `Computer object { type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `type: "computer"`

            The type of the computer tool. Always `computer`.

            - `"computer"`

        - `ComputerUsePreview object { display_height, display_width, environment, type }`

          A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

          - `display_height: number`

            The height of the computer display.

          - `display_width: number`

            The width of the computer display.

          - `environment: "windows" or "mac" or "linux" or 2 more`

            The type of computer environment to control.

            - `"windows"`

            - `"mac"`

            - `"linux"`

            - `"ubuntu"`

            - `"browser"`

          - `type: "computer_use_preview"`

            The type of the computer use tool. Always `computer_use_preview`.

            - `"computer_use_preview"`

        - `WebSearch object { type, external_web_access, filters, 2 more }`

          Search the Internet for sources related to the prompt. Learn more about the
          [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search" or "web_search_2025_08_26"`

            The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

            - `"web_search"`

            - `"web_search_2025_08_26"`

          - `external_web_access: optional boolean`

            Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

          - `filters: optional object { allowed_domains }  or null`

            Filters for the search.

            - `allowed_domains: optional array of string or null`

              Allowed domains for the search. If not provided, all domains are allowed.
              Subdomains of the provided domains are allowed as well.

              Example: `["pubmed.ncbi.nlm.nih.gov"]`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { city, country, region, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the
            United States. To avoid this fallback, pass `{"type": "approximate"}` without
            location fields. To localize results, provide the relevant location fields.

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

            - `type: optional "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

        - `Mcp object { server_label, type, allowed_callers, 9 more }`

          Give the model access to additional tools via remote Model Context Protocol
          (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

          - `server_label: string`

            A label for this MCP server, used to identify it in tool calls.

          - `type: "mcp"`

            The type of the MCP tool. Always `mcp`.

            - `"mcp"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

            List of allowed tool names or a filter object.

            - `McpAllowedTools = array of string`

              A string array of allowed tool names

            - `McpToolFilter object { read_only, tool_names }`

              A filter object to specify which tools are allowed.

              - `read_only: optional boolean`

                Indicates whether or not a tool modifies data or is read-only. If an
                MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                it will match this filter.

              - `tool_names: optional array of string`

                List of allowed tool names.

          - `authorization: optional string`

            An OAuth access token that can be used with a remote MCP server, either
            with a custom MCP server URL or a service connector. Your application
            must handle the OAuth authorization flow and provide the token here.

          - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

            Identifier for service connectors, like those available in ChatGPT. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
            about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

            This field is deprecated for models released after September 1, 2026.
            Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
            connect through a Secure MCP Tunnel.

            Currently supported `connector_id` values are:

            - Dropbox: `connector_dropbox`
            - Gmail: `connector_gmail`
            - Google Calendar: `connector_googlecalendar`
            - Google Drive: `connector_googledrive`
            - Microsoft Teams: `connector_microsoftteams`
            - Outlook Calendar: `connector_outlookcalendar`
            - Outlook Email: `connector_outlookemail`
            - SharePoint: `connector_sharepoint`

            - `"connector_dropbox"`

            - `"connector_gmail"`

            - `"connector_googlecalendar"`

            - `"connector_googledrive"`

            - `"connector_microsoftteams"`

            - `"connector_outlookcalendar"`

            - `"connector_outlookemail"`

            - `"connector_sharepoint"`

          - `defer_loading: optional boolean`

            Whether this MCP tool is deferred and discovered via tool search.

          - `headers: optional map[string] or null`

            Optional HTTP headers to send to the MCP server. Use for authentication
            or other purposes.

          - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

            Specify which of the MCP server's tools require approval.

            - `McpToolApprovalFilter object { always, never }`

              Specify which of the MCP server's tools require approval. Can be
              `always`, `never`, or a filter object associated with tools
              that require approval.

              - `always: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

              - `never: optional object { read_only, tool_names }`

                A filter object to specify which tools are allowed.

                - `read_only: optional boolean`

                  Indicates whether or not a tool modifies data or is read-only. If an
                  MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
                  it will match this filter.

                - `tool_names: optional array of string`

                  List of allowed tool names.

            - `McpToolApprovalSetting = "always" or "never"`

              Specify a single approval policy for all tools. One of `always` or
              `never`. When set to `always`, all tools will require approval. When
              set to `never`, all tools will not require approval.

              - `"always"`

              - `"never"`

          - `server_description: optional string`

            Optional description of the MCP server, used to provide more context.

          - `server_url: optional string`

            The URL for the MCP server. One of `server_url`, `connector_id`, or
            `tunnel_id` must be provided.

          - `tunnel_id: optional string`

            The Secure MCP Tunnel ID to use instead of a direct server URL. One of
            `server_url`, `connector_id`, or `tunnel_id` must be provided.

        - `CodeInterpreter object { container, type, allowed_callers }`

          A tool that runs Python code to help generate a response to a prompt.

          - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

            The code interpreter container. Can be a container ID or an object that
            specifies uploaded file IDs to make available to your code, along with an
            optional `memory_limit` setting.

            - `string`

              The container ID.

            - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

              Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

              - `type: "auto"`

                Always `auto`.

                - `"auto"`

              - `file_ids: optional array of string`

                An optional list of uploaded files to make available to your code.

              - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

                The memory limit for the code interpreter container.

                - `"1g"`

                - `"4g"`

                - `"16g"`

                - `"64g"`

              - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

                Network access policy for the container.

                - `ContainerNetworkPolicyDisabled object { type }`

                - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

          - `type: "code_interpreter"`

            The type of the code interpreter tool. Always `code_interpreter`.

            - `"code_interpreter"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

        - `ProgrammaticToolCalling object { type }`

          - `type: "programmatic_tool_calling"`

            The type of the tool. Always `programmatic_tool_calling`.

            - `"programmatic_tool_calling"`

        - `ImageGeneration object { type, action, background, 9 more }`

          A tool that generates images using the GPT image models.

          - `type: "image_generation"`

            The type of the image generation tool. Always `image_generation`.

            - `"image_generation"`

          - `action: optional "generate" or "edit" or "auto"`

            Whether to generate a new image or edit an existing image. Default: `auto`.

            - `"generate"`

            - `"edit"`

            - `"auto"`

          - `background: optional "transparent" or "opaque" or "auto"`

            Set the background of the generated image. One of `transparent`, `opaque`,
            or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
            their `2026-09-08` snapshots, support `opaque` and `transparent`
            backgrounds. Transparent backgrounds are available for supported GPT Image
            models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
            preview. When using `transparent`, set the output format to `png` or `webp`.
            Default: `auto`.

            - `"transparent"`

            - `"opaque"`

            - `"auto"`

          - `input_fidelity: optional "high" or "low" or null`

            Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

            - `"high"`

            - `"low"`

          - `input_image_mask: optional object { file_id, image_url }`

            Optional mask for inpainting. Contains `image_url`
            (string, optional) and `file_id` (string, optional).

            - `file_id: optional string`

              File ID for the mask image.

            - `image_url: optional string`

              Base64-encoded mask image.

          - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

            The image generation model to use. One of `gpt-image-1`,
            `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
            `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
            `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
            `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
            `gpt-image-1`.

            - `string`

            - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

              The image generation model to use. One of `gpt-image-1`,
              `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
              `gpt-image-1`.

              - `"gpt-image-1"`

              - `"gpt-image-1-mini"`

              - `"gpt-image-1.5"`

              - `"gpt-image-2"`

              - `"gpt-image-2-2026-04-21"`

              - `"gpt-image-2.5-sunburst"`

              - `"gpt-image-2.5-sunburst-2026-09-08"`

              - `"gpt-image-2.5-flare"`

              - `"gpt-image-2.5-flare-2026-09-08"`

          - `moderation: optional "auto" or "low"`

            Moderation level for the generated image. Default: `auto`.

            - `"auto"`

            - `"low"`

          - `output_compression: optional number`

            Compression level for the output image. Default: 100.

          - `output_format: optional "png" or "webp" or "jpeg"`

            The output format of the generated image. One of `png`, `webp`, or
            `jpeg`. Default: `png`.

            - `"png"`

            - `"webp"`

            - `"jpeg"`

          - `partial_images: optional number`

            Number of partial images to generate in streaming mode, from 0 (default value) to 3.

          - `quality: optional "low" or "medium" or "high" or 3 more`

            The quality of the generated image. The GPT image models support `low`,
            `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
            including their `2026-09-08` snapshots, also support `xhigh` and `max`.
            Default: `auto`.

            - `"low"`

            - `"medium"`

            - `"high"`

            - `"xhigh"`

            - `"max"`

            - `"auto"`

          - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

            The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

            - `string`

            - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

              The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

              - `"1024x1024"`

              - `"1024x1536"`

              - `"1536x1024"`

              - `"auto"`

        - `LocalShell object { type }`

          A tool that allows the model to execute shell commands in a local environment.

          - `type: "local_shell"`

            The type of the local shell tool. Always `local_shell`.

            - `"local_shell"`

        - `Shell object { type, allowed_callers, environment }`

          A tool that allows the model to execute shell commands.

          - `type: "shell"`

            The type of the shell tool. Always `shell`.

            - `"shell"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

            - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

            - `LocalEnvironment object { type, skills }`

            - `ContainerReference object { container_id, type }`

        - `Custom object { name, type, allowed_callers, 4 more }`

          A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

          - `name: string`

            The name of the custom tool, used to identify it in tool calls.

          - `type: "custom"`

            The type of the custom tool. Always `custom`.

            - `"custom"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

            Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

          - `defer_loading: optional boolean`

            Whether this tool should be deferred and discovered via tool search.

          - `description: optional string`

            Optional description of the custom tool, used to provide more context.

          - `format: optional CustomToolInputFormat`

            The input format for the custom tool. Default is unconstrained text.

        - `Namespace object { description, name, tools, type }`

          Groups function/custom tools under a shared namespace.

          - `description: string`

            A description of the namespace shown to the model.

          - `name: string`

            The namespace name used in tool calls (for example, `crm`).

          - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

            The function/custom tools available inside this namespace.

            - `Function object { name, type, allowed_callers, 6 more }`

              - `name: string`

              - `type: "function"`

                - `"function"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this function should be deferred and discovered via tool search.

              - `description: optional string or null`

              - `output_schema: optional map[unknown] or null`

                A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

              - `parameters: optional unknown or null`

              - `strict: optional boolean or null`

                Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

            - `Custom object { name, type, allowed_callers, 4 more }`

              A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

              - `name: string`

                The name of the custom tool, used to identify it in tool calls.

              - `type: "custom"`

                The type of the custom tool. Always `custom`.

                - `"custom"`

              - `allowed_callers: optional array of "direct" or "programmatic" or null`

                The tool invocation context(s).

                - `"direct"`

                - `"programmatic"`

              - `async: optional boolean`

                Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

              - `defer_loading: optional boolean`

                Whether this tool should be deferred and discovered via tool search.

              - `description: optional string`

                Optional description of the custom tool, used to provide more context.

              - `format: optional CustomToolInputFormat`

                The input format for the custom tool. Default is unconstrained text.

          - `type: "namespace"`

            The type of the tool. Always `namespace`.

            - `"namespace"`

        - `ToolSearch object { type, description, execution, parameters }`

          Hosted or BYOT tool search configuration for deferred tools.

          - `type: "tool_search"`

            The type of the tool. Always `tool_search`.

            - `"tool_search"`

          - `description: optional string or null`

            Description shown to the model for a client-executed tool search tool.

          - `execution: optional "server" or "client"`

            Whether tool search is executed by the server or by the client.

            - `"server"`

            - `"client"`

          - `parameters: optional unknown or null`

            Parameter schema for a client-executed tool search tool.

        - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

          This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

          - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

            The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

            - `"web_search_preview"`

            - `"web_search_preview_2025_03_11"`

          - `search_content_types: optional array of "text" or "image"`

            - `"text"`

            - `"image"`

          - `search_context_size: optional "low" or "medium" or "high"`

            High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

            - `"low"`

            - `"medium"`

            - `"high"`

          - `user_location: optional object { type, city, country, 2 more }  or null`

            The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

            - `type: "approximate"`

              The type of location approximation. Always `approximate`.

              - `"approximate"`

            - `city: optional string or null`

              Free text input for the city of the user, e.g. `San Francisco`.

            - `country: optional string or null`

              The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

            - `region: optional string or null`

              Free text input for the region of the user, e.g. `California`.

            - `timezone: optional string or null`

              The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

        - `ApplyPatch object { type, allowed_callers }`

          Allows the assistant to create, delete, or update files using unified diffs.

          - `type: "apply_patch"`

            The type of the tool. Always `apply_patch`.

            - `"apply_patch"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

      - `type: "additional_tools"`

        The type of the item. Always `additional_tools`.

        - `"additional_tools"`

    - `Compaction object { id, encrypted_content, type, created_by }`

      A compaction item generated by the [`v1/responses/compact` API](/api/reference/resources/responses/methods/compact).

      - `id: string`

        The unique ID of the compaction item.

      - `encrypted_content: string`

        The encrypted content that was produced by compaction.

      - `type: "compaction"`

        The type of the item. Always `compaction`.

        - `"compaction"`

      - `created_by: optional string`

        The identifier of the actor that created the item.

    - `ImageGenerationCall object { id, result, status, 8 more }`

      An image generation request made by the model.

      - `id: string`

        The unique ID of the image generation call.

      - `result: string or null`

        The generated image encoded in base64.

      - `status: "in_progress" or "completed" or "generating" or "failed"`

        The status of the image generation call.

        - `"in_progress"`

        - `"completed"`

        - `"generating"`

        - `"failed"`

      - `type: "image_generation_call"`

        The type of the image generation call. Always `image_generation_call`.

        - `"image_generation_call"`

      - `action: optional "generate" or "edit" or "auto" or null`

        The action used for image generation.

        - `"generate"`

        - `"edit"`

        - `"auto"`

      - `background: optional "transparent" or "opaque" or "auto" or null`

        The background setting used for generation.

        - `"transparent"`

        - `"opaque"`

        - `"auto"`

      - `error: optional object { code, message, param, 2 more }`

        Details of a moderation failure, when available.

        - `code: string or null`

          The error code.

        - `message: string`

          A description of the error.

        - `param: string or null`

          The related request parameter.

        - `type: string`

          The error type.

        - `moderation_details: optional object { categories, moderation_stage }`

          Public details for a `moderation_blocked` error, when available.

          - `categories: array of string`

            Public moderation categories. New category values may be added over time.

          - `moderation_stage: "input" or "output" or "unknown"`

            The stage where moderation blocked the image generation call.

            - `"input"`

            - `"output"`

            - `"unknown"`

      - `output_format: optional "png" or "webp" or "jpeg" or null`

        The output format used for generation.

        - `"png"`

        - `"webp"`

        - `"jpeg"`

      - `quality: optional "low" or "medium" or "high" or 3 more or null`

        The quality of the image generated by the image generation tool call. One of `low`, `medium`, `high`, `xhigh`, `max`, or `auto`.

        - `"low"`

        - `"medium"`

        - `"high"`

        - `"xhigh"`

        - `"max"`

        - `"auto"`

      - `revised_prompt: optional string or null`

        The prompt that was used after any model prompt rewriting.

      - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or null`

        The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`.

        - `string`

        - `"1024x1024" or "1024x1536" or "1536x1024"`

          The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`.

          - `"1024x1024"`

          - `"1024x1536"`

          - `"1536x1024"`

    - `CodeInterpreterCall object { id, code, container_id, 3 more }`

      A tool call to run code.

      - `id: string`

        The unique ID of the code interpreter tool call.

      - `code: string or null`

        The code to run, or null if not available.

      - `container_id: string`

        The ID of the container used to run the code.

      - `outputs: array of Logs { logs, type }  or Image { type, url }  or null`

        The outputs generated by the code interpreter, such as logs or images.
        Can be null if no outputs are available.

        - `Logs object { logs, type }`

          The logs output from the code interpreter.

          - `logs: string`

            The logs output from the code interpreter.

          - `type: "logs"`

            The type of the output. Always `logs`.

            - `"logs"`

        - `Image object { type, url }`

          The image output from the code interpreter.

          - `type: "image"`

            The type of the output. Always `image`.

            - `"image"`

          - `url: string`

            The URL of the image output from the code interpreter.

      - `status: "in_progress" or "completed" or "incomplete" or 2 more`

        The status of the code interpreter tool call. Valid values are `in_progress`, `completed`, `incomplete`, `interpreting`, and `failed`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

        - `"interpreting"`

        - `"failed"`

      - `type: "code_interpreter_call"`

        The type of the code interpreter tool call. Always `code_interpreter_call`.

        - `"code_interpreter_call"`

    - `LocalShellCall object { id, action, call_id, 2 more }`

      A tool call to run a command on the local shell.

      - `id: string`

        The unique ID of the local shell call.

      - `action: object { command, env, type, 3 more }`

        Execute a shell command on the server.

        - `command: array of string`

          The command to run.

        - `env: map[string]`

          Environment variables to set for the command.

        - `type: "exec"`

          The type of the local shell action. Always `exec`.

          - `"exec"`

        - `timeout_ms: optional number or null`

          Optional timeout in milliseconds for the command.

        - `user: optional string or null`

          Optional user to run the command as.

        - `working_directory: optional string or null`

          Optional working directory to run the command in.

      - `call_id: string`

        The unique ID of the local shell tool call generated by the model.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the local shell call.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "local_shell_call"`

        The type of the local shell call. Always `local_shell_call`.

        - `"local_shell_call"`

    - `LocalShellCallOutput object { id, output, type, status }`

      The output of a local shell tool call.

      - `id: string`

        The unique ID of the local shell tool call generated by the model.

      - `output: string`

        A JSON string of the output of the local shell tool call.

      - `type: "local_shell_call_output"`

        The type of the local shell tool call output. Always `local_shell_call_output`.

        - `"local_shell_call_output"`

      - `status: optional "in_progress" or "completed" or "incomplete" or null`

        The status of the item. One of `in_progress`, `completed`, or `incomplete`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

    - `ShellCall object { id, action, call_id, 5 more }`

      A tool call that executes one or more shell commands in a managed environment.

      - `id: string`

        The unique ID of the shell tool call. Populated when this item is returned via API.

      - `action: object { commands, max_output_length, timeout_ms }`

        The shell commands and limits that describe how to run the tool call.

        - `commands: array of string`

        - `max_output_length: number or null`

          Optional maximum number of characters to return from each command.

        - `timeout_ms: number or null`

          Optional timeout in milliseconds for the commands.

      - `call_id: string`

        The unique ID of the shell tool call generated by the model.

      - `environment: ResponseLocalEnvironment or ResponseContainerReference or null`

        Represents the use of a local environment to perform shell actions.

        - `ResponseLocalEnvironment object { type }`

          Represents the use of a local environment to perform shell actions.

          - `type: "local"`

            The environment type. Always `local`.

            - `"local"`

        - `ResponseContainerReference object { container_id, type }`

          Represents a container created with /v1/containers.

          - `container_id: string`

          - `type: "container_reference"`

            The environment type. Always `container_reference`.

            - `"container_reference"`

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the shell call. One of `in_progress`, `completed`, or `incomplete`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "shell_call"`

        The type of the item. Always `shell_call`.

        - `"shell_call"`

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `created_by: optional string`

        The ID of the entity that created this tool call.

    - `ShellCallOutput object { id, call_id, max_output_length, 5 more }`

      The output of a shell tool call that was emitted.

      - `id: string`

        The unique ID of the shell call output. Populated when this item is returned via API.

      - `call_id: string`

        The unique ID of the shell tool call generated by the model.

      - `max_output_length: number or null`

        The maximum length of the shell command output. This is generated by the model and should be passed back with the raw output.

      - `output: array of object { outcome, stderr, stdout, created_by }`

        An array of shell call output contents

        - `outcome: Timeout { type }  or Exit { exit_code, type }`

          Represents either an exit outcome (with an exit code) or a timeout outcome for a shell call output chunk.

          - `Timeout object { type }`

            Indicates that the shell call exceeded its configured time limit.

            - `type: "timeout"`

              The outcome type. Always `timeout`.

              - `"timeout"`

          - `Exit object { exit_code, type }`

            Indicates that the shell commands finished and returned an exit code.

            - `exit_code: number`

              Exit code from the shell process.

            - `type: "exit"`

              The outcome type. Always `exit`.

              - `"exit"`

        - `stderr: string`

          The standard error output that was captured.

        - `stdout: string`

          The standard output that was captured.

        - `created_by: optional string`

          The identifier of the actor that created the item.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the shell call output. One of `in_progress`, `completed`, or `incomplete`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "shell_call_output"`

        The type of the shell call output. Always `shell_call_output`.

        - `"shell_call_output"`

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `created_by: optional string`

        The identifier of the actor that created the item.

    - `ApplyPatchCall object { id, call_id, operation, 4 more }`

      A tool call that applies file diffs by creating, deleting, or updating files.

      - `id: string`

        The unique ID of the apply patch tool call. Populated when this item is returned via API.

      - `call_id: string`

        The unique ID of the apply patch tool call generated by the model.

      - `operation: CreateFile { diff, path, type }  or DeleteFile { path, type }  or UpdateFile { diff, path, type }`

        One of the create_file, delete_file, or update_file operations applied via apply_patch.

        - `CreateFile object { diff, path, type }`

          Instruction describing how to create a file via the apply_patch tool.

          - `diff: string`

            Diff to apply.

          - `path: string`

            Path of the file to create.

          - `type: "create_file"`

            Create a new file with the provided diff.

            - `"create_file"`

        - `DeleteFile object { path, type }`

          Instruction describing how to delete a file via the apply_patch tool.

          - `path: string`

            Path of the file to delete.

          - `type: "delete_file"`

            Delete the specified file.

            - `"delete_file"`

        - `UpdateFile object { diff, path, type }`

          Instruction describing how to update a file via the apply_patch tool.

          - `diff: string`

            Diff to apply.

          - `path: string`

            Path of the file to update.

          - `type: "update_file"`

            Update an existing file with the provided diff.

            - `"update_file"`

      - `status: "in_progress" or "completed"`

        The status of the apply patch tool call. One of `in_progress` or `completed`.

        - `"in_progress"`

        - `"completed"`

      - `type: "apply_patch_call"`

        The type of the item. Always `apply_patch_call`.

        - `"apply_patch_call"`

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `created_by: optional string`

        The ID of the entity that created this tool call.

    - `ApplyPatchCallOutput object { id, call_id, status, 4 more }`

      The output emitted by an apply patch tool call.

      - `id: string`

        The unique ID of the apply patch tool call output. Populated when this item is returned via API.

      - `call_id: string`

        The unique ID of the apply patch tool call generated by the model.

      - `status: "completed" or "failed"`

        The status of the apply patch tool call output. One of `completed` or `failed`.

        - `"completed"`

        - `"failed"`

      - `type: "apply_patch_call_output"`

        The type of the item. Always `apply_patch_call_output`.

        - `"apply_patch_call_output"`

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `created_by: optional string`

        The ID of the entity that created this tool call output.

      - `output: optional string or null`

        Optional textual output returned by the apply patch tool.

    - `McpCall object { id, arguments, name, 6 more }`

      An invocation of a tool on an MCP server.

      - `id: string`

        The unique ID of the tool call.

      - `arguments: string`

        A JSON string of the arguments passed to the tool.

      - `name: string`

        The name of the tool that was run.

      - `server_label: string`

        The label of the MCP server running the tool.

      - `type: "mcp_call"`

        The type of the item. Always `mcp_call`.

        - `"mcp_call"`

      - `approval_request_id: optional string or null`

        Unique identifier for the MCP tool call approval request.
        Include this value in a subsequent `mcp_approval_response` input to approve or reject the corresponding tool call.

      - `error: optional McpToolCallError or null`

        The error from the tool call, if any.

      - `output: optional string or null`

        The output from the tool call.

      - `status: optional "in_progress" or "completed" or "incomplete" or 2 more`

        The status of the tool call. One of `in_progress`, `completed`, `incomplete`, `calling`, or `failed`.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

        - `"calling"`

        - `"failed"`

    - `McpListTools object { id, server_label, tools, 2 more }`

      A list of tools available on an MCP server.

      - `id: string`

        The unique ID of the list.

      - `server_label: string`

        The label of the MCP server.

      - `tools: array of object { input_schema, name, annotations, description }`

        The tools available on the server.

        - `input_schema: unknown`

          The JSON schema describing the tool's input.

        - `name: string`

          The name of the tool.

        - `annotations: optional unknown or null`

          Additional annotations about the tool.

        - `description: optional string or null`

          The description of the tool.

      - `type: "mcp_list_tools"`

        The type of the item. Always `mcp_list_tools`.

        - `"mcp_list_tools"`

      - `error: optional string or null`

        Error message if the server could not list tools.

    - `McpApprovalRequest object { id, arguments, name, 2 more }`

      A request for human approval of a tool invocation.

      - `id: string`

        The unique ID of the approval request.

      - `arguments: string`

        A JSON string of arguments for the tool.

      - `name: string`

        The name of the tool to run.

      - `server_label: string`

        The label of the MCP server making the request.

      - `type: "mcp_approval_request"`

        The type of the item. Always `mcp_approval_request`.

        - `"mcp_approval_request"`

    - `McpApprovalResponse object { id, approval_request_id, approve, 2 more }`

      A response to an MCP approval request.

      - `id: string`

        The unique ID of the approval response

      - `approval_request_id: string`

        The ID of the approval request being answered.

      - `approve: boolean`

        Whether the request was approved.

      - `type: "mcp_approval_response"`

        The type of the item. Always `mcp_approval_response`.

        - `"mcp_approval_response"`

      - `reason: optional string or null`

        Optional reason for the decision.

    - `CustomToolCall object { call_id, input, name, 5 more }`

      A call to a custom tool created by the model.

      - `call_id: string`

        An identifier used to map this custom tool call to a tool call output.

      - `input: string`

        The input for the custom tool call generated by the model.

      - `name: string`

        The name of the custom tool being called.

      - `type: "custom_tool_call"`

        The type of the custom tool call. Always `custom_tool_call`.

        - `"custom_tool_call"`

      - `id: optional string`

        The unique ID of the custom tool call in the OpenAI platform.

      - `async: optional boolean`

        Whether the custom tool call runs asynchronously.

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            - `"program"`

      - `namespace: optional string`

        The namespace of the custom tool being called.

    - `CustomToolCallOutput object { id, call_id, output, 4 more }`

      - `id: string`

        The unique ID of the custom tool call output item.

      - `call_id: string`

        The call ID, used to map this custom tool call output to a custom tool call.

      - `output: string or array of ResponseInputText or ResponseInputImage or ResponseInputFile`

        The output from the custom tool call generated by your code.
        Can be a string or an list of output content.

        - `StringOutput = string`

          A string of the output of the custom tool call.

        - `OutputContentList = array of ResponseInputText or ResponseInputImage or ResponseInputFile`

          Text, image, or file output of the custom tool call.

          - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

            A text input to the model.

          - `ResponseInputImage object { detail, type, file_id, 2 more }`

            An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

          - `ResponseInputFile object { type, detail, file_data, 4 more }`

            A file input to the model.

      - `status: "in_progress" or "completed" or "incomplete"`

        The status of the item. One of `in_progress`, `completed`, or
        `incomplete`. Populated when items are returned via API.

        - `"in_progress"`

        - `"completed"`

        - `"incomplete"`

      - `type: "custom_tool_call_output"`

        The type of the custom tool call output. Always `custom_tool_call_output`.

        - `"custom_tool_call_output"`

      - `caller: optional Direct { type }  or Program { caller_id, type }  or null`

        The execution context that produced this tool call.

        - `Direct object { type }`

          - `type: "direct"`

            The caller type. Always `direct`.

            - `"direct"`

        - `Program object { caller_id, type }`

          - `caller_id: string`

            The call ID of the program item that produced this tool call.

          - `type: "program"`

            The caller type. Always `program`.

            - `"program"`

      - `created_by: optional string`

        The identifier of the actor that created the item.

  - `parallel_tool_calls: boolean`

    Whether to allow the model to run tool calls in parallel.

  - `temperature: number or null`

    What sampling temperature to use, between 0 and 2. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.
    We generally recommend altering this or `top_p` but not both.

  - `tool_choice: ToolChoiceOptions or ToolChoiceAllowed or ToolChoiceTypes or 6 more`

    How the model should select which tool (or tools) to use when generating
    a response. See the `tools` parameter to see how to specify which tools
    the model can call.

    - `ToolChoiceOptions = "none" or "auto" or "required"`

      Controls which (if any) tool is called by the model.

      `none` means the model will not call any tool and instead generates a message.

      `auto` means the model can pick between generating a message or calling one or
      more tools.

      `required` means the model must call one or more tools.

      - `"none"`

      - `"auto"`

      - `"required"`

    - `ToolChoiceAllowed object { mode, tools, type }`

      Constrains the tools available to the model to a pre-defined set.

      - `mode: "auto" or "required"`

        Constrains the tools available to the model to a pre-defined set.

        `auto` allows the model to pick from among the allowed tools and generate a
        message.

        `required` requires the model to call one or more of the allowed tools.

        - `"auto"`

        - `"required"`

      - `tools: array of map[unknown]`

        A list of tool definitions that the model should be allowed to call.

        For the Responses API, the list of tool definitions might look like:

        ```json
        [
          { "type": "function", "name": "get_weather" },
          { "type": "mcp", "server_label": "deepwiki" },
          { "type": "image_generation" }
        ]
        ```

      - `type: "allowed_tools"`

        Allowed tool configuration type. Always `allowed_tools`.

        - `"allowed_tools"`

    - `ToolChoiceTypes object { type }`

      Indicates that the model should use a built-in tool to generate a response.
      [Learn more about built-in tools](/api/docs/guides/tools).

      - `type: "file_search" or "web_search_preview" or "computer" or 5 more`

        The type of hosted tool the model should to use. Learn more about
        [built-in tools](/api/docs/guides/tools).

        Allowed values are:

        - `file_search`
        - `web_search_preview`
        - `computer`
        - `computer_use_preview`
        - `computer_use`
        - `code_interpreter`
        - `image_generation`

        - `"file_search"`

        - `"web_search_preview"`

        - `"computer"`

        - `"computer_use_preview"`

        - `"computer_use"`

        - `"web_search_preview_2025_03_11"`

        - `"image_generation"`

        - `"code_interpreter"`

    - `ToolChoiceFunction object { name, type }`

      Use this option to force the model to call a specific function.

      - `name: string`

        The name of the function to call.

      - `type: "function"`

        For function calling, the type is always `function`.

        - `"function"`

    - `ToolChoiceMcp object { server_label, type, name }`

      Use this option to force the model to call a specific tool on a remote MCP server.

      - `server_label: string`

        The label of the MCP server to use.

      - `type: "mcp"`

        For MCP tools, the type is always `mcp`.

        - `"mcp"`

      - `name: optional string or null`

        The name of the tool to call on the server.

    - `ToolChoiceCustom object { name, type }`

      Use this option to force the model to call a specific custom tool.

      - `name: string`

        The name of the custom tool to call.

      - `type: "custom"`

        For custom tool calling, the type is always `custom`.

        - `"custom"`

    - `SpecificProgrammaticToolCallingParam object { type }`

      - `type: "programmatic_tool_calling"`

        The tool to call. Always `programmatic_tool_calling`.

        - `"programmatic_tool_calling"`

    - `ToolChoiceApplyPatch object { type }`

      Forces the model to call the apply_patch tool when executing a tool call.

      - `type: "apply_patch"`

        The tool to call. Always `apply_patch`.

        - `"apply_patch"`

    - `ToolChoiceShell object { type }`

      Forces the model to call the shell tool when a tool call is required.

      - `type: "shell"`

        The tool to call. Always `shell`.

        - `"shell"`

  - `tools: array of Function { name, parameters, strict, 6 more }  or FileSearch { type, vector_store_ids, filters, 2 more }  or Computer { type }  or 13 more`

    An array of tools the model may call while generating a response. You
    can specify which tool to use by setting the `tool_choice` parameter.

    We support the following categories of tools:

    - **Built-in tools**: Tools that are provided by OpenAI that extend the
      model's capabilities, like [web search](/api/docs/guides/tools-web-search)
      or [file search](/api/docs/guides/tools-file-search). Learn more about
      [built-in tools](/api/docs/guides/tools).
    - **MCP Tools**: Integrations with third-party systems via custom MCP servers
      or predefined connectors such as Google Drive and SharePoint. Learn more about
      [MCP Tools](/api/docs/guides/tools-connectors-mcp).
    - **Function calls (custom tools)**: Functions that are defined by you,
      enabling the model to call your own code with strongly typed arguments
      and outputs. Learn more about
      [function calling](/api/docs/guides/function-calling). You can also use
      custom tools to call your own code.

    - `Function object { name, parameters, strict, 6 more }`

      Defines a function in your own code the model can choose to call. Learn more about [function calling](/api/docs/guides/function-calling).

      - `name: string`

        The name of the function to call.

      - `parameters: map[unknown] or null`

        A JSON schema object describing the parameters of the function.

      - `strict: boolean or null`

        Whether strict parameter validation is enforced for this function tool.

      - `type: "function"`

        The type of the function tool. Always `function`.

        - `"function"`

      - `allowed_callers: optional array of "direct" or "programmatic" or null`

        The tool invocation context(s).

        - `"direct"`

        - `"programmatic"`

      - `async: optional boolean`

      - `defer_loading: optional boolean`

        Whether this function is deferred and loaded via tool search.

      - `description: optional string or null`

        A description of the function. Used by the model to determine whether or not to call the function.

      - `output_schema: optional map[unknown] or null`

        A JSON schema object describing the JSON value encoded in string outputs for this function.

    - `FileSearch object { type, vector_store_ids, filters, 2 more }`

      A tool that searches for relevant content from uploaded files. Learn more about the [file search tool](/api/docs/guides/tools-file-search).

      - `type: "file_search"`

        The type of the file search tool. Always `file_search`.

        - `"file_search"`

      - `vector_store_ids: array of string`

        The IDs of the vector stores to search.

      - `filters: optional ComparisonFilter or CompoundFilter or null`

        A filter to apply.

        - `ComparisonFilter object { key, type, value }`

          A filter used to compare a specified attribute key to a given value using a defined comparison operation.

        - `CompoundFilter object { filters, type }`

          Combine multiple filters using `and` or `or`.

      - `max_num_results: optional number`

        The maximum number of results to return. This number should be between 1 and 50 inclusive.

      - `ranking_options: optional object { hybrid_search, ranker, score_threshold }`

        Ranking options for search.

        - `hybrid_search: optional object { embedding_weight, text_weight }`

          Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.

          - `embedding_weight: number`

            The weight of the embedding in the reciprocal ranking fusion.

          - `text_weight: number`

            The weight of the text in the reciprocal ranking fusion.

        - `ranker: optional "auto" or "default-2024-11-15"`

          The ranker to use for the file search.

          - `"auto"`

          - `"default-2024-11-15"`

        - `score_threshold: optional number`

          The score threshold for the file search, a number between 0 and 1. Numbers closer to 1 will attempt to return only the most relevant results, but may return fewer results.

    - `Computer object { type }`

      A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

      - `type: "computer"`

        The type of the computer tool. Always `computer`.

        - `"computer"`

    - `ComputerUsePreview object { display_height, display_width, environment, type }`

      A tool that controls a virtual computer. Learn more about the [computer tool](/api/docs/guides/tools-computer-use).

      - `display_height: number`

        The height of the computer display.

      - `display_width: number`

        The width of the computer display.

      - `environment: "windows" or "mac" or "linux" or 2 more`

        The type of computer environment to control.

        - `"windows"`

        - `"mac"`

        - `"linux"`

        - `"ubuntu"`

        - `"browser"`

      - `type: "computer_use_preview"`

        The type of the computer use tool. Always `computer_use_preview`.

        - `"computer_use_preview"`

    - `WebSearch object { type, external_web_access, filters, 2 more }`

      Search the Internet for sources related to the prompt. Learn more about the
      [web search tool](/api/docs/guides/tools-web-search).

      - `type: "web_search" or "web_search_2025_08_26"`

        The type of the web search tool. One of `web_search` or `web_search_2025_08_26`.

        - `"web_search"`

        - `"web_search_2025_08_26"`

      - `external_web_access: optional boolean`

        Allow live internet access for web search. Defaults to true when omitted. When false, the web search tool runs in offline/cache-only mode and will not fetch new external content.

      - `filters: optional object { allowed_domains }  or null`

        Filters for the search.

        - `allowed_domains: optional array of string or null`

          Allowed domains for the search. If not provided, all domains are allowed.
          Subdomains of the provided domains are allowed as well.

          Example: `["pubmed.ncbi.nlm.nih.gov"]`

      - `search_context_size: optional "low" or "medium" or "high"`

        High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

        - `"low"`

        - `"medium"`

        - `"high"`

      - `user_location: optional object { city, country, region, 2 more }  or null`

        The approximate location of the user. If omitted or null, defaults to the
        United States. To avoid this fallback, pass `{"type": "approximate"}` without
        location fields. To localize results, provide the relevant location fields.

        - `city: optional string or null`

          Free text input for the city of the user, e.g. `San Francisco`.

        - `country: optional string or null`

          The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

        - `region: optional string or null`

          Free text input for the region of the user, e.g. `California`.

        - `timezone: optional string or null`

          The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

        - `type: optional "approximate"`

          The type of location approximation. Always `approximate`.

          - `"approximate"`

    - `Mcp object { server_label, type, allowed_callers, 9 more }`

      Give the model access to additional tools via remote Model Context Protocol
      (MCP) servers. [Learn more about MCP](/api/docs/guides/tools-connectors-mcp).

      - `server_label: string`

        A label for this MCP server, used to identify it in tool calls.

      - `type: "mcp"`

        The type of the MCP tool. Always `mcp`.

        - `"mcp"`

      - `allowed_callers: optional array of "direct" or "programmatic" or null`

        The tool invocation context(s).

        - `"direct"`

        - `"programmatic"`

      - `allowed_tools: optional array of string or McpToolFilter { read_only, tool_names }  or null`

        List of allowed tool names or a filter object.

        - `McpAllowedTools = array of string`

          A string array of allowed tool names

        - `McpToolFilter object { read_only, tool_names }`

          A filter object to specify which tools are allowed.

          - `read_only: optional boolean`

            Indicates whether or not a tool modifies data or is read-only. If an
            MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
            it will match this filter.

          - `tool_names: optional array of string`

            List of allowed tool names.

      - `authorization: optional string`

        An OAuth access token that can be used with a remote MCP server, either
        with a custom MCP server URL or a service connector. Your application
        must handle the OAuth authorization flow and provide the token here.

      - `connector_id: optional "connector_dropbox" or "connector_gmail" or "connector_googlecalendar" or 5 more`

        Identifier for service connectors, like those available in ChatGPT. One of
        `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
        about service connectors [here](/api/docs/guides/tools-connectors-mcp#connectors).

        This field is deprecated for models released after September 1, 2026.
        Use `server_url` to connect to a remote MCP server, or `tunnel_id` to
        connect through a Secure MCP Tunnel.

        Currently supported `connector_id` values are:

        - Dropbox: `connector_dropbox`
        - Gmail: `connector_gmail`
        - Google Calendar: `connector_googlecalendar`
        - Google Drive: `connector_googledrive`
        - Microsoft Teams: `connector_microsoftteams`
        - Outlook Calendar: `connector_outlookcalendar`
        - Outlook Email: `connector_outlookemail`
        - SharePoint: `connector_sharepoint`

        - `"connector_dropbox"`

        - `"connector_gmail"`

        - `"connector_googlecalendar"`

        - `"connector_googledrive"`

        - `"connector_microsoftteams"`

        - `"connector_outlookcalendar"`

        - `"connector_outlookemail"`

        - `"connector_sharepoint"`

      - `defer_loading: optional boolean`

        Whether this MCP tool is deferred and discovered via tool search.

      - `headers: optional map[string] or null`

        Optional HTTP headers to send to the MCP server. Use for authentication
        or other purposes.

      - `require_approval: optional McpToolApprovalFilter { always, never }  or "always" or "never" or null`

        Specify which of the MCP server's tools require approval.

        - `McpToolApprovalFilter object { always, never }`

          Specify which of the MCP server's tools require approval. Can be
          `always`, `never`, or a filter object associated with tools
          that require approval.

          - `always: optional object { read_only, tool_names }`

            A filter object to specify which tools are allowed.

            - `read_only: optional boolean`

              Indicates whether or not a tool modifies data or is read-only. If an
              MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
              it will match this filter.

            - `tool_names: optional array of string`

              List of allowed tool names.

          - `never: optional object { read_only, tool_names }`

            A filter object to specify which tools are allowed.

            - `read_only: optional boolean`

              Indicates whether or not a tool modifies data or is read-only. If an
              MCP server is [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
              it will match this filter.

            - `tool_names: optional array of string`

              List of allowed tool names.

        - `McpToolApprovalSetting = "always" or "never"`

          Specify a single approval policy for all tools. One of `always` or
          `never`. When set to `always`, all tools will require approval. When
          set to `never`, all tools will not require approval.

          - `"always"`

          - `"never"`

      - `server_description: optional string`

        Optional description of the MCP server, used to provide more context.

      - `server_url: optional string`

        The URL for the MCP server. One of `server_url`, `connector_id`, or
        `tunnel_id` must be provided.

      - `tunnel_id: optional string`

        The Secure MCP Tunnel ID to use instead of a direct server URL. One of
        `server_url`, `connector_id`, or `tunnel_id` must be provided.

    - `CodeInterpreter object { container, type, allowed_callers }`

      A tool that runs Python code to help generate a response to a prompt.

      - `container: string or CodeInterpreterToolAuto { type, file_ids, memory_limit, network_policy }`

        The code interpreter container. Can be a container ID or an object that
        specifies uploaded file IDs to make available to your code, along with an
        optional `memory_limit` setting.

        - `string`

          The container ID.

        - `CodeInterpreterToolAuto object { type, file_ids, memory_limit, network_policy }`

          Configuration for a code interpreter container. Optionally specify the IDs of the files to run the code on.

          - `type: "auto"`

            Always `auto`.

            - `"auto"`

          - `file_ids: optional array of string`

            An optional list of uploaded files to make available to your code.

          - `memory_limit: optional "1g" or "4g" or "16g" or "64g" or null`

            The memory limit for the code interpreter container.

            - `"1g"`

            - `"4g"`

            - `"16g"`

            - `"64g"`

          - `network_policy: optional ContainerNetworkPolicyDisabled or ContainerNetworkPolicyAllowlist`

            Network access policy for the container.

            - `ContainerNetworkPolicyDisabled object { type }`

            - `ContainerNetworkPolicyAllowlist object { allowed_domains, type, domain_secrets }`

      - `type: "code_interpreter"`

        The type of the code interpreter tool. Always `code_interpreter`.

        - `"code_interpreter"`

      - `allowed_callers: optional array of "direct" or "programmatic" or null`

        The tool invocation context(s).

        - `"direct"`

        - `"programmatic"`

    - `ProgrammaticToolCalling object { type }`

      - `type: "programmatic_tool_calling"`

        The type of the tool. Always `programmatic_tool_calling`.

        - `"programmatic_tool_calling"`

    - `ImageGeneration object { type, action, background, 9 more }`

      A tool that generates images using the GPT image models.

      - `type: "image_generation"`

        The type of the image generation tool. Always `image_generation`.

        - `"image_generation"`

      - `action: optional "generate" or "edit" or "auto"`

        Whether to generate a new image or edit an existing image. Default: `auto`.

        - `"generate"`

        - `"edit"`

        - `"auto"`

      - `background: optional "transparent" or "opaque" or "auto"`

        Set the background of the generated image. One of `transparent`, `opaque`,
        or `auto`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including
        their `2026-09-08` snapshots, support `opaque` and `transparent`
        backgrounds. Transparent backgrounds are available for supported GPT Image
        models. For `gpt-image-2` and `gpt-image-2-2026-04-21`, this support is in
        preview. When using `transparent`, set the output format to `png` or `webp`.
        Default: `auto`.

        - `"transparent"`

        - `"opaque"`

        - `"auto"`

      - `input_fidelity: optional "high" or "low" or null`

        Control how much effort the model will exert to match the style and features, especially facial features, of input images. Supports `high` and `low` on `gpt-image-1` and `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit this parameter. Defaults to `low` on supported models.

        - `"high"`

        - `"low"`

      - `input_image_mask: optional object { file_id, image_url }`

        Optional mask for inpainting. Contains `image_url`
        (string, optional) and `file_id` (string, optional).

        - `file_id: optional string`

          File ID for the mask image.

        - `image_url: optional string`

          Base64-encoded mask image.

      - `model: optional string or "gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

        The image generation model to use. One of `gpt-image-1`,
        `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
        `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
        `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
        `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
        `gpt-image-1`.

        - `string`

        - `"gpt-image-1" or "gpt-image-1-mini" or "gpt-image-1.5" or 6 more`

          The image generation model to use. One of `gpt-image-1`,
          `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
          `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
          `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
          `gpt-image-2.5-flare-2026-09-08`, or `chatgpt-image-latest`. Default:
          `gpt-image-1`.

          - `"gpt-image-1"`

          - `"gpt-image-1-mini"`

          - `"gpt-image-1.5"`

          - `"gpt-image-2"`

          - `"gpt-image-2-2026-04-21"`

          - `"gpt-image-2.5-sunburst"`

          - `"gpt-image-2.5-sunburst-2026-09-08"`

          - `"gpt-image-2.5-flare"`

          - `"gpt-image-2.5-flare-2026-09-08"`

      - `moderation: optional "auto" or "low"`

        Moderation level for the generated image. Default: `auto`.

        - `"auto"`

        - `"low"`

      - `output_compression: optional number`

        Compression level for the output image. Default: 100.

      - `output_format: optional "png" or "webp" or "jpeg"`

        The output format of the generated image. One of `png`, `webp`, or
        `jpeg`. Default: `png`.

        - `"png"`

        - `"webp"`

        - `"jpeg"`

      - `partial_images: optional number`

        Number of partial images to generate in streaming mode, from 0 (default value) to 3.

      - `quality: optional "low" or "medium" or "high" or 3 more`

        The quality of the generated image. The GPT image models support `low`,
        `medium`, and `high`. `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`,
        including their `2026-09-08` snapshots, also support `xhigh` and `max`.
        Default: `auto`.

        - `"low"`

        - `"medium"`

        - `"high"`

        - `"xhigh"`

        - `"max"`

        - `"auto"`

      - `size: optional string or "1024x1024" or "1024x1536" or "1536x1024" or "auto"`

        The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

        - `string`

        - `"1024x1024" or "1024x1536" or "1536x1024" or "auto"`

          The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and the maximum supported resolution is `3840x2160`. The requested size must also satisfy the model's current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models; `auto` is supported for models that allow automatic sizing.

          - `"1024x1024"`

          - `"1024x1536"`

          - `"1536x1024"`

          - `"auto"`

    - `LocalShell object { type }`

      A tool that allows the model to execute shell commands in a local environment.

      - `type: "local_shell"`

        The type of the local shell tool. Always `local_shell`.

        - `"local_shell"`

    - `Shell object { type, allowed_callers, environment }`

      A tool that allows the model to execute shell commands.

      - `type: "shell"`

        The type of the shell tool. Always `shell`.

        - `"shell"`

      - `allowed_callers: optional array of "direct" or "programmatic" or null`

        The tool invocation context(s).

        - `"direct"`

        - `"programmatic"`

      - `environment: optional ContainerAuto or LocalEnvironment or ContainerReference or null`

        - `ContainerAuto object { type, file_ids, memory_limit, 2 more }`

        - `LocalEnvironment object { type, skills }`

        - `ContainerReference object { container_id, type }`

    - `Custom object { name, type, allowed_callers, 4 more }`

      A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

      - `name: string`

        The name of the custom tool, used to identify it in tool calls.

      - `type: "custom"`

        The type of the custom tool. Always `custom`.

        - `"custom"`

      - `allowed_callers: optional array of "direct" or "programmatic" or null`

        The tool invocation context(s).

        - `"direct"`

        - `"programmatic"`

      - `async: optional boolean`

        Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

      - `defer_loading: optional boolean`

        Whether this tool should be deferred and discovered via tool search.

      - `description: optional string`

        Optional description of the custom tool, used to provide more context.

      - `format: optional CustomToolInputFormat`

        The input format for the custom tool. Default is unconstrained text.

    - `Namespace object { description, name, tools, type }`

      Groups function/custom tools under a shared namespace.

      - `description: string`

        A description of the namespace shown to the model.

      - `name: string`

        The namespace name used in tool calls (for example, `crm`).

      - `tools: array of Function { name, type, allowed_callers, 6 more }  or Custom { name, type, allowed_callers, 4 more }`

        The function/custom tools available inside this namespace.

        - `Function object { name, type, allowed_callers, 6 more }`

          - `name: string`

          - `type: "function"`

            - `"function"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

            Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

          - `defer_loading: optional boolean`

            Whether this function should be deferred and discovered via tool search.

          - `description: optional string or null`

          - `output_schema: optional map[unknown] or null`

            A JSON Schema describing the JSON value encoded in string outputs for this function tool. This does not describe content-array outputs.

          - `parameters: optional unknown or null`

          - `strict: optional boolean or null`

            Whether to enforce strict parameter validation. If omitted, Responses attempts to use strict validation when the schema is compatible, and falls back to non-strict validation otherwise.

        - `Custom object { name, type, allowed_callers, 4 more }`

          A custom tool that processes input using a specified format. Learn more about   [custom tools](/api/docs/guides/function-calling#custom-tools)

          - `name: string`

            The name of the custom tool, used to identify it in tool calls.

          - `type: "custom"`

            The type of the custom tool. Always `custom`.

            - `"custom"`

          - `allowed_callers: optional array of "direct" or "programmatic" or null`

            The tool invocation context(s).

            - `"direct"`

            - `"programmatic"`

          - `async: optional boolean`

            Whether the tool response can be returned asynchronously versus immediately returned on next response creation.

          - `defer_loading: optional boolean`

            Whether this tool should be deferred and discovered via tool search.

          - `description: optional string`

            Optional description of the custom tool, used to provide more context.

          - `format: optional CustomToolInputFormat`

            The input format for the custom tool. Default is unconstrained text.

      - `type: "namespace"`

        The type of the tool. Always `namespace`.

        - `"namespace"`

    - `ToolSearch object { type, description, execution, parameters }`

      Hosted or BYOT tool search configuration for deferred tools.

      - `type: "tool_search"`

        The type of the tool. Always `tool_search`.

        - `"tool_search"`

      - `description: optional string or null`

        Description shown to the model for a client-executed tool search tool.

      - `execution: optional "server" or "client"`

        Whether tool search is executed by the server or by the client.

        - `"server"`

        - `"client"`

      - `parameters: optional unknown or null`

        Parameter schema for a client-executed tool search tool.

    - `WebSearchPreview object { type, search_content_types, search_context_size, user_location }`

      This tool searches the web for relevant results to use in a response. Learn more about the [web search tool](/api/docs/guides/tools-web-search).

      - `type: "web_search_preview" or "web_search_preview_2025_03_11"`

        The type of the web search tool. One of `web_search_preview` or `web_search_preview_2025_03_11`.

        - `"web_search_preview"`

        - `"web_search_preview_2025_03_11"`

      - `search_content_types: optional array of "text" or "image"`

        - `"text"`

        - `"image"`

      - `search_context_size: optional "low" or "medium" or "high"`

        High level guidance for the amount of context window space to use for the search. One of `low`, `medium`, or `high`. `medium` is the default.

        - `"low"`

        - `"medium"`

        - `"high"`

      - `user_location: optional object { type, city, country, 2 more }  or null`

        The approximate location of the user. If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.

        - `type: "approximate"`

          The type of location approximation. Always `approximate`.

          - `"approximate"`

        - `city: optional string or null`

          Free text input for the city of the user, e.g. `San Francisco`.

        - `country: optional string or null`

          The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of the user, e.g. `US`.

        - `region: optional string or null`

          Free text input for the region of the user, e.g. `California`.

        - `timezone: optional string or null`

          The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the user, e.g. `America/Los_Angeles`.

    - `ApplyPatch object { type, allowed_callers }`

      Allows the assistant to create, delete, or update files using unified diffs.

      - `type: "apply_patch"`

        The type of the tool. Always `apply_patch`.

        - `"apply_patch"`

      - `allowed_callers: optional array of "direct" or "programmatic" or null`

        The tool invocation context(s).

        - `"direct"`

        - `"programmatic"`

  - `top_p: number or null`

    An alternative to sampling with temperature, called nucleus sampling,
    where the model considers the results of the tokens with top_p probability
    mass. So 0.1 means only the tokens comprising the top 10% probability mass
    are considered.

    We generally recommend altering this or `temperature` but not both.

  - `background: optional boolean or null`

    Whether to run the model response in the background.
    [Learn more](/api/docs/guides/background).

  - `completed_at: optional number or null`

    Unix timestamp (in seconds) of when this Response was completed.
    Only present when the status is `completed`.

  - `conversation: optional object { id }  or null`

    The conversation that this response belonged to. Input items and output items from this response were automatically added to this conversation.

    - `id: string`

      The unique ID of the conversation that this response was associated with.

  - `max_output_tokens: optional number or null`

    An upper bound for the number of tokens that can be generated for a response, including visible output tokens and [reasoning tokens](/api/docs/guides/reasoning).

  - `max_tool_calls: optional number or null`

    The maximum number of total calls to built-in tools that can be processed in a response. This maximum number applies across all built-in tool calls, not per individual tool. Any further attempts to call a tool by the model will be ignored.

  - `moderation: optional object { input, output }  or null`

    Moderation results for the response input and output, if moderated completions were requested.

    - `input: ModerationResult { categories, category_applied_input_types, category_scores, 3 more }  or Error { code, message, type }`

      Moderation for the response input.

      - `ModerationResult object { categories, category_applied_input_types, category_scores, 3 more }`

        A moderation result produced for the response input or output.

        - `categories: map[boolean]`

          A dictionary of moderation categories to booleans, True if the input is flagged under this category.

        - `category_applied_input_types: map[array of "text" or "image"]`

          Which modalities of input are reflected by the score for each category.

          - `"text"`

          - `"image"`

        - `category_scores: map[number]`

          A dictionary of moderation categories to scores.

        - `flagged: boolean`

          A boolean indicating whether the content was flagged by any category.

        - `model: string`

          The moderation model that produced this result.

        - `type: "moderation_result"`

          The object type, which was always `moderation_result` for successful moderation results.

          - `"moderation_result"`

      - `Error object { code, message, type }`

        An error produced while attempting moderation for the response input or output.

        - `code: string`

          The error code.

        - `message: string`

          The error message.

        - `type: "error"`

          The object type, which was always `error` for moderation failures.

          - `"error"`

    - `output: ModerationResult { categories, category_applied_input_types, category_scores, 3 more }  or Error { code, message, type }`

      Moderation for the response output.

      - `ModerationResult object { categories, category_applied_input_types, category_scores, 3 more }`

        A moderation result produced for the response input or output.

        - `categories: map[boolean]`

          A dictionary of moderation categories to booleans, True if the input is flagged under this category.

        - `category_applied_input_types: map[array of "text" or "image"]`

          Which modalities of input are reflected by the score for each category.

          - `"text"`

          - `"image"`

        - `category_scores: map[number]`

          A dictionary of moderation categories to scores.

        - `flagged: boolean`

          A boolean indicating whether the content was flagged by any category.

        - `model: string`

          The moderation model that produced this result.

        - `type: "moderation_result"`

          The object type, which was always `moderation_result` for successful moderation results.

          - `"moderation_result"`

      - `Error object { code, message, type }`

        An error produced while attempting moderation for the response input or output.

        - `code: string`

          The error code.

        - `message: string`

          The error message.

        - `type: "error"`

          The object type, which was always `error` for moderation failures.

          - `"error"`

  - `output_text: optional string or null`

    SDK-only convenience property that contains the aggregated text output
    from all `output_text` items in the `output` array, if any are present.
    Supported in the Python and JavaScript SDKs.

  - `previous_response_id: optional string or null`

    The unique ID of the previous response to the model. Use this to
    create multi-turn conversations. Learn more about
    [conversation state](/api/docs/guides/conversation-state). Cannot be used in conjunction with `conversation`.

  - `prompt: optional ResponsePrompt or null`

    Reference to a prompt template and its variables.
    [Learn more](/api/docs/guides/text?api-mode=responses#version-prompts-in-code).

    - `id: string`

      The unique identifier of the prompt template to use.

    - `variables: optional map[string or ResponseInputText or ResponseInputImage or ResponseInputFile] or null`

      Optional map of values to substitute in for variables in your
      prompt. The substitution values can either be strings, or other
      Response input types like images or files.

      - `string`

      - `ResponseInputText object { text, type, prompt_cache_breakpoint }`

        A text input to the model.

      - `ResponseInputImage object { detail, type, file_id, 2 more }`

        An image input to the model. Learn about [image inputs](/api/docs/guides/images-vision).

      - `ResponseInputFile object { type, detail, file_data, 4 more }`

        A file input to the model.

    - `version: optional string or null`

      Optional version of the prompt template.

  - `prompt_cache_diagnostics: optional CacheMiss { cache_missed_tokens, reason, type, comparison_reusable_tokens }  or CacheHit { type }  or ComparisonResponseNotFound { type }  or Unavailable { type }`

    Prompt cache diagnostics requested for this response.

    - `CacheMiss object { cache_missed_tokens, reason, type, comparison_reusable_tokens }`

      - `cache_missed_tokens: number`

        The estimated number of input tokens affected after the first detected divergence.

      - `reason: "model_changed" or "prompt_cache_key_changed" or "tools_changed" or 6 more`

        The reason prompt cache reuse did not occur.

        - `"model_changed"`

        - `"prompt_cache_key_changed"`

        - `"tools_changed"`

        - `"text_format_changed"`

        - `"reasoning_effort_changed"`

        - `"verbosity_changed"`

        - `"context_compacted"`

        - `"input_changed"`

        - `"service_tier_changed"`

      - `type: "cache_miss"`

        - `"cache_miss"`

      - `comparison_reusable_tokens: optional number`

        The raw token count of the reusable prefix in the compared response.

    - `CacheHit object { type }`

      - `type: "cache_hit"`

        - `"cache_hit"`

    - `ComparisonResponseNotFound object { type }`

      - `type: "comparison_response_not_found"`

        - `"comparison_response_not_found"`

    - `Unavailable object { type }`

      - `type: "unavailable"`

        - `"unavailable"`

  - `prompt_cache_key: optional string or null`

    Used by OpenAI to cache responses for similar requests to optimize your cache hit rates. Replaces the `user` field. [Learn more](/api/docs/guides/prompt-caching).

  - `prompt_cache_options: optional object { mode, ttl, comparison_response_id }`

    The prompt-caching options that were applied to the response. Supported for `gpt-5.6` and later models.

    - `mode: "implicit" or "explicit"`

      Whether implicit prompt-cache breakpoints were enabled.

      - `"implicit"`

      - `"explicit"`

    - `ttl: "30m"`

      The minimum lifetime applied to each cache breakpoint.

      - `"30m"`

    - `comparison_response_id: optional string or null`

      The response ID supplied as the prompt cache diagnostics comparison.

  - `prompt_cache_retention: optional "in_memory" or "24h" or null`

    Deprecated. Use `prompt_cache_options.ttl` instead.

    The retention policy for the prompt cache. Set to `24h` to enable extended prompt caching, which keeps cached prefixes active for longer, up to a maximum of 24 hours. [Learn more](/api/docs/guides/prompt-caching#prompt-cache-retention).
    This field expresses a maximum retention policy, while
    `prompt_cache_options.ttl` expresses a minimum cache lifetime. The two
    fields are independent and do not interact.
    For `gpt-5.5`, `gpt-5.5-pro`, and future models, only `24h` is supported.

    For older models that support both `in_memory` and `24h`, the default depends on your organization's data retention policy:

    - Organizations without ZDR enabled default to `24h`.
    - Organizations with ZDR enabled default to `in_memory` when `prompt_cache_retention` is not specified.

    - `"in_memory"`

    - `"24h"`

  - `reasoning: optional Reasoning or null`

    Configuration options for
    [reasoning models](/api/docs/guides/reasoning).

    - `context: optional "auto" or "current_turn" or "all_turns" or null`

      Controls which reasoning items are rendered back to the model on later turns.
      If omitted or set to `auto`, the model determines the context mode. The
      `gpt-5.6` model family defaults to `all_turns`; earlier models default to
      `current_turn`.

      When returned on a response, this is the effective reasoning context mode
      used for the response.

      - `"auto"`

      - `"current_turn"`

      - `"all_turns"`

    - `effort: optional ReasoningEffort or null`

      Constrains effort on reasoning for reasoning models. Currently supported
      values are `none`, `minimal`, `low`, `medium`, `high`, `xhigh`, and `max`.
      Reducing reasoning effort can result in faster responses and fewer tokens
      used on reasoning in a response. Not all reasoning models support every
      value. See the
      [reasoning guide](/api/docs/guides/reasoning)
      for model-specific support.

    - `generate_summary: optional "auto" or "concise" or "detailed" or null`

      **Deprecated:** use `summary` instead.

      A summary of the reasoning performed by the model. This can be
      useful for debugging and understanding the model's reasoning process.
      One of `auto`, `concise`, or `detailed`.

      - `"auto"`

      - `"concise"`

      - `"detailed"`

    - `mode: optional string or "standard" or "pro"`

      Controls the reasoning execution mode for the request.

      When returned on a response, this is the effective execution mode.

      - `string`

      - `"standard" or "pro"`

        Controls the reasoning execution mode for the request.

        When returned on a response, this is the effective execution mode.

        - `"standard"`

        - `"pro"`

    - `summary: optional "auto" or "concise" or "detailed" or null`

      A summary of the reasoning performed by the model. This can be
      useful for debugging and understanding the model's reasoning process.
      One of `auto`, `concise`, or `detailed`.

      `concise` is supported for `computer-use-preview` models and all reasoning models after `gpt-5`.

      - `"auto"`

      - `"concise"`

      - `"detailed"`

  - `safety_identifier: optional string or null`

    A stable identifier used to help detect users of your application that may be violating OpenAI's usage policies.
    The IDs should be a string that uniquely identifies each user, with a maximum length of 128 characters. We recommend hashing their username or email address, in order to avoid sending us any identifying information. [Learn more](/api/docs/guides/safety-best-practices#implement-safety-identifiers).

  - `service_tier: optional ServiceTier or null`

    Specifies the processing type used for serving the request.

    - If set to 'auto', then the request will be processed with the service tier configured in the Project settings. Unless otherwise configured, the Project will use 'default'.
    - If set to 'default', then the request will be processed with the standard pricing and performance for the selected model.
    - If set to '[flex](/api/docs/guides/flex-processing)', then the request will be processed with the Flex Processing service tier.
    - To opt-in to [Fast mode](/api/docs/guides/fast-mode) at the request level, include the `service_tier=fast` or `service_tier=priority` parameter for Responses or Chat Completions. The response will show `service_tier=priority` regardless of if you specify `service_tier=fast` or `priority` in your request.
    - If set to 'ultrafast', then the request will be processed with the access-controlled Ultrafast Processing service tier. This tier is currently available for `gpt-5.6-sol`; a response served through it will show `service_tier=ultrafast`.
    - When not set, the default behavior is 'auto'.

    When the `service_tier` parameter is set, the response body will include the `service_tier` value based on the processing mode actually used to serve the request. This response value may be different from the value set in the parameter.

    - `"auto"`

    - `"default"`

    - `"flex"`

    - `"scale"`

    - `"priority"`

    - `"fast"`

    - `"ultrafast"`

  - `status: optional ResponseStatus`

    The status of the response generation. One of `completed`, `failed`,
    `in_progress`, `cancelled`, `queued`, or `incomplete`.

    - `"completed"`

    - `"failed"`

    - `"in_progress"`

    - `"cancelled"`

    - `"queued"`

    - `"incomplete"`

  - `text: optional ResponseTextConfig`

    Configuration options for a text response from the model. Can be plain
    text or structured JSON data. Learn more:

    - [Text inputs and outputs](/api/docs/guides/text)
    - [Structured Outputs](/api/docs/guides/structured-outputs)

    - `format: optional ResponseFormatTextConfig`

      An object specifying the format that the model must output.

      Configuring `{ "type": "json_schema" }` enables Structured Outputs,
      which ensures the model will match your supplied JSON schema. Learn more in the
      [Structured Outputs guide](/api/docs/guides/structured-outputs).

      The default format is `{ "type": "text" }` with no additional options.

      **Not recommended for gpt-4o and newer models:**

      Setting to `{ "type": "json_object" }` enables the older JSON mode, which
      ensures the message the model generates is valid JSON. Using `json_schema`
      is preferred for models that support it.

      - `ResponseFormatText object { type }`

        Default response format. Used to generate text responses.

        - `type: "text"`

          The type of response format being defined. Always `text`.

          - `"text"`

      - `ResponseFormatTextJSONSchemaConfig object { name, schema, type, 2 more }`

        JSON Schema response format. Used to generate structured JSON responses.
        Learn more about [Structured Outputs](/api/docs/guides/structured-outputs).

        - `name: string`

          The name of the response format. Must be a-z, A-Z, 0-9, or contain
          underscores and dashes, with a maximum length of 64.

        - `schema: map[unknown]`

          The schema for the response format, described as a JSON Schema object.
          Learn how to build JSON schemas [here](https://json-schema.org/).

        - `type: "json_schema"`

          The type of response format being defined. Always `json_schema`.

          - `"json_schema"`

        - `description: optional string`

          A description of what the response format is for, used by the model to
          determine how to respond in the format.

        - `strict: optional boolean or null`

          Whether to enable strict schema adherence when generating the output.
          If set to true, the model will always follow the exact schema defined
          in the `schema` field. Only a subset of JSON Schema is supported when
          `strict` is `true`. To learn more, read the [Structured Outputs
          guide](/api/docs/guides/structured-outputs).

      - `ResponseFormatJSONObject object { type }`

        JSON object response format. An older method of generating JSON responses.
        Using `json_schema` is recommended for models that support it. Note that the
        model will not generate JSON without a system or user message instructing it
        to do so.

        - `type: "json_object"`

          The type of response format being defined. Always `json_object`.

          - `"json_object"`

    - `verbosity: optional "low" or "medium" or "high" or null`

      Constrains the verbosity of the model's response. Lower values will result in
      more concise responses, while higher values will result in more verbose responses.
      Currently supported values are `low`, `medium`, and `high`. The default is
      `medium`.

      - `"low"`

      - `"medium"`

      - `"high"`

  - `top_logprobs: optional number or null`

    An integer between 0 and 20 specifying the maximum number of most likely
    tokens to return at each token position, each with an associated log
    probability. In some cases, the number of returned tokens may be fewer than
    requested.

  - `truncation: optional "auto" or "disabled" or null`

    The truncation strategy to use for the model response.

    - `auto`: If the input to this Response exceeds
      the model's context window size, the model will truncate the
      response to fit the context window by dropping items from the beginning of the conversation.
    - `disabled` (default): If the input size will exceed the context window
      size for a model, the request will fail with a 400 error.

    - `"auto"`

    - `"disabled"`

  - `usage: optional ResponseUsage or null`

    Represents token usage details including input tokens, output tokens,
    a breakdown of output tokens, and the total tokens used.

    - `input_tokens: number`

      The number of input tokens.

    - `input_tokens_details: object { cache_write_tokens, cached_tokens }`

      A detailed breakdown of the input tokens.

      - `cache_write_tokens: number`

        The number of input tokens that were written to the cache.

      - `cached_tokens: number`

        The number of tokens that were retrieved from the cache.
        [More on prompt caching](/api/docs/guides/prompt-caching).

    - `output_tokens: number`

      The number of output tokens.

    - `output_tokens_details: object { reasoning_tokens }`

      A detailed breakdown of the output tokens.

      - `reasoning_tokens: number`

        The number of reasoning tokens.

    - `total_tokens: number`

      The total number of tokens used.

  - `user: optional string or null`

    This field is being replaced by `safety_identifier` and `prompt_cache_key`. Use `prompt_cache_key` instead to maintain caching optimizations.
    A stable identifier for your end-users.
    Used to boost cache hit rates by better bucketing similar requests and  to help OpenAI detect and prevent abuse. [Learn more](/api/docs/guides/safety-best-practices#implement-safety-identifiers).

### Example

```http
curl https://api.openai.com/v1/responses \
    -H 'Content-Type: application/json' \
    -H "Authorization: Bearer $OPENAI_API_KEY" \
    -d '"string"'
```

#### Response

```json
{
  "id": "resp_67ccd3a9da748190baa7f1570fe91ac604becb25c45c1d41",
  "object": "response",
  "access_programs": null,
  "created_at": 1741476777,
  "status": "completed",
  "completed_at": 1741476778,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "message",
      "id": "msg_67ccd3acc8d48190a77525dc6de64b4104becb25c45c1d41",
      "status": "completed",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "The image depicts a scenic landscape with a wooden boardwalk or pathway leading through lush, green grass under a blue sky with some clouds. The setting suggests a peaceful natural area, possibly a park or nature reserve. There are trees and shrubs in the background.",
          "annotations": [],
          "logprobs": []
        }
      ]
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null,
    "context": null
  },
  "store": true,
  "temperature": 1,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [],
  "top_p": 1,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 328,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 52,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 380
  },
  "user": null,
  "metadata": {},
  "conversation": {
    "id": "id"
  },
  "moderation": {
    "input": {
      "categories": {
        "foo": true
      },
      "category_applied_input_types": {
        "foo": [
          "text"
        ]
      },
      "category_scores": {
        "foo": 0
      },
      "flagged": true,
      "model": "model",
      "type": "moderation_result"
    },
    "output": {
      "categories": {
        "foo": true
      },
      "category_applied_input_types": {
        "foo": [
          "text"
        ]
      },
      "category_scores": {
        "foo": 0
      },
      "flagged": true,
      "model": "model",
      "type": "moderation_result"
    }
  },
  "output_text": "output_text",
  "prompt_cache_diagnostics": {
    "cache_missed_tokens": 0,
    "reason": "model_changed",
    "type": "cache_miss",
    "comparison_reusable_tokens": 0
  },
  "prompt_cache_options": {
    "mode": "implicit",
    "ttl": "30m",
    "comparison_response_id": "comparison_response_id"
  },
  "service_tier": "auto"
}
```

### File input

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "input": [
      {
        "role": "user",
        "content": [
          {"type": "input_text", "text": "what is in this file?"},
          {
            "type": "input_file",
            "file_url": "https://www.berkshirehathaway.com/letters/2024ltr.pdf",
            "detail": "auto"
          }
        ]
      }
    ]
  }'
```

#### Response

```json
{
  "id": "resp_686eef60237881a2bd1180bb8b13de430e34c516d176ff86",
  "object": "response",
  "access_programs": null,
  "created_at": 1752100704,
  "status": "completed",
  "completed_at": 1752100705,
  "background": false,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "max_tool_calls": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "id": "msg_686eef60d3e081a29283bdcbc4322fd90e34c516d176ff86",
      "type": "message",
      "status": "completed",
      "content": [
        {
          "type": "output_text",
          "annotations": [],
          "logprobs": [],
          "text": "The file seems to contain excerpts from a letter to the shareholders of Berkshire Hathaway Inc., likely written by Warren Buffett. It covers several topics:\n\n1. **Communication Philosophy**: Buffett emphasizes the importance of transparency and candidness in reporting mistakes and successes to shareholders.\n\n2. **Mistakes and Learnings**: The letter acknowledges past mistakes in business assessments and management hires, highlighting the importance of correcting errors promptly.\n\n3. **CEO Succession**: Mention of Greg Abel stepping in as the new CEO and continuing the tradition of honest communication.\n\n4. **Pete Liegl Story**: A detailed account of acquiring Forest River and the relationship with its founder, highlighting trust and effective business decisions.\n\n5. **2024 Performance**: Overview of business performance, particularly in insurance and investment activities, with a focus on GEICO's improvement.\n\n6. **Tax Contributions**: Discussion of significant tax payments to the U.S. Treasury, credited to shareholders' reinvestments.\n\n7. **Investment Strategy**: A breakdown of Berkshire\u2019s investments in both controlled subsidiaries and marketable equities, along with a focus on long-term holding strategies.\n\n8. **American Capitalism**: Reflections on America\u2019s economic development and Berkshire\u2019s role within it.\n\n9. **Property-Casualty Insurance**: Insights into the P/C insurance business model and its challenges and benefits.\n\n10. **Japanese Investments**: Information about Berkshire\u2019s investments in Japanese companies and future plans.\n\n11. **Annual Meeting**: Details about the upcoming annual gathering in Omaha, including schedule changes and new book releases.\n\n12. **Personal Anecdotes**: Light-hearted stories about family and interactions, conveying Buffett's personable approach.\n\n13. **Financial Performance Data**: Tables comparing Berkshire\u2019s annual performance to the S&P 500, showing impressive long-term gains.\n\nOverall, the letter reinforces Berkshire Hathaway's commitment to transparency, investment in both its businesses and the wider economy, and emphasizes strong leadership and prudent financial management."
        }
      ],
      "role": "assistant"
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null
  },
  "service_tier": "default",
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [],
  "top_logprobs": 0,
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 8438,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 398,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 8836
  },
  "user": null,
  "metadata": {}
}
```

### File search

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "tools": [{
      "type": "file_search",
      "vector_store_ids": ["vs_1234567890"],
      "max_num_results": 20
    }],
    "input": "What are the attributes of an ancient brown dragon?"
  }'
```

#### Response

```json
{
  "id": "resp_67ccf4c55fc48190b71bd0463ad3306d09504fb6872380d7",
  "object": "response",
  "access_programs": null,
  "created_at": 1741485253,
  "status": "completed",
  "completed_at": 1741485254,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "file_search_call",
      "id": "fs_67ccf4c63cd08190887ef6464ba5681609504fb6872380d7",
      "status": "completed",
      "queries": [
        "attributes of an ancient brown dragon"
      ],
      "results": null
    },
    {
      "type": "message",
      "id": "msg_67ccf4c93e5c81909d595b369351a9d309504fb6872380d7",
      "status": "completed",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "The attributes of an ancient brown dragon include...",
          "annotations": [
            {
              "type": "file_citation",
              "index": 320,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 576,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 815,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 815,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 1030,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 1030,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 1156,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            },
            {
              "type": "file_citation",
              "index": 1225,
              "file_id": "file-4wDz5b167pAf72nx1h9eiN",
              "filename": "dragons.pdf"
            }
          ],
          "logprobs": []
        }
      ]
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null
  },
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [
    {
      "type": "file_search",
      "filters": null,
      "max_num_results": 20,
      "ranking_options": {
        "ranker": "auto",
        "score_threshold": 0.0
      },
      "vector_store_ids": [
        "vs_1234567890"
      ]
    }
  ],
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 18307,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 348,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 18655
  },
  "user": null,
  "metadata": {}
}
```

### Functions

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "input": "What is the weather like in Boston today?",
    "tools": [
      {
        "type": "function",
        "name": "get_current_weather",
        "description": "Get the current weather in a given location",
        "parameters": {
          "type": "object",
          "properties": {
            "location": {
              "type": "string",
              "description": "The city and state, e.g. San Francisco, CA"
            },
            "unit": {
              "type": "string",
              "enum": ["celsius", "fahrenheit"]
            }
          },
          "required": ["location", "unit"]
        }
      }
    ],
    "tool_choice": "auto"
  }'
```

#### Response

```json
{
  "id": "resp_67ca09c5efe0819096d0511c92b8c890096610f474011cc0",
  "object": "response",
  "access_programs": null,
  "created_at": 1741294021,
  "status": "completed",
  "completed_at": 1741294022,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "function_call",
      "id": "fc_67ca09c6bedc8190a7abfec07b1a1332096610f474011cc0",
      "call_id": "call_unLAR8MvFNptuiZK6K6HCy5k",
      "name": "get_current_weather",
      "arguments": "{\"location\":\"Boston, MA\",\"unit\":\"celsius\"}",
      "status": "completed"
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null
  },
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [
    {
      "type": "function",
      "description": "Get the current weather in a given location",
      "name": "get_current_weather",
      "parameters": {
        "type": "object",
        "properties": {
          "location": {
            "type": "string",
            "description": "The city and state, e.g. San Francisco, CA"
          },
          "unit": {
            "type": "string",
            "enum": [
              "celsius",
              "fahrenheit"
            ]
          }
        },
        "required": [
          "location",
          "unit"
        ]
      },
      "strict": true
    }
  ],
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 291,
    "output_tokens": 23,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 314,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    }
  },
  "user": null,
  "metadata": {}
}
```

### Image input

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "input": [
      {
        "role": "user",
        "content": [
          {"type": "input_text", "text": "what is in this image?"},
          {
            "type": "input_image",
            "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg"
          }
        ]
      }
    ]
  }'
```

#### Response

```json
{
  "id": "resp_67ccd3a9da748190baa7f1570fe91ac604becb25c45c1d41",
  "object": "response",
  "access_programs": null,
  "created_at": 1741476777,
  "status": "completed",
  "completed_at": 1741476778,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "message",
      "id": "msg_67ccd3acc8d48190a77525dc6de64b4104becb25c45c1d41",
      "status": "completed",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "The image depicts a scenic landscape with a wooden boardwalk or pathway leading through lush, green grass under a blue sky with some clouds. The setting suggests a peaceful natural area, possibly a park or nature reserve. There are trees and shrubs in the background.",
          "annotations": [],
          "logprobs": []
        }
      ]
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null
  },
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [],
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 328,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 52,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 380
  },
  "user": null,
  "metadata": {}
}
```

### Reasoning

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "input": "How much wood would a woodchuck chuck?",
    "reasoning": {
      "effort": "high"
    }
  }'
```

#### Response

```json
{
  "id": "resp_67ccd7eca01881908ff0b5146584e408072912b2993db808",
  "object": "response",
  "access_programs": null,
  "created_at": 1741477868,
  "status": "completed",
  "completed_at": 1741477869,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "message",
      "id": "msg_67ccd7f7b5848190a6f3e95d809f6b44072912b2993db808",
      "status": "completed",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "The classic tongue twister...",
          "annotations": [],
          "logprobs": []
        }
      ]
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": "high",
    "summary": null
  },
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [],
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 81,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 1035,
    "output_tokens_details": {
      "reasoning_tokens": 832
    },
    "total_tokens": 1116
  },
  "user": null,
  "metadata": {}
}
```

### Streaming

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "instructions": "You are a helpful assistant.",
    "input": "Hello!",
    "stream": true
  }'
```

#### Response

```json
event: response.created
data: {"type":"response.created","response":{"id":"resp_67c9fdcecf488190bdd9a0409de3a1ec07b8b0ad4e5eb654","object":"response","access_programs":null,"created_at":1741290958,"status":"in_progress","error":null,"incomplete_details":null,"instructions":"You are a helpful assistant.","max_output_tokens":null,"model":"gpt-6-astra","output":[],"parallel_tool_calls":true,"previous_response_id":null,"reasoning":{"effort":null,"summary":null},"store":true,"temperature":1.0,"text":{"format":{"type":"text"}},"tool_choice":"auto","tools":[],"top_p":1.0,"truncation":"disabled","usage":null,"user":null,"metadata":{}},"sequence_number":0}

event: response.in_progress
data: {"type":"response.in_progress","response":{"id":"resp_67c9fdcecf488190bdd9a0409de3a1ec07b8b0ad4e5eb654","object":"response","access_programs":null,"created_at":1741290958,"status":"in_progress","error":null,"incomplete_details":null,"instructions":"You are a helpful assistant.","max_output_tokens":null,"model":"gpt-6-astra","output":[],"parallel_tool_calls":true,"previous_response_id":null,"reasoning":{"effort":null,"summary":null},"store":true,"temperature":1.0,"text":{"format":{"type":"text"}},"tool_choice":"auto","tools":[],"top_p":1.0,"truncation":"disabled","usage":null,"user":null,"metadata":{}},"sequence_number":1}

event: response.output_item.added
data: {"type":"response.output_item.added","output_index":0,"item":{"id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","type":"message","status":"in_progress","role":"assistant","content":[]},"sequence_number":2}

event: response.content_part.added
data: {"type":"response.content_part.added","item_id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","output_index":0,"content_index":0,"part":{"type":"output_text","text":"","annotations":[],"logprobs":[]},"sequence_number":3}

event: response.output_text.delta
data: {"type":"response.output_text.delta","item_id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","output_index":0,"content_index":0,"delta":"Hi","sequence_number":4,"logprobs":[]}

: Intermediate response events omitted.

event: response.output_text.done
data: {"type":"response.output_text.done","item_id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","output_index":0,"content_index":0,"text":"Hi there! How can I assist you today?","sequence_number":10,"logprobs":[]}

event: response.content_part.done
data: {"type":"response.content_part.done","item_id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","output_index":0,"content_index":0,"part":{"type":"output_text","text":"Hi there! How can I assist you today?","annotations":[],"logprobs":[]},"sequence_number":11}

event: response.output_item.done
data: {"type":"response.output_item.done","output_index":0,"item":{"id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","type":"message","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Hi there! How can I assist you today?","annotations":[],"logprobs":[]}]},"sequence_number":12}

event: response.completed
data: {"type":"response.completed","response":{"id":"resp_67c9fdcecf488190bdd9a0409de3a1ec07b8b0ad4e5eb654","object":"response","access_programs":null,"created_at":1741290958,"status":"completed","error":null,"incomplete_details":null,"instructions":"You are a helpful assistant.","max_output_tokens":null,"model":"gpt-6-astra","output":[{"id":"msg_67c9fdcf37fc8190ba82116e33fb28c507b8b0ad4e5eb654","type":"message","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Hi there! How can I assist you today?","annotations":[],"logprobs":[]}]}],"parallel_tool_calls":true,"previous_response_id":null,"reasoning":{"effort":null,"summary":null},"store":true,"temperature":1.0,"text":{"format":{"type":"text"}},"tool_choice":"auto","tools":[],"top_p":1.0,"truncation":"disabled","usage":{"input_tokens":37,"output_tokens":11,"output_tokens_details":{"reasoning_tokens":0},"total_tokens":48,"input_tokens_details":{"cached_tokens":0,"cache_write_tokens":0}},"user":null,"metadata":{}},"sequence_number":13}

```

### Text input

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "input": "Tell me a three sentence bedtime story about a unicorn."
  }'
```

#### Response

```json
{
  "id": "resp_67ccd2bed1ec8190b14f964abc0542670bb6a6b452d3795b",
  "object": "response",
  "access_programs": null,
  "created_at": 1741476542,
  "status": "completed",
  "completed_at": 1741476543,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "message",
      "id": "msg_67ccd2bf17f0819081ff3bb2cf6508e60bb6a6b452d3795b",
      "status": "completed",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "In a peaceful grove beneath a silver moon, a unicorn named Lumina discovered a hidden pool that reflected the stars. As she dipped her horn into the water, the pool began to shimmer, revealing a pathway to a magical realm of endless night skies. Filled with wonder, Lumina whispered a wish for all who dream to find their own hidden magic, and as she glanced back, her hoofprints sparkled like stardust.",
          "annotations": [],
          "logprobs": []
        }
      ]
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null
  },
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [],
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 36,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 87,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 123
  },
  "user": null,
  "metadata": {}
}
```

### Web search

```http
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-6-astra",
    "tools": [{ "type": "web_search_preview" }],
    "input": "What was a positive news story from today?"
  }'
```

#### Response

```json
{
  "id": "resp_67ccf18ef5fc8190b16dbee19bc54e5f087bb177ab789d5c",
  "object": "response",
  "access_programs": null,
  "created_at": 1741484430,
  "status": "completed",
  "completed_at": 1741484431,
  "error": null,
  "incomplete_details": null,
  "instructions": null,
  "max_output_tokens": null,
  "model": "gpt-6-astra",
  "output": [
    {
      "type": "web_search_call",
      "id": "ws_67ccf18f64008190a39b619f4c8455ef087bb177ab789d5c",
      "status": "completed"
    },
    {
      "type": "message",
      "id": "msg_67ccf190ca3881909d433c50b1f6357e087bb177ab789d5c",
      "status": "completed",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "As of today, March 9, 2025, one notable positive news story...",
          "annotations": [
            {
              "type": "url_citation",
              "start_index": 442,
              "end_index": 557,
              "url": "https://.../?utm_source=chatgpt.com",
              "title": "..."
            },
            {
              "type": "url_citation",
              "start_index": 962,
              "end_index": 1077,
              "url": "https://.../?utm_source=chatgpt.com",
              "title": "..."
            },
            {
              "type": "url_citation",
              "start_index": 1336,
              "end_index": 1451,
              "url": "https://.../?utm_source=chatgpt.com",
              "title": "..."
            }
          ],
          "logprobs": []
        }
      ]
    }
  ],
  "parallel_tool_calls": true,
  "previous_response_id": null,
  "reasoning": {
    "effort": null,
    "summary": null
  },
  "store": true,
  "temperature": 1.0,
  "text": {
    "format": {
      "type": "text"
    }
  },
  "tool_choice": "auto",
  "tools": [
    {
      "type": "web_search_preview",
      "domains": [],
      "search_context_size": "medium",
      "user_location": {
        "type": "approximate",
        "city": null,
        "country": "US",
        "region": null,
        "timezone": null
      }
    }
  ],
  "top_p": 1.0,
  "truncation": "disabled",
  "usage": {
    "input_tokens": 328,
    "input_tokens_details": {
      "cached_tokens": 0,
      "cache_write_tokens": 0
    },
    "output_tokens": 356,
    "output_tokens_details": {
      "reasoning_tokens": 0
    },
    "total_tokens": 684
  },
  "user": null,
  "metadata": {}
}
```
