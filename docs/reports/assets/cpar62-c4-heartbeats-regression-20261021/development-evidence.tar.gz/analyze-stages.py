from pathlib import Path
import re,json,hashlib,sys
out=Path(__file__).parent
for name in sys.argv[1:]:
 p=out/(name+'.log');lines=p.read_text().splitlines();data=[];current={}
 for i,line in enumerate(lines,1):
  match=re.search(r'CPAR62_CASE (Responses|Messages) (\w+) idle_ms=(\d+) total_ms=(\d+)',line)
  if match:
   proto=match[1];current[proto]={'protocol':proto,'case':match[2],'idle_ms':int(match[3]),'total_ms':int(match[4]),'case_line':i,'stages':[]};data.append(current[proto])
  if any(tag in line for tag in ['CPAR62_STAGE ', 'CPAR62_PEER ', 'CPAR62_DECODE ']):
   proto='Messages' if '::messages::' in line else 'Responses';m=re.search(r'tv_sec: (\d+), tv_nsec: (\d+).*stage=(\S+)',line)
   if m and proto in current:current[proto]['stages'].append({'line':i,'time_ns':int(m[1])*10**9+int(m[2]),'stage':m[3]})
 for row in data:
  stages={s['stage']:s['time_ns'] for s in row['stages']}
  for label,a,b in [('client_build_ms','client_cache_miss_build_begin','client_build_end'),('execute_to_headers_ms','execute_begin','upstream_response_headers'),('send_to_public_headers_ms','send_enter_total_deadline_established','public_headers_formed'),('send_to_body_terminal_ms','send_enter_total_deadline_established','transport_body_end_or_error')]:
   if a in stages and b in stages:row[label]=(stages[b]-stages[a])/1e6
  if row['case']=='Heartbeats':print(name,row['protocol'],row.get('client_build_ms'),row.get('execute_to_headers_ms'),[s['stage'] for s in row['stages'] if 'exhausted' in s['stage']])
 record={'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':data,'results':[{'line':i+1,'text':line} for i,line in enumerate(lines) if line.startswith('test result:') or 'CPAR62_TIMEOUT_FAILURE' in line or 'Error: "truncated SSE"' in line]}
 (out/(name+'-stages.json')).write_text(json.dumps(record,indent=2)+'\n')
