# Check run log

- Mode: `full`
- Started: `2026-10-20T17:07:58Z`
- Host: `Darwin 27.0.0 arm64`

| Step | Duration seconds | Result |
|---|---:|---|
| Shell syntax | 0 | PASS |
| CI workflow | 1 | PASS |
| Release artifact workflow | 0 | PASS |
| CI change classifier | 1 | PASS |
| Plan state | 0 | PASS |
| Plan state guard | 1 | PASS |
| Canary thresholds | 0 | PASS |
| Caddy split | 0 | PASS |
| Caddy split guard | 2 | PASS |
| Management SPA dependencies | 0 | PASS |
| Benchmark baseline comparator | 1 | PASS |
| Soak runner argument guard | 67 | PASS |
| Soak receipt checker | 1 | PASS |
| Quality installer cache behavior | 1 | PASS |
| Release artifact verifier | 5 | PASS |
| P12 systemd unit | 1 | PASS |
| P12 OpenAI differential graph | 0 | PASS |
| P12 OpenAI differential classifier | 0 | PASS |
| P12 OpenClaw migration dry-run | 1 | PASS |
| P12 G1 production graph | 0 | PASS |
| P12 G1 live harness | 0 | PASS |
| P12 G1 Chat SSE classifier | 0 | PASS |
| P12 G1 Responses JSON classifier | 0 | PASS |
| P12 G1 Messages SSE classifier | 0 | PASS |
| P12 grok2api memory export | 0 | PASS |
| P12 Autoreg Console memory export | 0 | PASS |
| P12 production observer | 0 | PASS |
| P12 Grok CPAR curl E2E harness | 0 | PASS |
| CPAR new-build acceptance oracle | 6 | PASS |
| Management SPA | 3 | PASS |
| Rust format | 2 | PASS |
| Clippy | 48 | PASS |
| Rust tests | 277 | PASS |
| P12 serve envelope | 25 | PASS |
| Agent multi-turn and stream regression | 8 | PASS |
| Source policy | 0 | PASS |
| Secret scanner test | 1 | PASS |
| Crate boundaries | 1 | PASS |
| Document links | 0 | PASS |
| Contract tests | 0 | PASS |
| Tracked secret scan | 75 | PASS |
| Git whitespace | 0 | PASS |
| Quality tool versions | 1 | PASS |
| Dependency policy | 4 | PASS |
| RustSec audit | 3 | PASS |

Completed: `2026-10-20T17:16:54Z`
