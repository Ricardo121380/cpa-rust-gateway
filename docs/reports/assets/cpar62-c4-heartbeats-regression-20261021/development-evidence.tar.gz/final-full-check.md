# Check run log

- Mode: `full`
- Started: `2026-10-20T16:56:25Z`
- Host: `Darwin 27.0.0 arm64`

| Step | Duration seconds | Result |
|---|---:|---|
| Shell syntax | 0 | PASS |
| CI workflow | 0 | PASS |
| Release artifact workflow | 1 | PASS |
| CI change classifier | 0 | PASS |
| Plan state | 1 | PASS |
| Plan state guard | 0 | PASS |
| Canary thresholds | 1 | PASS |
| Caddy split | 0 | PASS |
| Caddy split guard | 1 | PASS |
| Management SPA dependencies | 1 | PASS |
| Benchmark baseline comparator | 1 | PASS |
| Soak runner argument guard | 69 | PASS |
| Soak receipt checker | 1 | PASS |
| Quality installer cache behavior | 1 | PASS |
| Release artifact verifier | 5 | PASS |
| P12 systemd unit | 0 | PASS |
| P12 OpenAI differential graph | 0 | PASS |
| P12 OpenAI differential classifier | 0 | PASS |
| P12 OpenClaw migration dry-run | 1 | PASS |
| P12 G1 production graph | 0 | PASS |
| P12 G1 live harness | 1 | PASS |
| P12 G1 Chat SSE classifier | 0 | PASS |
| P12 G1 Responses JSON classifier | 0 | PASS |
| P12 G1 Messages SSE classifier | 0 | PASS |
| P12 grok2api memory export | 0 | PASS |
| P12 Autoreg Console memory export | 0 | PASS |
| P12 production observer | 0 | PASS |
| P12 Grok CPAR curl E2E harness | 0 | PASS |
| CPAR new-build acceptance oracle | 6 | PASS |
| Management SPA | 3 | PASS |
| Rust format | 2 | PASS |
| Clippy | 49 | PASS |
| Rust tests | 178 | FAIL (101) |
