from pathlib import Path
import json,tarfile,hashlib,gzip,shutil,stat,io,subprocess,fnmatch
out=Path(__file__).parent
root=Path('/Volumes/Asgard/Agentprojects/CPA-Rust/worktrees/cpar62-client-metadata-20261020')
assets=root/'docs/reports/assets/cpar62-c4-heartbeats-regression-20261021'
assets.mkdir(parents=True,exist_ok=True)
allow=json.loads((out/'package-allowlist.json').read_text())
names=[]
for key,values in allow.items():
 if key=='runs':
  for n in values:names.extend([n+'.json',n+'.log'])
 else:names.extend(values)
names.extend(['package-allowlist.json','package.py','review-final.md'])
names=sorted(set(names))
for n in names:
 p=out/n
 assert p.is_file() and not p.is_symlink(),n
 assert p.name==n,n
prefix=(root/'scripts/secret-scan.sh').read_text().split('\nis_forbidden_path()')[0]
regex=subprocess.check_output(['bash','-c',prefix+'\nprintf \'%s\' "$secret_regex"'],cwd=root,text=True)
legacy=json.loads((root/'docs/reports/assets/cpar62-client-metadata-20261020/artifact-scan-exceptions.json').read_text())[0]
reviewed=json.loads((out/'artifact-scan-reviewed-line.json').read_text())
for key in ['filename_sha256','tracked_blob','tracked_file_sha256']:assert reviewed[key]==legacy[key]
allowed_line_hashes={legacy['line_sha256'],reviewed['line_sha256']}
exceptions=[];findings=[]
def scan(name,data):
 forbidden=['.env','.env.*','*.pem','*.key','*.p12','*.pfx','*.jks','*.keystore','*.oauth.json','*.sqlite','*.sqlite3','*.sqlite-shm','*.sqlite-wal']
 if any(fnmatch.fnmatch(Path(name).name,p) for p in forbidden):raise RuntimeError('forbidden path '+name)
 if any(p in ['auths','credentials','secrets','deploy-secrets'] for p in Path(name).parts):raise RuntimeError('forbidden path '+name)
 result=subprocess.run(['rg','--pcre2','-a','-n','--',regex],input=data,capture_output=True)
 assert result.returncode in [0,1],name
 if result.returncode==1:return
 for row in result.stdout.splitlines():
  number,line=row.split(b':',1);digest=hashlib.sha256(line).hexdigest()
  if digest in allowed_line_hashes:
   record=json.loads(b'{'+line.strip().rstrip(b',')+b'}');rel=record['path']
   assert hashlib.sha256(rel.encode()).hexdigest()==legacy['filename_sha256']
   blob=subprocess.check_output(['git','rev-parse','HEAD:'+rel],cwd=root,text=True).strip()
   contents=subprocess.check_output(['git','show','HEAD:'+rel],cwd=root)
   assert blob==legacy['tracked_blob'] and hashlib.sha256(contents).hexdigest()==legacy['tracked_file_sha256']
   exceptions.append({'artifact':name,'line':int(number),'line_sha256':digest,'tracked_blob':blob,'tracked_file_sha256':legacy['tracked_file_sha256'],'reason':legacy['reason']})
  else:findings.append({'artifact':name,'line':int(number),'line_sha256':digest})
manifest=[]
archive=assets/'development-evidence.tar.gz'
with tarfile.open(archive,'w:gz',dereference=False) as tar:
 for name in names:
  p=out/name;data=p.read_bytes();scan(name,data);tar.add(p,arcname=name,recursive=False)
  manifest.append({'path':name,'bytes':len(data),'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':hashlib.sha256(data).hexdigest()})
assert not findings, findings
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(manifest)
 for member,expected in zip(tar.getmembers(),manifest):
  assert member.isfile() and member.name==expected['path']
  data=tar.extractfile(member).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'] and oct(member.mode)==expected['mode']
top=['c4-fixture-comparison.json','candidate-final.json','source-binding.json','final-full-environment.json','validation-overlay-final-binding.json','preservation-final.json','owned-code-staging.json','owned-fixture-staging.json','comparison.json','diagnostic-stress-1-stages.json','diagnostic-stress-2-stages.json','first-event-fresh-binding.json','final-full-v2-check.md','review-final.md']
for n in top:shutil.copy2(out/n,assets/n)
for n in ['source-inputs-final-before.json','source-inputs-final-after.json','final-full-v2.log']:
 (assets/(n+'.gz')).write_bytes(gzip.compress((out/n).read_bytes(),mtime=0))
shutil.copy2(out/'final-full-check.md',assets/'first-full-check.md')
(assets/'first-full.log.gz').write_bytes(gzip.compress((out/'final-full.log').read_bytes(),mtime=0))
(assets/'archive-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
(assets/'artifact-scan-exceptions.json').write_text(json.dumps(exceptions,indent=2)+'\n')
summary={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_members':len(manifest),'members_verified':True,'forbidden_paths':0,'unreviewed_secret_matches':0,'exact_line_exceptions':len(exceptions),'exception_basis':'same reviewed historical tracked task filename, unchanged line and Git blob; no regex change','secret_regex_sha256':hashlib.sha256(regex.encode()).hexdigest(),'excluded':['executables','target directories','databases and keys','inherited-inputs.tar.gz','inherited-diff.txt','raw GitHub comments and client configuration']}
(assets/'artifact-scan.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
