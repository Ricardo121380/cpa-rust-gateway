import os,sys,json,time,subprocess,signal,datetime
from pathlib import Path
out=Path(__file__).parent
name,cwd,bound,*cmd=sys.argv[1:]
record={'name':name,'cwd':cwd,'command':cmd,'limit_seconds':int(bound),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:os.environ.get(k) for k in ['CARGO_TARGET_DIR','CHECK_REPORT_PATH','RUST_TEST_THREADS','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_PROFILE_TEST_OPT_LEVEL','RUST_LOG','CPAR62_STAGE_TRACE']},'cpu_count':os.cpu_count()}
(out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (out/(name+'.log')).open('xb') as log:
 p=subprocess.Popen(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 record['pid']=p.pid
 try: record['returncode']=p.wait(timeout=int(bound))
 except subprocess.TimeoutExpired:
  record['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
record['elapsed_seconds']=time.monotonic()-start
(out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record),flush=True)
sys.exit(record.get('returncode',124))
