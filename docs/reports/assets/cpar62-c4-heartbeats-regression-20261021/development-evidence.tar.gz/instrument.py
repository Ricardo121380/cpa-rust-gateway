from pathlib import Path
root=Path('/Volumes/Asgard/Agentprojects/CPA-Rust/worktrees/validation/cpar62-c4-diagnostic-20261021')
p=root/'crates/gateway-upstream/src/upstream_client.rs'; s=p.read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace('impl UpstreamClientPool {','''fn cpar62_stage(stage: &str) {
    let thread = std::thread::current();
    let name = thread.name().unwrap_or("unnamed");
    if std::env::var_os("CPAR62_STAGE_TRACE").is_some()
        && (name.contains("eof_idle_and_total") || name.contains("cpar62_cold"))
    {
        eprintln!("CPAR62_STAGE thread={name} tick={:?} stage={stage}", std::time::Instant::now());
    }
}

impl UpstreamClientPool {''')
replace('''        let client = self.client_for(request.target(), profile)?;
        let first_byte_budget = remaining_budget(deadline)?.min(profile.timeouts().ttfb());''','''        cpar62_stage("send_enter_total_deadline_established");
        let client = self.client_for(request.target(), profile)?;
        let budget = remaining_budget(deadline);
        if budget.is_err() { cpar62_stage("total_exhausted_before_execute"); }
        let first_byte_budget = budget?.min(profile.timeouts().ttfb());
        cpar62_stage("execute_begin");''')
replace('''                    Err(_) | Ok(Err(_)) => return Err(egress_unavailable_error()),
                    Ok(Ok(response)) => response,''','''                    Err(_) => { cpar62_stage("execute_elapsed"); return Err(egress_unavailable_error()); }
                    Ok(Err(error)) => {
                        cpar62_stage(if error.is_connect() { "execute_connect_error" } else if error.is_timeout() { "execute_timeout_error" } else { "execute_other_error" });
                        return Err(egress_unavailable_error());
                    }
                    Ok(Ok(response)) => { cpar62_stage("upstream_response_headers"); response },''') if False else None
# The Standard and Chrome matches have identical text: instrument Standard only.
a='''                    Err(_) | Ok(Err(_)) => return Err(egress_unavailable_error()),
                    Ok(Ok(response)) => response,'''
assert s.count(a)==2
s=s.replace(a,'''                    Err(_) => { cpar62_stage("execute_elapsed"); return Err(egress_unavailable_error()); }
                    Ok(Err(error)) => {
                        cpar62_stage(if error.is_connect() { "execute_connect_error" } else if error.is_timeout() { "execute_timeout_error" } else { "execute_other_error" });
                        return Err(egress_unavailable_error());
                    }
                    Ok(Ok(response)) => { cpar62_stage("upstream_response_headers"); response },''',1)
replace('''        if let Some(client) = self.clients.get(&key) {
            return Ok(client);
        }

        let built''','''        if let Some(client) = self.clients.get(&key) {
            cpar62_stage("client_cache_hit");
            return Ok(client);
        }
        cpar62_stage("client_cache_miss_build_begin");
        let built''')
replace('''        Ok(self.clients.get_with(key, || built))''','''        cpar62_stage("client_build_end");
        Ok(self.clients.get_with(key, || built))''')
p.write_text(s)
p=root/'apps/gateway/src/runtime/batch_c/grok/standard_responses/lifecycle.rs';s=p.read_text()
replace('''struct SocketPeer {''','''fn cpar62_peer_stage(stage: &str) {
    let thread = std::thread::current();
    let name = thread.name().unwrap_or("unnamed");
    if std::env::var_os("CPAR62_STAGE_TRACE").is_some() && name.contains("eof_idle_and_total") {
        eprintln!("CPAR62_PEER thread={name} tick={:?} stage={stage}", std::time::Instant::now());
    }
}

struct SocketPeer {''')
replace('''                let (mut socket, _) = listener.accept().await?;
                let request = read_request(&mut socket).await?;''','''                let (mut socket, _) = listener.accept().await?;
                cpar62_peer_stage("accept");
                let request = read_request(&mut socket).await?;
                cpar62_peer_stage("complete_request_read");''')
replace('''                socket.write_all(head.as_bytes()).await?;
                socket.write_all(body.as_bytes()).await?;''','''                socket.write_all(head.as_bytes()).await?;
                cpar62_peer_stage("headers_written");
                socket.write_all(body.as_bytes()).await?;
                cpar62_peer_stage("first_sse_segment_written");''')
replace('''        bytes.extend_from_slice(&chunk[..n]);''','''        cpar62_peer_stage("request_bytes_arrived");
        bytes.extend_from_slice(&chunk[..n]);''')
replace('''        Box::pin(async move { self.0.next_chunk().await.map(|v| v.map(|b| b.to_vec())) })''','''        Box::pin(async move {
            let result = self.0.next_chunk().await.map(|v| v.map(|b| b.to_vec()));
            cpar62_peer_stage(if result.as_ref().is_ok_and(|v| v.is_some()) { "transport_body_chunk" } else { "transport_body_end_or_error" });
            result
        })''')
replace('''            let response = self.pool.send(handoff, &self.profile).await?;''','''            cpar62_peer_stage("pool_send_enter");
            let response = self.pool.send(handoff, &self.profile).await?;
            cpar62_peer_stage("pool_send_headers_returned");''')
replace('''        let status = reply.status();
        let bytes''','''        cpar62_peer_stage("public_headers_formed");
        let status = reply.status();
        let bytes''')
replace('''        let peer = SocketPeer::start(partial_wire(), end)?;''','''        eprintln!("CPAR62_CASE Responses {end:?} idle_ms={} total_ms={}",idle.as_millis(),total.as_millis());
        let peer = SocketPeer::start(partial_wire(), end)?;''')
p.write_text(s)
p=root/'apps/gateway/src/runtime/batch_c/grok/standard_responses/lifecycle/messages/cancellation.rs';s=p.read_text()
replace('''        let peer = SocketPeer::start(partial(), end)?;''','''        eprintln!("CPAR62_CASE Messages {end:?} idle_ms={} total_ms={}",idle.as_millis(),total.as_millis());
        let peer = SocketPeer::start(partial(), end)?;''')
replace('''        let id = reply
            .headers()''','''        cpar62_peer_stage("messages_public_headers_formed");
        eprintln!("CPAR62_MESSAGES_STATUS {}", reply.status());
        let id = reply
            .headers()''')
p.write_text(s)
