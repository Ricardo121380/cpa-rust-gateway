from pathlib import Path
import json,hashlib,stat,subprocess,os,sys
root=Path(sys.argv[1]);destination=Path(sys.argv[2]);out=Path(__file__).parent
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');inherit=[r['path'] for r in json.loads((out/'inherited-inputs.json').read_text())];paths=sorted(set(p for p in tracked+inherit if p));rows=[]
for rel in paths:
 p=root/rel;s=p.lstat();rows.append({'path':rel,'mode':oct(stat.S_IMODE(s.st_mode)),'symlink':os.readlink(p) if p.is_symlink() else None,'bytes':s.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
record={'root':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True),'records':rows}
destination.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'file':str(destination),'records':len(rows),'head':record['head'],'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'records_sha256':hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()}))
