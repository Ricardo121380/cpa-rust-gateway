import os, subprocess, json, time, hashlib
from pathlib import Path
out=Path(__file__).parent
binary=Path('/Volumes/Asgard/Agentprojects/CPA-Rust/output/cpar62-client-metadata-20261020/eof-failure/final-full-gateway-failed')
cwd=Path('/Volumes/Asgard/Agentprojects/CPA-Rust/worktrees/validation/cpar62-client-metadata-20261020-32ece7f4bd4e')
expected='6b969388341b73776d04867e32924dda70631bdc509e0e5bfd4bc1bda9ab9f9b'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
env=os.environ.copy()
for key in ['RUST_TEST_THREADS','RUSTFLAGS','CARGO_BUILD_JOBS','CARGO_PROFILE_TEST_OPT_LEVEL']: env.pop(key,None)
env['CARGO_TARGET_DIR']='/Volumes/Asgard/Agentprojects/CPA-Rust/output/cpar62-client-metadata-20261020/target-full'
env['CHECK_REPORT_PATH']=str(out/'original-unused-check-report.md')
symbol='runtime::batch_c::grok::standard_responses::lifecycle::public_build_upstream_eof_idle_and_total_timeout_fail_once_without_resend'
for name,args in [('original-default-concurrency',[]),('original-filtered-control',[symbol,'--exact','--nocapture'])]:
 start=time.monotonic(); cmd=[str(binary),*args]
 record=dict(command=cmd,cwd=str(cwd),binary_sha256=expected,environment_overrides={k:env.get(k) for k in ['RUST_TEST_THREADS','RUSTFLAGS','CARGO_BUILD_JOBS','CARGO_PROFILE_TEST_OPT_LEVEL','CARGO_TARGET_DIR','CHECK_REPORT_PATH','RUST_LOG']},cpu_count=os.cpu_count(),limit_seconds=360)
 with (out/(name+'.log')).open('xb') as log:
  try: p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=360); record['returncode']=p.returncode
  except subprocess.TimeoutExpired: record['timeout']=True
 record['elapsed_seconds']=time.monotonic()-start
 (out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record),flush=True)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
