use std::{collections::HashSet, sync::{Arc, Barrier}, thread, time::{SystemTime,UNIX_EPOCH}};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let barrier = Arc::new(Barrier::new(8));
    let threads: Vec<_> = (0..8).map(|_| {
        let barrier = barrier.clone();
        thread::spawn(move || {
            barrier.wait();
            (0..10000).filter_map(|_|SystemTime::now().duration_since(UNIX_EPOCH).ok().map(|v|v.as_nanos())).collect::<Vec<_>>()
        })
    }).collect();
    let mut samples=Vec::new();
    for task in threads {samples.extend(task.join().map_err(|_|"clock probe thread")?);}
    let unique:HashSet<_>=samples.iter().copied().collect();
    println!("{{\"samples\":{},\"unique_timestamps\":{},\"duplicate_timestamps\":{},\"threads\":8,\"pid_is_common\":true}}",samples.len(),unique.len(),samples.len()-unique.len());
    Ok(())
}
