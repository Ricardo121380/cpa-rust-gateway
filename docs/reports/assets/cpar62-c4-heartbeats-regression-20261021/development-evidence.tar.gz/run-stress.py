import os,subprocess,sys,json,time
from pathlib import Path
out=Path(__file__).parent
phase=sys.argv[1]
binary=sys.argv[2]
cwd=sys.argv[3]
env=os.environ.copy();env.pop('RUST_TEST_THREADS',None)
if phase == 'candidate':env.pop('CPAR62_STAGE_TRACE',None)
else:env['CPAR62_STAGE_TRACE']='1'
start=time.monotonic(); processes=[]
for slot in [1,2]:
 cmd=[sys.executable,str(out/'run.py'),f'{phase}-stress-{slot}',cwd,'360',binary,'--nocapture']
 p=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);processes.append(p)
results=[]
for p in processes:
 stdout,_=p.communicate();print(stdout,flush=True);results.append({'runner_exit':p.returncode})
(out/(phase+'-stress-group.json')).write_text(json.dumps({'harnesses':2,'test_threads_per_harness':'default, RUST_TEST_THREADS unset','cpu_count':os.cpu_count(),'additional_load':'one other identical full gateway harness','elapsed_seconds':time.monotonic()-start,'results':results},indent=2)+'\n')
