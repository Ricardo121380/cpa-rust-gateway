from pathlib import Path
import json, os, signal, subprocess, sys, time

source = Path(sys.argv[1])
output = Path(sys.argv[2])
env = os.environ.copy()
env['CARGO_TARGET_DIR'] = '/Volumes/Asgard/Agentprojects/CPA-Rust/repo/cpa-rust-gateway/target'
started = time.monotonic()
with output.with_suffix('.driver.log').open('w') as log:
    process = subprocess.Popen(['/usr/bin/python3', 'scripts/acceptance/cpar62-cli.py', '--output', str(output)], cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT)
    killed = None
    deadline = time.monotonic() + 180
    while process.poll() is None:
        marker = output / 'pi-cancel/abort-complete'
        if killed is None and marker.exists():
            try:
                proof = json.loads(marker.read_text())
            except json.JSONDecodeError:
                time.sleep(0.02)
                continue
            assert proof['rpc_alive'] is True
            time.sleep(0.2)
            os.kill(proof['pid'], signal.SIGTERM)
            killed = {'pid': proof['pid'], 'signal': 'SIGTERM', 'after_abort_complete': True}
        if time.monotonic() > deadline:
            process.terminate()
            raise TimeoutError('negative CLI exit probe timed out')
        time.sleep(0.02)
    exit_code = process.wait()
diag_path = output / 'pi-cancel/cancel-diagnostic.json'
diagnostic = json.loads(diag_path.read_text()) if diag_path.exists() else None
receipt = {'source': str(source), 'output': str(output), 'exit': exit_code, 'elapsed_seconds': time.monotonic() - started, 'forced_client_exit': killed, 'diagnostic': diagnostic, 'early_exit_accepted': killed is not None and exit_code == 0}
output.with_suffix('.probe.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
