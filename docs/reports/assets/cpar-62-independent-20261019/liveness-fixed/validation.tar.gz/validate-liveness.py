from pathlib import Path
import os, subprocess, json, hashlib, time, re

repo = Path('/Volumes/Asgard/Agentprojects/CPA-Rust/repo/cpa-rust-gateway')
run = Path(__file__).resolve().parent
old = json.loads((run / 'full-source.json').read_text())
def git(*args, cwd=repo, env=None):
    return subprocess.check_output(['git', *args], cwd=cwd, env=env, text=True).strip()
head = git('rev-parse', 'HEAD')
index_env = os.environ.copy()
index_env['GIT_INDEX_FILE'] = str(run / 'full-liveness.index')
git('read-tree', head, env=index_env)
git('add', '--', *old['overlays_validation_only'], env=index_env)
tree = git('write-tree', env=index_env)
commit = subprocess.check_output(['git', 'commit-tree', tree, '-p', head], cwd=repo, env=index_env, input='Immutable #62 cancellation-liveness verification; user docs overlays validation-only\n', text=True).strip()
checkout = repo.parents[1] / 'output' / ('cpar62-liveness-validation-' + head[:8])
subprocess.run(['git', 'worktree', 'add', '--detach', str(checkout), commit], cwd=repo, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
hashes = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in old['owned_hashes']}
assert all(hashlib.sha256((checkout / name).read_bytes()).hexdigest() == value for name, value in hashes.items())
source = {'source_commit': commit, 'tree': tree, 'delivery_code_commit': head, 'fixed_baseline': old['fixed_baseline'], 'worktree': str(checkout), 'overlays_validation_only': old['overlays_validation_only'], 'owned_hashes': hashes}
(run / 'full-liveness-source.json').write_text(json.dumps(source, indent=2) + '\n')
assert git('status', '--porcelain', '--untracked-files=no', cwd=checkout) == ''
with (run / 'liveness-npm-ci.log').open('w') as log:
    subprocess.run(['npm', '--prefix', 'web/prism', 'ci', '--offline', '--ignore-scripts', '--no-audit', '--no-fund'], cwd=checkout, stdout=log, stderr=subprocess.STDOUT, check=True)
full_env = os.environ.copy()
full_env['PATH'] = str(run / 'full-bin') + ':' + full_env['PATH']
full_env['CARGO_TARGET_DIR'] = str(repo / 'target')
full_env['RUST_TEST_THREADS'] = '4'
full_env['CHECK_REPORT_PATH'] = str(run / 'full-liveness-steps.md')
print('Full started for immutable source ' + commit, flush=True)
started = time.monotonic()
with (run / 'full-liveness.log').open('w') as log:
    full = subprocess.run(['bash', 'scripts/check.sh', 'full'], cwd=checkout, env=full_env, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
text = (run / 'full-liveness.log').read_text()
counts = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
steps = (run / 'full-liveness-steps.md').read_text()
summary = {'exit': full.returncode, 'elapsed_seconds': time.monotonic() - started, 'source': source, 'worktree_status': git('status', '--porcelain', '--untracked-files=no', cwd=checkout), 'steps_passed': len(re.findall(r'\| PASS \|', steps)), 'rust_test_counts': {'passed': sum(row[0] for row in counts), 'failed': sum(row[1] for row in counts), 'ignored': sum(row[2] for row in counts)}}
(run / 'full-liveness-result.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'full': summary}), flush=True)
assert full.returncode == 0 and summary['worktree_status'] == ''
cli_env = os.environ.copy()
cli_env['CARGO_TARGET_DIR'] = str(repo / 'target')
results = []
for name, strict in [('liveness-cli', False), ('liveness-prompt-red', True)]:
    command = ['/usr/bin/python3', 'scripts/acceptance/cpar62-cli.py', '--output', str(run / name)]
    if strict:
        command.append('--require-prompt-release')
    with (run / (name + '-driver.log')).open('w') as log:
        result = subprocess.run(command, cwd=checkout, env=cli_env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    receipt = json.loads((run / name / 'run.json').read_text())
    assert result.returncode == (1 if strict else 0)
    assert receipt['installs_unchanged'] is True
    proof = json.loads((run / name / 'pi-cancel/cancel-client-alive').read_text())
    abort = json.loads((run / name / 'pi-cancel/abort-complete').read_text())
    diagnostic = json.loads((run / name / 'pi-cancel/cancel-diagnostic.json').read_text())
    assert proof['rpc_alive'] is True and proof['pid'] == abort['pid'] == diagnostic['cli_pid']
    assert diagnostic['cli_kept_alive'] is True and diagnostic['eventually_released_before_server_stop'] is True
    assert diagnostic['released_within_first_second'] is False
    identity = json.loads((run / name / 'client-identity.json').read_text())
    assert identity['source_head'] == commit
    results.append({'run': name, 'strict': strict, 'exit': result.returncode, 'identity': identity['source_head'], 'cancellation': diagnostic, 'installs_unchanged': True})
    print(json.dumps(results[-1]), flush=True)
assert all(hashlib.sha256((checkout / name).read_bytes()).hexdigest() == value for name, value in hashes.items())
assert git('status', '--porcelain', '--untracked-files=no', cwd=checkout) == ''
(run / 'liveness-cli-replays.json').write_text(json.dumps({'source': source, 'replays': results, 'worktree_status': '', 'owned_hashes_match': True}, indent=2) + '\n')
