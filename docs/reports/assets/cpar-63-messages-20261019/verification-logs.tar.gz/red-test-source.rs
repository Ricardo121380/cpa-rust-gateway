//! #63 controlled Messages through the real compiler, leased Build adapter and HTTP pool.
use super::*;

struct MessagesTransport {
    target: AdmittedEgressTarget,
    pool: UpstreamClientPool,
    profile: UpstreamTransportProfile,
    size: usize,
}

struct MessagesBody {
    inner: SocketBody,
    pending: Vec<u8>,
    size: usize,
}
impl GrokBuildResponseBody for MessagesBody {
    fn next_chunk(&mut self) -> BoxFuture<'_, Result<Option<Vec<u8>>, GatewayError>> {
        Box::pin(async move {
            if self.pending.is_empty() {
                let Some(bytes) = self.inner.next_chunk().await? else { return Ok(None) };
                self.pending = bytes;
            }
            let length = self.size.min(self.pending.len());
            Ok(Some(self.pending.drain(..length).collect()))
        })
    }
}
impl MessagesTransport {
    fn new(peer: &ModelPeer, size: usize) -> Result<Arc<Self>, Box<dyn Error>> {
        let port = peer.url.split(':').nth(2).and_then(|v| v.split('/').next())
            .ok_or("port")?.parse()?;
        let policy = EgressPolicy::try_new(EgressPolicyInput {
            id: EgressPolicyId::try_new("messages-63-loopback")?, name: "Messages controlled peer".into(),
            allowed_schemes: BTreeSet::from([EgressScheme::Http]),
            allowed_hosts: BTreeSet::from([EgressHost::try_new("127.0.0.1")?]),
            allowed_ports: BTreeSet::from([port]),
            allowed_cidrs: BTreeSet::from([EgressCidr::try_new("127.0.0.1".parse()?,32)?]),
            redirect_policy: RedirectPolicy::Deny,
        })?;
        Ok(Arc::new(Self {
            target: policy.admit_url(&peer.url, &SystemEgressDnsResolver)?,
            pool: UpstreamClientPool::new(NonZeroUsize::new(2).ok_or("pool")?),
            profile: UpstreamTransportProfile::new(UpstreamTimeouts::try_new(
                Duration::from_secs(2),Duration::from_secs(2),Duration::from_secs(3),Duration::from_secs(10))?,
                UpstreamProxy::Direct,NonZeroUsize::new(1).ok_or("bound")?), size,
        }))
    }
}
impl GrokBuildTransport for MessagesTransport {
    fn send(&self, request: GrokBuildResponsesOutboundRequest)
        -> BoxFuture<'_, Result<GrokBuildTransportResponse, GatewayError>> {
        Box::pin(async move {
            assert_eq!(request.url(), "https://cli-chat-proxy.grok.com/v1/responses");
            let streaming = serde_json::from_slice::<Value>(request.body()).map_err(|_| internal_error())?["stream"] == true;
            let handoff = UpstreamHttpRequest::try_new(self.target.clone(),UpstreamHttpMethod::Post,
                [("content-type".into(),"application/json".into()),
                 ("x-grok-model-override".into(),request.header("x-grok-model-override").ok_or_else(internal_error)?.into())],
                request.body().to_vec()).map_err(|_| internal_error())?;
            let response = self.pool.send(handoff,&self.profile).await?;
            Ok(GrokBuildTransportResponse::new(response.status(),
                if streaming { GrokBuildResponseContentType::EventStream } else { GrokBuildResponseContentType::Json },
                provider_grok::GrokBuildResponseContentEncoding::Identity,
                Box::new(MessagesBody { inner: SocketBody(response), pending: Vec::new(), size: self.size })))
        })
    }
}

#[actix_web::test]
async fn public_build_messages_json_retains_summary_before_success() -> TestResult {
    summary_answer(false).await
}
#[actix_web::test]
async fn public_build_messages_sse_retains_summary_before_success() -> TestResult {
    summary_answer(true).await
}
async fn summary_answer(streaming: bool) -> TestResult {
    let peer = ModelPeer::start_wire(streaming,super::super::tool_rounds::wire_response(1,streaming)?)?;
    let fixture = lifecycle_fixture(MessagesTransport::new(&peer,7)?)?;
    let recording = Recording::start(&fixture,false)?;
    let app = test::init_service(App::new().app_data(web::Data::new(fixture.state.clone()))
        .configure(gateway_http_actix::configure)).await;
    let reply = test::call_service(&app,test::TestRequest::post().uri("/v1/messages")
        .insert_header(("authorization",format!("Bearer {}",fixture.key)))
        .set_json(json!({"model":"p12-test-model","max_tokens":19,"stream":streaming,
            "messages":[{"role":"user","content":"question"}]})).to_request()).await;
    let status = reply.status();
    let bytes = test::read_body(reply).await;
    assert_eq!(peer.requests.lock().map_err(|_| "receiver")?.len(),1);
    assert_eq!(status,StatusCode::OK,"{}",String::from_utf8_lossy(&bytes));
    if streaming {
        let frames = public_frames(&bytes)?;
        assert_eq!(frames.iter().filter(|v| v["type"]=="message_stop").count(),1,"{}",String::from_utf8_lossy(&bytes));
    } else {
        assert_eq!(serde_json::from_slice::<Value>(&bytes)?["content"][0]["text"],"回答 1");
    }
    drop(app);
    recording.finish(&fixture,0).await?;
    Ok(())
}
