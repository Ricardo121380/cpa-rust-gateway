import subprocess,sys,time,json,hashlib,os
from pathlib import Path
root=Path(__file__).resolve().parent
label,cwd,*command=sys.argv[1:]
start=time.monotonic()
with (root/(label+'.log')).open('w') as log:
 result=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
receipt={'label':label,'cwd':cwd,'command':command,'exit':result.returncode,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256((root/(label+'.log')).read_bytes()).hexdigest()}
(root/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print((root/(label+'.log')).read_text()[-6000:])
sys.exit(result.returncode)
