from pathlib import Path
import gzip,hashlib,io,json,tarfile,tempfile
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
assets=root/'docs/reports/assets/cpar-62-listener-cancel-20261019';assets.mkdir(exist_ok=True)
selected={}
def add(name,path):
 path=Path(path)
 if path.exists():
  assert name not in selected,name
  selected[name]=path.read_bytes()
for stem in ['fin-red','fin-green','focused-grok','typecheck-clippy','typecheck-clippy-green','format','old-cli-direct','old-cli-direct2','old-cli-observer','new-cli-direct','new-cli-observer','final-full','immutable-old-direct','final-direct','final-direct2','final-observer2','final-codex-required2']:
 for suffix in ['json','log']:add('steps/'+stem+'.'+suffix,out/(stem+'.'+suffix))
for name in ['baseline-summary.json','listener-settings.json','source-manifest.json','old-control-source.json','old2-listener-source.json','listener-only-binding.json','validation-build-preparation.json','issues-before-summary.json','full-summary.json','full-steps.md','final-client-runs.json','preservation-final.json','scope-spec.md','review-final.json','verification-summary.json']:
 add('receipts/'+name,out/name)
for name in ['run-step.py','validate-clients.py','validate-clients-initial.py','collect-evidence.py']:
 add('orchestration/'+name,out/name)
files=['client.json','driver.stdout','driver.stderr','isolation.json','loaded-esm.json','ingress.json','upstream.json','events.txt','observations.json','cancel-ready','cancel-proceed','abort-complete','cancel-client-alive','cancel-diagnostic.json','cancel-observed','client-transport.json']
for label in ['immutable-old-direct','final-direct','final-direct2','final-observer2','final-codex-required2']:
 run=Path(tempfile.gettempdir())/f'cpar62-listener-{label}-20261019'
 for name in ['client-identity.json','isolated.sb','run.json','qualification.log']:add(label+'/'+name,run/name)
 if label=='final-direct2':add(label+'/installed-files.json.gz',run/'installed-files.json.gz')
 for scenario in ['codex-standard','pi-standard','pi-failure','pi-cancel']:
  for name in files:add(label+'/'+scenario+'/'+name,run/scenario/name)
for label in ['old-direct2','old-observer','new-direct','new-observer','final-direct']:
 run=Path(tempfile.gettempdir())/f'cpar62-listener-{label}-20261019'
 for name in ['run.json','qualification.log']:add('preliminary/'+label+'/'+name,run/name)
 for name in files:add('preliminary/'+label+'/pi-cancel/'+name,run/'pi-cancel'/name)
private_old=Path('/var/folders/tk/90cjjmks0h1b2l13fry36ccm0000gn/T/cpar62-20261018-2rzziqp_')
for run in ['cancel-exit-red','cancel-exit-green']:
 for name in ['qualification.log','pi-cancel/cancel-diagnostic.json','pi-cancel/driver.stderr']:
  add('retained-liveness-counterexample/'+run+'/'+name,private_old/run/name)
build=Path(tempfile.gettempdir())/'cpar62-listener-old-direct-20261019/build.log'
if build.exists():
 messages=[]
 for line in build.read_text().splitlines():
  try:
   row=json.loads(line)
   if row.get('reason')=='compiler-message':messages.append(row['message'].get('rendered',''))
  except json.JSONDecodeError:messages.append(line)
 selected['steps/initial-build-messages.log']='\n'.join(messages).encode()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
 for name,data in sorted(selected.items()):
  item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;item.mode=0o644
  archive.addfile(item,io.BytesIO(data))
archive_bytes=gzip.compress(stream.getvalue(),mtime=0)
archive_path=assets/'verified-evidence.tar.gz';archive_path.write_bytes(archive_bytes)
manifest={'archive':'verified-evidence.tar.gz','archive_sha256':hashlib.sha256(archive_bytes).hexdigest(),'members':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(selected.items())],'excluded':['credentials and client configuration directories','SQLite files','raw ESM stderr (its exact hash remains in client.json)','compiler-artifact JSON (raw log and hash retained privately)','unrelated prior output and user work']}
with tarfile.open(archive_path) as archive:
 assert set(archive.getnames())==set(selected)
 for item in archive.getmembers():
  assert item.isfile() and '..' not in Path(item.name).parts
  assert archive.extractfile(item).read()==selected[item.name]
(assets/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['baseline-summary.json','listener-settings.json','source-manifest.json','old-control-source.json','issues-before-summary.json','full-summary.json','final-client-runs.json','preservation-final.json','review-final.json','verification-summary.json']:
 (assets/name).write_bytes((out/name).read_bytes())
print(json.dumps({'members':len(selected),'archive_bytes':len(archive_bytes),'all_member_bytes_independently_read_back':True,'sha256':manifest['archive_sha256']}))
