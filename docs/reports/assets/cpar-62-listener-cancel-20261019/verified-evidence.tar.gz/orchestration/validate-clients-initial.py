from pathlib import Path
import hashlib, json, os, subprocess, tempfile
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
m=json.loads((out/'source-manifest.json').read_text())
old=json.loads((out/'old-control-source.json').read_text())
env=dict(os.environ,CARGO_TARGET_DIR=m['shared_target'])
rows=[]
for label,cwd,flags,expected in [
 ('immutable-old-direct',old['worktree'],['--require-prompt-release'],1),
 ('final-direct',m['worktree'],['--require-prompt-release'],0),
 ('final-observer',m['worktree'],['--require-prompt-release','--observe-client-tcp'],0),
 ('final-codex-required',m['worktree'],['--require-prompt-release','--require-codex-success'],1),
]:
 run=Path(tempfile.gettempdir())/f'cpar62-listener-{label}-20261019'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)
 result=subprocess.run(['python3',str(out/'run-step.py'),label,cwd,'/usr/bin/python3','scripts/acceptance/cpar62-cli.py',*flags,'--output',str(run)],env=env)
 assert result.returncode==expected,(label,result.returncode)
 receipt=json.loads((run/'run.json').read_text())
 diag=json.loads((run/'pi-cancel/cancel-diagnostic.json').read_text())
 client=json.loads((run/'pi-cancel/client.json').read_text())
 standard=json.loads((run/'pi-standard/observations.json').read_text())
 failure=json.loads((run/'pi-failure/observations.json').read_text())
 cancel=json.loads((run/'pi-cancel/observations.json').read_text())
 assert receipt['installs_unchanged']
 assert diag['cli_kept_alive'] and diag['alive_after_observation']['rpc_alive']
 assert diag['cli_pid']==diag['alive_after_observation']['pid']==diag['rpc_timeline']['pid']
 assert diag['lease_before_abort']['lease']==1
 assert diag['eventually_released_before_server_stop'] and diag['leases_at_observation_end']==0 and diag['peer_close_at_observation_end']==1
 assert diag['rpc_timeline']['delta_at_ms']<=diag['lease_before_abort']['observed_at_ms']<=diag['rpc_timeline']['abort_sent_at_ms']<=diag['release_observed_at_ms']<=diag['alive_after_observation']['observed_at_ms']<=client['cleanup_started_at_ms']
 assert standard['received']==5 and failure['received']==1 and cancel['received']==1
 assert all(standard['accounting'][k]==5 for k in ['attempts','usage','ledger'])
 assert (cancel['accounting']['attempts'],cancel['accounting']['usage'],cancel['accounting']['ledger'])==(1,0,0)
 assert (failure['accounting']['usage'],failure['accounting']['ledger'])==(1,1)
 assert diag['released_within_first_second']==(label!='immutable-old-direct')
 if label=='final-codex-required':
  assert receipt['exit']==0 and receipt['codex_success_gate']['status']=='FAIL'
  assert all(value is False for value in receipt['codex_success_gate']['checks'].values())
 elif label!='immutable-old-direct':
  assert receipt['exit']==0 and receipt['runner_status']=='PASS'
 else:
  assert receipt['exit']!=0 and receipt['runner_status']=='FAIL'
 ingress=json.loads((run/'pi-cancel/ingress.json').read_text())
 rows.append({'label':label,'source':json.loads((run/'client-identity.json').read_text())['source_head'],'run':str(run),'expected_exit':expected,'actual_exit':result.returncode,'qualification_exit':receipt['exit'],'cancellation':diag,'client_cleanup_started_at_ms':client['cleanup_started_at_ms'],'cancel_public_chunk_elapsed_ms':ingress[0]['chunk_elapsed_ms'],'cancel_keepalive_count':ingress[0]['wire'].count(': keepalive\n\n'),'cancel_accounting':cancel['accounting'],'standard_accounting':standard['accounting'],'failure_accounting':failure['accounting'],'installs_unchanged':receipt['installs_unchanged'],'codex_success_gate':receipt['codex_success_gate'],'tcp_observer':receipt['tcp_observer']})
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)
 (out/'final-client-runs.json').write_text(json.dumps(rows,indent=2)+'\n')
for binding in m['owned_files']:
 for directory in [root,Path(m['worktree'])]:
  assert hashlib.sha256((directory/binding['path']).read_bytes()).hexdigest()==binding['sha256']
print('All immutable actual-client oracles matched expected results; source binding and clean validation status retained.')
