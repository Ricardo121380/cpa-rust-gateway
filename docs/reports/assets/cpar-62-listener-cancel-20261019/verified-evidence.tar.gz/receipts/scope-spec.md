# Current user scope for #62

公开监听器配置对齐与 Pi 取消链验收修复。

- Continue feature/62-codex-responses-compat from 36e937ff; preserve all pre-existing dirty and historical evidence.
- Align the two test data listeners to deployed h1_allow_half_closed(false); retain management policy and all existing protocol compatibility.
- Do not call static drift a dynamic root cause. Controlled before/after should vary only listener configuration where possible.
- Reuse public HTTP, production compiler/factory/leased Build, real bounded TCP upstream and durable records.
- Regress normal open-half success; client FIN/reset while awaiting upstream headers and during idle SSE. No shortened deadlines or accelerated 15s SSE keepalive, no fixed-sleep resource proof.
- Actual unmodified original Pi RPC: incremental CLI text, real lease=1, abort, same PID alive throughout observation, independent upstream close and real lease=0, only then CLI/server cleanup. Premature CLI exit must fail.
- No read-ahead, retry or invented successful terminal. Known Usage keeps exact Request/Attempt/source-event/ledger; absent terminal Usage is not zero cost.
- Change production only if a production-path bug remains reproducible after alignment; otherwise deliver test-configuration repair and fresh evidence.
- Regress Pi tool/failure, summary-only JSON/SSE/history and #59/#60/#61 lifecycle/Usage/lease; final immutable Full and independent Standards/Spec; actual CLI opt-in separate.
- Keep one-second probe separate, unchanged assertion and no new SLA. Codex strict success gate unchanged. #61 cost NOT_ADMITTED and #58/#61/#62 OPEN, native dependencies intact.
- Only owned increment committed. Normal named feature push and one #62 result comment are authorized after verification/review/secret scan, with Git/API readback. No other issue changes, real Provider/accounts/budget, main/develop merge, tags, release or deployment.
