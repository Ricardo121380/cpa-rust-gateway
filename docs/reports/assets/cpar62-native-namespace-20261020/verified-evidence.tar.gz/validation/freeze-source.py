import hashlib,json,os,stat,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
extra=json.loads(Path(sys.argv[2]).read_text())["overlays"]
paths=set(subprocess.check_output(["git","ls-files","-z"],cwd=root).decode().split("\0"))-{ "" }
paths.update(v["path"] for v in extra)
records=[]
for rel in sorted(paths):
    p=root/rel; s=p.lstat()
    item={"path":rel,"mode":oct(stat.S_IMODE(s.st_mode))}
    if p.is_symlink(): item.update(kind="symlink",target=os.readlink(p))
    else: item.update(kind="file",bytes=s.st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    records.append(item)
wire=json.dumps(records,separators=(",",":"),sort_keys=True).encode()
value={"root":str(root),"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),"tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=root,text=True).strip(),"records_sha256":hashlib.sha256(wire).hexdigest(),"records":records}
Path(sys.argv[3]).write_text(json.dumps(value,indent=2)+"\n")
print(json.dumps({k:v for k,v in value.items() if k!="records"})+f" files={len(records)}")
