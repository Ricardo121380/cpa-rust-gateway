# Check run log

- Mode: `full`
- Started: `2026-10-20T12:22:39Z`
- Host: `Darwin 27.0.0 arm64`

| Step | Duration seconds | Result |
|---|---:|---|
| Shell syntax | 1 | PASS |
| CI workflow | 1 | PASS |
| Release artifact workflow | 0 | PASS |
| CI change classifier | 1 | PASS |
| Plan state | 0 | PASS |
| Plan state guard | 1 | PASS |
| Canary thresholds | 0 | PASS |
| Caddy split | 1 | PASS |
| Caddy split guard | 2 | PASS |
| Management SPA dependencies | 1 | PASS |
| Benchmark baseline comparator | 2 | PASS |
| Soak runner argument guard | 109 | PASS |
| Soak receipt checker | 1 | PASS |
| Quality installer cache behavior | 1 | PASS |
| Release artifact verifier | 11 | PASS |
| P12 systemd unit | 1 | PASS |
| P12 OpenAI differential graph | 0 | PASS |
| P12 OpenAI differential classifier | 1 | PASS |
| P12 OpenClaw migration dry-run | 2 | PASS |
| P12 G1 production graph | 0 | PASS |
| P12 G1 live harness | 0 | PASS |
| P12 G1 Chat SSE classifier | 0 | PASS |
| P12 G1 Responses JSON classifier | 0 | PASS |
| P12 G1 Messages SSE classifier | 0 | PASS |
| P12 grok2api memory export | 1 | PASS |
| P12 Autoreg Console memory export | 0 | PASS |
| P12 production observer | 0 | PASS |
| P12 Grok CPAR curl E2E harness | 0 | PASS |
| CPAR new-build acceptance oracle | 7 | PASS |
| Management SPA | 7 | PASS |
| Rust format | 3 | PASS |
| Clippy | 149 | PASS |
| Rust tests | 382 | FAIL (101) |
