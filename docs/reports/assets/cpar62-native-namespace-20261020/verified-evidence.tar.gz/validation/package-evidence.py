"""Package an explicit synthetic evidence allowlist; verify every member on readback."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path(json.loads((OUT / "actual-cli-root.json").read_text())["root"])
ASSETS = Path("/Volumes/Asgard/Agentprojects/CPA-Rust/worktrees/cpar62-native-namespace-20261020/docs/reports/assets/cpar62-native-namespace-20261020")
ASSETS.mkdir(parents=True, exist_ok=True)

SECRET = re.compile(rb"(?i)(authorization:\s*bearer\s+[A-Za-z0-9._~+/=-]{16,}|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|management[_-]?key)\s*[:=]\s*['\"]?[A-Za-z0-9._~+/=-]{16,}|-----BEGIN\s+[A-Z0-9\s]*PRIVATE KEY-----|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{20,}|sk-[A-Za-z0-9_-]{16,}|ksk_[A-Za-z0-9_-]{16,})")
SECRET_KEY = re.compile(r"(?i)^(api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|authorization)$")
OLD_TASK_PATH = ("docs/reports/assets/cpar-build-json-502-20261011/" + "task" + "-initial-failed-excerpt.txt").encode()
ARTIFACT_TASK_PATHS = []
for line in (ROOT / "build.log").read_text().splitlines():
    if not line.startswith("{"):
        continue
    artifact = json.loads(line)
    if artifact.get("reason") == "compiler-artifact" and artifact.get("target", {}).get("name") == "futures_task":
        for filename in artifact["filenames"]:
            path = Path(filename)
            assert path.is_relative_to(OUT / "target-full")
            assert re.fullmatch(r"libfutures_task-[0-9a-f]{16}\.(rlib|rmeta)", path.name)
            ARTIFACT_TASK_PATHS.append(filename.encode())
assert len(ARTIFACT_TASK_PATHS) == 2


def scan_json(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if SECRET_KEY.fullmatch(key) and isinstance(child, str) and len(child) >= 16:
                raise ValueError("credential-like JSON assignment")
            scan_json(child)
    elif isinstance(value, list):
        for child in value:
            scan_json(child)


def scan(name, body):
    if body.startswith(b"\x1f\x8b"):
        scan(name + " (decompressed)", gzip.decompress(body))
        return
    scanned = body
    if name.startswith("validation/full-source-") and name.endswith(".gz (decompressed)"):
        # The immutable manifest includes an old filename whose word ends with a token prefix.
        # This exact path-only exception does not change the archive or skip content elsewhere.
        scanned = scanned.replace(OLD_TASK_PATH, b"legacy-report-task-filename")
    if name == "actual-cli/build.log":
        for path in ARTIFACT_TASK_PATHS:
            scanned = scanned.replace(path, b"verified-cargo-artifact-filename")
    if SECRET.search(scanned):
        raise ValueError("possible secret in " + name)
    try:
        value = json.loads(body)
    except (ValueError, UnicodeDecodeError):
        return
    try:
        scan_json(value)
    except ValueError as error:
        raise ValueError(str(error) + " in " + name) from None


members = {}
for path in sorted(OUT.glob("*.log")):
    members["development-and-validation/" + path.name] = path.read_bytes()
for name in ["baseline.json", "overlay-binding.json", "validation-overlay-binding.json",
             "full-check.md", "full-final-check.md", "controlled-binary.json", "reviews.json",
             "preservation-final.json", "client-observation.json", "codex-native-resolution.json",
             "controlled-receipts.json", "full-result.json", "source-binding.json",
             "overlay-secret-scan.json", "rust-test-result.json",
             "freeze-source.py", "package-evidence.py"]:
    members["validation/" + name] = (OUT / name).read_bytes()
for name in ["full-source-before.json", "full-source-after.json"]:
    members["validation/" + name + ".gz"] = gzip.compress((OUT / name).read_bytes(), mtime=0)
for name in ["client-identity.json", "installed-files.json.gz", "run.json", "qualification.log",
             "build.log", "isolated.sb"]:
    members["actual-cli/" + name] = (ROOT / name).read_bytes()
for scenario in ["codex-standard", "pi-standard", "pi-failure", "pi-cancel"]:
    for name in ["client.json", "client.stderr.log", "loaded-esm.json", "ingress.json",
                 "upstream.json", "observations.json", "events.txt", "isolation.json",
                 "driver.stdout", "driver.stderr", "cancel-diagnostic.json", "cancel-ready",
                 "cancel-proceed", "abort-complete", "cancel-observed", "cancel-client-alive",
                 "work/seed.txt", "work/result.txt"]:
        path = ROOT / scenario / name
        if path.exists():
            members["actual-cli/" + scenario + "/" + name] = path.read_bytes()

# No client credential configuration, database, or temporary account directory enters the archive.
for name, body in members.items():
    assert not any(part in {"auths", "credentials", "secrets"} for part in Path(name).parts)
    assert not name.endswith((".sqlite", ".sqlite3", ".pem", ".key", ".oauth.json"))
    scan(name, body)

archive = ASSETS / "verified-evidence.tar.gz"
with archive.open("wb") as stream:
    with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as bundle:
            for name, body in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(body)
                info.mode = 0o644
                bundle.addfile(info, io.BytesIO(body))

records = []
with tarfile.open(archive, "r:gz") as bundle:
    assert len(bundle.getmembers()) == len(members)
    for info in bundle.getmembers():
        assert info.isfile()
        body = bundle.extractfile(info).read()
        assert body == members[info.name]
        scan(info.name, body)
        records.append({"path": info.name, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
result = {"archive": archive.name, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
          "member_count": len(records), "all_members_read_back": True,
          "all_members_secret_scanned_including_nested_gzip": True,
          "exact_path_false_positive": {"source_manifest_record": 2290,
                                        "path_sha256": hashlib.sha256(OLD_TASK_PATH).hexdigest(),
                                        "cargo_target": "futures_task",
                                        "cargo_artifact_path_sha256": [hashlib.sha256(path).hexdigest() for path in ARTIFACT_TASK_PATHS],
                                        "reason": "Known task-word substrings in one exact source-manifest path and two verified Cargo compiler-artifact paths are false positives. Only those paths in those metadata members are exempted from that substring rule; no archive bytes or other content are changed."},
          "members": records}
(ASSETS / "evidence-manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "members"}))
