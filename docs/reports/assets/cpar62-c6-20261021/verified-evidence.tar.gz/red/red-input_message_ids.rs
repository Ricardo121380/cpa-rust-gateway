//! C6 native input IDs through the actual public listener and independent receiver.
use super::*;

fn inputs() -> Value {
    json!([
        {"id":"dev-C6:Original_01","role":"developer","content":[{"type":"input_text","text":"Retain roles and order."}]},
        {"id":"user-C6~Original_02","role":"user","content":[{"type":"input_text","text":"seed 41"}]},
        {"id":"sys-C6!Original_03","role":"system","content":[{"type":"input_text","text":"exact identity"}]}
    ])
}

#[actix_web::test]
async fn public_build_c6_native_input_message_ids_reach_receiver() -> TestResult {
    let peer = ModelPeer::start_wire(false, tool_rounds::wire_response(1, false)?)?;
    let fixture = lifecycle_fixture(namespaces::transport(&peer, 7)?)?;
    let recording = Recording::start(&fixture, false)?;
    let (url, server) = namespaces::listener(&fixture)?;
    let body = json!({"model":"p12-test-model","input":inputs(),"stream":false});
    let (status, bytes) = namespaces::request(&fixture, &url, &body).await?;
    server.stop(false).await;
    let database = recording.finish(&fixture, 0).await?;
    let rows = SqliteEventStore::open_read_only(&database)?.list_events()?;
    println!("CPAR62_C6_RED {}", json!({"status":status,"receiver":peer.requests.lock().map_err(|_| "receiver")?.len(),
        "accepted":peer.accepted.load(Ordering::SeqCst),"requests":rows.iter().filter(|r| matches!(r.event(),GatewayEvent::Request(_))).count(),
        "attempts":fixture.events.attempts()?,"usage":rows.iter().filter(|r| matches!(r.event(),GatewayEvent::Usage(_))).count(),
        "ledger":SqliteBillingLedger::open_read_only(&database)?.list_bounded(10)?.len(),"cost":"UNKNOWN"}));
    assert_eq!(status, 200, "{}", String::from_utf8_lossy(&bytes));
    let sent = peer.requests.lock().map_err(|_| "receiver")?;
    assert_eq!(sent.len(), 1);
    assert_eq!(sent[0].body["input"], inputs().as_array().ok_or("inputs")?.iter().map(|v| {
        let mut v=v.clone();v["type"]=json!("message");v
    }).collect::<Value>());
    Ok(())
}
